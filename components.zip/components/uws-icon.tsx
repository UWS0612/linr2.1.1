'use client';

import Image from 'next/image';

interface UWSIconProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const sizePx = {
  sm: 24,
  md: 32,
  lg: 40,
  xl: 48,
};

export function UWSIcon({ size = 'md', className = '' }: UWSIconProps) {
  return (
    <Image
      src="/icononly_transparent_nobuffer_1763974511214.png"
      alt="LINR"
      width={sizePx[size]}
      height={sizePx[size]}
      className={className}
      style={{ width: sizePx[size], height: 'auto' }}
    />
  );
}
