import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from './db';
import { users, orgUsers, organisations } from './schema';
import { eq } from 'drizzle-orm';
import type { Role } from './schema';

const JWT_SECRET = process.env.SESSION_SECRET;
if (!JWT_SECRET) {
  console.warn('WARNING: SESSION_SECRET not set. Authentication will not work properly in production.');
}
const getJwtSecret = () => {
  if (!JWT_SECRET) {
    throw new Error('SESSION_SECRET environment variable must be set');
  }
  return JWT_SECRET;
};
const JWT_EXPIRES_IN = '7d';

export interface JWTPayload {
  userId: number;
  organisationId: number;
  orgUserId: number;
  role: Role;
  email: string;
  firstName: string;
  lastName: string;
}

export interface AuthUser extends JWTPayload {
  organisationName: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(payload: JWTPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: JWT_EXPIRES_IN });
}

export function verifyToken(token: string): JWTPayload | null {
  try {
    return jwt.verify(token, getJwtSecret()) as JWTPayload;
  } catch {
    return null;
  }
}

export async function authenticateUser(email: string, password: string): Promise<{
  success: boolean;
  token?: string;
  user?: AuthUser;
  error?: string;
}> {
  const user = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1);
  
  if (user.length === 0) {
    return { success: false, error: 'Invalid email or password' };
  }

  const foundUser = user[0];
  const isValid = await verifyPassword(password, foundUser.passwordHash);
  
  if (!isValid) {
    return { success: false, error: 'Invalid email or password' };
  }

  const orgUser = await db
    .select({
      orgUser: orgUsers,
      organisation: organisations,
    })
    .from(orgUsers)
    .innerJoin(organisations, eq(orgUsers.organisationId, organisations.id))
    .where(eq(orgUsers.userId, foundUser.id))
    .limit(1);

  if (orgUser.length === 0) {
    return { success: false, error: 'User is not part of any organisation' };
  }

  const { orgUser: ou, organisation } = orgUser[0];

  if (!ou.isActive) {
    return { success: false, error: 'Your account has been deactivated' };
  }

  const payload: JWTPayload = {
    userId: foundUser.id,
    organisationId: organisation.id,
    orgUserId: ou.id,
    role: ou.role as Role,
    email: foundUser.email,
    firstName: foundUser.firstName,
    lastName: foundUser.lastName,
  };

  const token = generateToken(payload);

  return {
    success: true,
    token,
    user: {
      ...payload,
      organisationName: organisation.name,
    },
  };
}

export function getTokenFromRequest(request: Request): string | null {
  const authHeader = request.headers.get('Authorization');
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return null;
}

export function requireAuth(request: Request): JWTPayload | null {
  const token = getTokenFromRequest(request);
  if (!token) return null;
  return verifyToken(token);
}

export function requireOrgAdmin(request: Request): JWTPayload | null {
  const user = requireAuth(request);
  if (!user) return null;
  if (user.role !== 'ORG_ADMIN') return null;
  return user;
}
