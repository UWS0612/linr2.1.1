import bcrypt from 'bcryptjs';
import { db } from './db';
import { platformUsers, organisations, users, orgUsers } from './schema';
import { eq } from 'drizzle-orm';

export async function seedPlatformOwner() {
  const email = 'kaleb@underwoodwaterservices.info';
  const password = 'Waterservices25!';
  const passwordHash = await bcrypt.hash(password, 12);
  
  const existingPlatform = await db.select().from(platformUsers).where(eq(platformUsers.email, email)).limit(1);
  
  if (existingPlatform.length === 0) {
    await db.insert(platformUsers).values({
      email,
      passwordHash,
      firstName: 'Kaleb',
      lastName: 'Underwood',
      isActive: true,
    });
    console.log('Platform owner created:', email);
  } else {
    await db.update(platformUsers)
      .set({ passwordHash, firstName: 'Kaleb', lastName: 'Underwood' })
      .where(eq(platformUsers.email, email));
    console.log('Platform owner updated:', email);
  }

  const existingOrg = await db.select().from(organisations).where(eq(organisations.name, 'Underwood Water Services')).limit(1);
  let orgId: number;
  
  if (existingOrg.length === 0) {
    const [newOrg] = await db.insert(organisations).values({
      name: 'Underwood Water Services',
      slug: 'underwood-water-services',
      billingStatus: 'active',
      planType: 'pro',
    }).returning({ id: organisations.id });
    orgId = newOrg.id;
    console.log('Organisation created: Underwood Water Services');
  } else {
    orgId = existingOrg[0].id;
    console.log('Organisation exists: Underwood Water Services');
  }

  const existingUser = await db.select().from(users).where(eq(users.email, email)).limit(1);
  let userId: number;
  
  if (existingUser.length === 0) {
    const [newUser] = await db.insert(users).values({
      email,
      passwordHash,
      firstName: 'Kaleb',
      lastName: 'Underwood',
    }).returning({ id: users.id });
    userId = newUser.id;
    console.log('User created:', email);
  } else {
    userId = existingUser[0].id;
    await db.update(users)
      .set({ passwordHash, firstName: 'Kaleb', lastName: 'Underwood' })
      .where(eq(users.email, email));
    console.log('User updated:', email);
  }

  const existingOrgUser = await db.select().from(orgUsers).where(eq(orgUsers.userId, userId)).limit(1);
  
  if (existingOrgUser.length === 0) {
    await db.insert(orgUsers).values({
      organisationId: orgId,
      userId: userId,
      role: 'ORG_ADMIN',
    });
    console.log('Org user link created');
  } else {
    console.log('Org user link exists');
  }
}
