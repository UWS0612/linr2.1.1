'use client';

import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { 
  LinrProjectData, 
  DailyReport, 
  MaterialRoll, 
  WeldRecord, 
  QualityTest, 
  AsBuiltDrawing,
  createEmptyProjectData,
  LINR_DATA_VERSION 
} from './linr-types';

interface LinrContextType {
  data: LinrProjectData | null;
  isLoading: boolean;
  addDailyReport: (report: DailyReport) => void;
  updateDailyReport: (id: string, report: Partial<DailyReport>) => void;
  deleteDailyReport: (id: string) => void;
  addMaterial: (material: MaterialRoll) => void;
  updateMaterial: (id: string, material: Partial<MaterialRoll>) => void;
  deleteMaterial: (id: string) => void;
  addWeld: (weld: WeldRecord) => void;
  updateWeld: (id: string, weld: Partial<WeldRecord>) => void;
  deleteWeld: (id: string) => void;
  addTest: (test: QualityTest) => void;
  updateTest: (id: string, test: Partial<QualityTest>) => void;
  deleteTest: (id: string) => void;
  addDrawing: (drawing: AsBuiltDrawing) => void;
  updateDrawing: (id: string, drawing: Partial<AsBuiltDrawing>) => void;
  deleteDrawing: (id: string) => void;
  clearAllData: () => void;
}

const LinrContext = createContext<LinrContextType | undefined>(undefined);

function getStorageKey(projectId: string): string {
  return `linr_project_${projectId}`;
}

export function LinrProvider({ projectId, children }: { projectId: string; children: ReactNode }) {
  const [data, setData] = useState<LinrProjectData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const key = getStorageKey(projectId);
    const stored = localStorage.getItem(key);
    
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as LinrProjectData;
        if (parsed.version === LINR_DATA_VERSION) {
          setData(parsed);
        } else {
          setData(createEmptyProjectData(projectId));
        }
      } catch {
        setData(createEmptyProjectData(projectId));
      }
    } else {
      setData(createEmptyProjectData(projectId));
    }
    setIsLoading(false);
  }, [projectId]);

  const saveData = useCallback((newData: LinrProjectData) => {
    const key = getStorageKey(projectId);
    newData.lastUpdated = new Date().toISOString();
    localStorage.setItem(key, JSON.stringify(newData));
    setData(newData);
  }, [projectId]);

  const addDailyReport = useCallback((report: DailyReport) => {
    if (!data) return;
    saveData({ ...data, dailyReports: [...data.dailyReports, report] });
  }, [data, saveData]);

  const updateDailyReport = useCallback((id: string, updates: Partial<DailyReport>) => {
    if (!data) return;
    saveData({
      ...data,
      dailyReports: data.dailyReports.map(r => r.id === id ? { ...r, ...updates } : r),
    });
  }, [data, saveData]);

  const deleteDailyReport = useCallback((id: string) => {
    if (!data) return;
    saveData({ ...data, dailyReports: data.dailyReports.filter(r => r.id !== id) });
  }, [data, saveData]);

  const addMaterial = useCallback((material: MaterialRoll) => {
    if (!data) return;
    saveData({ ...data, materials: [...data.materials, material] });
  }, [data, saveData]);

  const updateMaterial = useCallback((id: string, updates: Partial<MaterialRoll>) => {
    if (!data) return;
    saveData({
      ...data,
      materials: data.materials.map(m => m.id === id ? { ...m, ...updates } : m),
    });
  }, [data, saveData]);

  const deleteMaterial = useCallback((id: string) => {
    if (!data) return;
    saveData({ ...data, materials: data.materials.filter(m => m.id !== id) });
  }, [data, saveData]);

  const addWeld = useCallback((weld: WeldRecord) => {
    if (!data) return;
    saveData({ ...data, welds: [...data.welds, weld] });
  }, [data, saveData]);

  const updateWeld = useCallback((id: string, updates: Partial<WeldRecord>) => {
    if (!data) return;
    saveData({
      ...data,
      welds: data.welds.map(w => w.id === id ? { ...w, ...updates } : w),
    });
  }, [data, saveData]);

  const deleteWeld = useCallback((id: string) => {
    if (!data) return;
    saveData({ ...data, welds: data.welds.filter(w => w.id !== id) });
  }, [data, saveData]);

  const addTest = useCallback((test: QualityTest) => {
    if (!data) return;
    saveData({ ...data, tests: [...data.tests, test] });
  }, [data, saveData]);

  const updateTest = useCallback((id: string, updates: Partial<QualityTest>) => {
    if (!data) return;
    saveData({
      ...data,
      tests: data.tests.map(t => t.id === id ? { ...t, ...updates } : t),
    });
  }, [data, saveData]);

  const deleteTest = useCallback((id: string) => {
    if (!data) return;
    saveData({ ...data, tests: data.tests.filter(t => t.id !== id) });
  }, [data, saveData]);

  const addDrawing = useCallback((drawing: AsBuiltDrawing) => {
    if (!data) return;
    saveData({ ...data, drawings: [...data.drawings, drawing] });
  }, [data, saveData]);

  const updateDrawing = useCallback((id: string, updates: Partial<AsBuiltDrawing>) => {
    if (!data) return;
    saveData({
      ...data,
      drawings: data.drawings.map(d => d.id === id ? { ...d, ...updates } : d),
    });
  }, [data, saveData]);

  const deleteDrawing = useCallback((id: string) => {
    if (!data) return;
    saveData({ ...data, drawings: data.drawings.filter(d => d.id !== id) });
  }, [data, saveData]);

  const clearAllData = useCallback(() => {
    const key = getStorageKey(projectId);
    localStorage.removeItem(key);
    setData(createEmptyProjectData(projectId));
  }, [projectId]);

  return (
    <LinrContext.Provider value={{
      data,
      isLoading,
      addDailyReport,
      updateDailyReport,
      deleteDailyReport,
      addMaterial,
      updateMaterial,
      deleteMaterial,
      addWeld,
      updateWeld,
      deleteWeld,
      addTest,
      updateTest,
      deleteTest,
      addDrawing,
      updateDrawing,
      deleteDrawing,
      clearAllData,
    }}>
      {children}
    </LinrContext.Provider>
  );
}

export function useLinr() {
  const context = useContext(LinrContext);
  if (!context) {
    throw new Error('useLinr must be used within LinrProvider');
  }
  return context;
}
