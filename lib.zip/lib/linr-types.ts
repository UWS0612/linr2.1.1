export interface DailyReport {
  id: string;
  date: string;
  weather: {
    conditions: 'sunny' | 'cloudy' | 'overcast' | 'rain' | 'wind';
    tempMin: number | null;
    tempMax: number | null;
    windSpeed: number | null;
    humidity: number | null;
  };
  personnel: {
    name: string;
    role: string;
    hours: number;
  }[];
  activities: string;
  safetyNotes: string;
  delays: string;
  createdAt: string;
  createdBy: string;
}

export interface MaterialRoll {
  id: string;
  rollId: string;
  type: 'HDPE' | 'LLDPE' | 'PVC' | 'GCL' | 'OTHER';
  thickness: number;
  width: number;
  length: number;
  manufacturer: string;
  lotNumber: string;
  dateReceived: string;
  location: string;
  status: 'in-stock' | 'in-use' | 'depleted' | 'rejected';
  notes: string;
  createdAt: string;
  createdBy: string;
}

export interface WeldRecord {
  id: string;
  seamId: string;
  type: 'wedge' | 'extrusion';
  date: string;
  time: string;
  panelA: string;
  panelB: string;
  welder: string;
  machine: string;
  temperature: number;
  speed: number | null;
  airTemp: number | null;
  result: 'pass' | 'fail' | 'pending';
  notes: string;
  testResults: {
    destructive: boolean;
    airChannel: boolean;
    vacuum: boolean;
  };
  createdAt: string;
  createdBy: string;
}

export interface QualityTest {
  id: string;
  testType: 'destructive' | 'air-channel' | 'vacuum-box' | 'spark' | 'other';
  date: string;
  time: string;
  location: string;
  seamId: string | null;
  tester: string;
  result: 'pass' | 'fail';
  readings: {
    label: string;
    value: string;
    unit: string;
  }[];
  notes: string;
  createdAt: string;
  createdBy: string;
}

export interface DrawingElement {
  id: string;
  type: 'line' | 'rectangle' | 'text' | 'panel' | 'seam' | 'marker';
  x: number;
  y: number;
  x2?: number;
  y2?: number;
  width?: number;
  height?: number;
  text?: string;
  label?: string;
  color?: string;
  rotation?: number;
}

export interface AsBuiltDrawing {
  id: string;
  name: string;
  elements: DrawingElement[];
  scale: number;
  gridSize: number;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

export interface LinrProjectData {
  version: number;
  projectId: string;
  dailyReports: DailyReport[];
  materials: MaterialRoll[];
  welds: WeldRecord[];
  tests: QualityTest[];
  drawings: AsBuiltDrawing[];
  lastUpdated: string;
}

export const LINR_DATA_VERSION = 1;

export function createEmptyProjectData(projectId: string): LinrProjectData {
  return {
    version: LINR_DATA_VERSION,
    projectId,
    dailyReports: [],
    materials: [],
    welds: [],
    tests: [],
    drawings: [],
    lastUpdated: new Date().toISOString(),
  };
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
