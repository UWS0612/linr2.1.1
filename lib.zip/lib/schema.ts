import { pgTable, serial, varchar, text, timestamp, integer, boolean, jsonb, pgEnum, decimal } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

export const roleEnum = pgEnum('role', ['ORG_ADMIN', 'SUPERVISOR', 'QA', 'TECH']);
export const projectStatusEnum = pgEnum('project_status', ['planned', 'active', 'completed', 'archived']);
export const projectRoleEnum = pgEnum('project_role', ['SUPERVISOR', 'QA', 'TECH']);
export const billingStatusEnum = pgEnum('billing_status', ['trial', 'active', 'suspended', 'cancelled']);
export const planTypeEnum = pgEnum('plan_type', ['basic', 'pro', 'enterprise']);
export const releaseStatusEnum = pgEnum('release_status', ['stable', 'beta', 'deprecated']);
export const supportScopeEnum = pgEnum('support_scope', ['read_only', 'full_access']);

export const platformUsers = pgTable('platform_users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).unique().notNull(),
  passwordHash: text('password_hash').notNull(),
  firstName: varchar('first_name', { length: 100 }).notNull(),
  lastName: varchar('last_name', { length: 100 }).notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const organisations = pgTable('organisations', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  slug: varchar('slug', { length: 100 }).unique().notNull(),
  abn: varchar('abn', { length: 20 }),
  country: varchar('country', { length: 100 }),
  state: varchar('state', { length: 100 }),
  contactEmail: varchar('contact_email', { length: 255 }),
  billingStatus: billingStatusEnum('billing_status').notNull().default('trial'),
  planType: planTypeEnum('plan_type').notNull().default('basic'),
  trialEndsAt: timestamp('trial_ends_at'),
  subscriptionStartDate: timestamp('subscription_start_date'),
  nextRenewalDate: timestamp('next_renewal_date'),
  storageUsedMb: integer('storage_used_mb').default(0).notNull(),
  lastActiveAt: timestamp('last_active_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const releases = pgTable('releases', {
  id: serial('id').primaryKey(),
  version: varchar('version', { length: 20 }).unique().notNull(),
  status: releaseStatusEnum('status').notNull().default('beta'),
  notes: text('notes'),
  releaseDate: timestamp('release_date').defaultNow().notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const featureFlags = pgTable('feature_flags', {
  id: serial('id').primaryKey(),
  key: varchar('key', { length: 100 }).unique().notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  enabledForAll: boolean('enabled_for_all').default(false).notNull(),
  enabledPlans: jsonb('enabled_plans').default([]).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const orgFeatureOverrides = pgTable('org_feature_overrides', {
  id: serial('id').primaryKey(),
  organisationId: integer('organisation_id').references(() => organisations.id).notNull(),
  featureFlagId: integer('feature_flag_id').references(() => featureFlags.id).notNull(),
  enabled: boolean('enabled').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).unique().notNull(),
  passwordHash: text('password_hash').notNull(),
  firstName: varchar('first_name', { length: 100 }).notNull(),
  lastName: varchar('last_name', { length: 100 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const orgUsers = pgTable('org_users', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id).notNull(),
  organisationId: integer('organisation_id').references(() => organisations.id).notNull(),
  role: roleEnum('role').notNull().default('TECH'),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const supportAccess = pgTable('support_access', {
  id: serial('id').primaryKey(),
  organisationId: integer('organisation_id').references(() => organisations.id).notNull(),
  grantedByOrgUserId: integer('granted_by_org_user_id').references(() => orgUsers.id).notNull(),
  scope: supportScopeEnum('scope').notNull().default('read_only'),
  grantedAt: timestamp('granted_at').defaultNow().notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  revokedAt: timestamp('revoked_at'),
});

export const projects = pgTable('projects', {
  id: serial('id').primaryKey(),
  organisationId: integer('organisation_id').references(() => organisations.id).notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  clientName: varchar('client_name', { length: 255 }),
  siteName: varchar('site_name', { length: 255 }),
  location: text('location'),
  status: projectStatusEnum('status').notNull().default('planned'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const projectSpecs = pgTable('project_specs', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').references(() => projects.id).notNull().unique(),
  projectNumber: varchar('project_number', { length: 100 }),
  geomembraneType: varchar('geomembrane_type', { length: 100 }),
  specifiedThickness: varchar('specified_thickness', { length: 50 }),
  totalArea: varchar('total_area', { length: 50 }),
  startDate: varchar('start_date', { length: 20 }),
  supervisor: varchar('supervisor', { length: 255 }),
  contractor: varchar('contractor', { length: 255 }),
  qualityStandards: text('quality_standards'),
  testingRequirements: text('testing_requirements'),
  minPeelPass: varchar('min_peel_pass', { length: 50 }),
  minShearPass: varchar('min_shear_pass', { length: 50 }),
  destructiveTestFrequency: varchar('destructive_test_frequency', { length: 100 }),
  minWedgeTemp: integer('min_wedge_temp'),
  maxWedgeTemp: integer('max_wedge_temp'),
  minExtrusionTemp: integer('min_extrusion_temp'),
  maxExtrusionTemp: integer('max_extrusion_temp'),
  configJson: jsonb('config_json'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const projectAssignments = pgTable('project_assignments', {
  id: serial('id').primaryKey(),
  projectId: integer('project_id').references(() => projects.id).notNull(),
  orgUserId: integer('org_user_id').references(() => orgUsers.id).notNull(),
  roleOnProject: projectRoleEnum('role_on_project').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const organisationsRelations = relations(organisations, ({ many }) => ({
  orgUsers: many(orgUsers),
  projects: many(projects),
}));

export const usersRelations = relations(users, ({ many }) => ({
  orgUsers: many(orgUsers),
}));

export const orgUsersRelations = relations(orgUsers, ({ one, many }) => ({
  user: one(users, {
    fields: [orgUsers.userId],
    references: [users.id],
  }),
  organisation: one(organisations, {
    fields: [orgUsers.organisationId],
    references: [organisations.id],
  }),
  projectAssignments: many(projectAssignments),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  organisation: one(organisations, {
    fields: [projects.organisationId],
    references: [organisations.id],
  }),
  specs: one(projectSpecs),
  assignments: many(projectAssignments),
}));

export const projectSpecsRelations = relations(projectSpecs, ({ one }) => ({
  project: one(projects, {
    fields: [projectSpecs.projectId],
    references: [projects.id],
  }),
}));

export const projectAssignmentsRelations = relations(projectAssignments, ({ one }) => ({
  project: one(projects, {
    fields: [projectAssignments.projectId],
    references: [projects.id],
  }),
  orgUser: one(orgUsers, {
    fields: [projectAssignments.orgUserId],
    references: [orgUsers.id],
  }),
}));

export type Organisation = typeof organisations.$inferSelect;
export type InsertOrganisation = typeof organisations.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type OrgUser = typeof orgUsers.$inferSelect;
export type InsertOrgUser = typeof orgUsers.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type ProjectSpec = typeof projectSpecs.$inferSelect;
export type InsertProjectSpec = typeof projectSpecs.$inferInsert;
export type ProjectAssignment = typeof projectAssignments.$inferSelect;
export type InsertProjectAssignment = typeof projectAssignments.$inferInsert;

export type Role = 'ORG_ADMIN' | 'SUPERVISOR' | 'QA' | 'TECH';
export type ProjectStatus = 'planned' | 'active' | 'completed' | 'archived';
export type ProjectRole = 'SUPERVISOR' | 'QA' | 'TECH';
export type BillingStatus = 'trial' | 'active' | 'suspended' | 'cancelled';
export type PlanType = 'basic' | 'pro' | 'enterprise';
export type ReleaseStatus = 'stable' | 'beta' | 'deprecated';
export type SupportScope = 'read_only' | 'full_access';

export type PlatformUser = typeof platformUsers.$inferSelect;
export type InsertPlatformUser = typeof platformUsers.$inferInsert;
export type Release = typeof releases.$inferSelect;
export type InsertRelease = typeof releases.$inferInsert;
export type FeatureFlag = typeof featureFlags.$inferSelect;
export type InsertFeatureFlag = typeof featureFlags.$inferInsert;
export type SupportAccess = typeof supportAccess.$inferSelect;
export type InsertSupportAccess = typeof supportAccess.$inferInsert;
export type OrgFeatureOverride = typeof orgFeatureOverrides.$inferSelect;
export type InsertOrgFeatureOverride = typeof orgFeatureOverrides.$inferInsert;
