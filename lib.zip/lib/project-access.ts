import { db } from './db';
import { projects, projectAssignments } from './schema';
import { eq, and } from 'drizzle-orm';
import type { JWTPayload } from './auth';

export async function canAccessProject(
  user: JWTPayload,
  projectId: number
): Promise<boolean> {
  const [project] = await db
    .select()
    .from(projects)
    .where(
      and(
        eq(projects.id, projectId),
        eq(projects.organisationId, user.organisationId)
      )
    );

  if (!project) {
    return false;
  }

  if (user.role === 'ORG_ADMIN') {
    return true;
  }

  const [assignment] = await db
    .select()
    .from(projectAssignments)
    .where(
      and(
        eq(projectAssignments.projectId, projectId),
        eq(projectAssignments.orgUserId, user.orgUserId)
      )
    );

  return !!assignment;
}

export async function getProjectRole(
  user: JWTPayload,
  projectId: number
): Promise<string | null> {
  if (user.role === 'ORG_ADMIN') {
    return 'ORG_ADMIN';
  }

  const [assignment] = await db
    .select()
    .from(projectAssignments)
    .where(
      and(
        eq(projectAssignments.projectId, projectId),
        eq(projectAssignments.orgUserId, user.orgUserId)
      )
    );

  return assignment ? assignment.roleOnProject : null;
}
