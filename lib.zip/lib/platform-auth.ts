import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from './db';
import { platformUsers } from './schema';
import { eq } from 'drizzle-orm';

const JWT_SECRET = process.env.SESSION_SECRET;
const getJwtSecret = () => {
  if (!JWT_SECRET) {
    throw new Error('SESSION_SECRET environment variable must be set');
  }
  return JWT_SECRET;
};
const JWT_EXPIRES_IN = '24h';

export interface PlatformJWTPayload {
  platformUserId: number;
  email: string;
  firstName: string;
  lastName: string;
  isPlatformOwner: true;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generatePlatformToken(payload: PlatformJWTPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: JWT_EXPIRES_IN });
}

export function verifyPlatformToken(token: string): PlatformJWTPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as PlatformJWTPayload;
    if (decoded.isPlatformOwner !== true) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export async function authenticatePlatformUser(email: string, password: string): Promise<{
  success: boolean;
  token?: string;
  user?: PlatformJWTPayload;
  error?: string;
}> {
  const user = await db.select().from(platformUsers).where(eq(platformUsers.email, email.toLowerCase())).limit(1);
  
  if (user.length === 0) {
    return { success: false, error: 'Invalid email or password' };
  }

  const foundUser = user[0];
  
  if (!foundUser.isActive) {
    return { success: false, error: 'Account is deactivated' };
  }

  const isValid = await verifyPassword(password, foundUser.passwordHash);
  
  if (!isValid) {
    return { success: false, error: 'Invalid email or password' };
  }

  const payload: PlatformJWTPayload = {
    platformUserId: foundUser.id,
    email: foundUser.email,
    firstName: foundUser.firstName,
    lastName: foundUser.lastName,
    isPlatformOwner: true,
  };

  const token = generatePlatformToken(payload);

  return {
    success: true,
    token,
    user: payload,
  };
}

export function getPlatformTokenFromRequest(request: Request): string | null {
  const authHeader = request.headers.get('Authorization');
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.substring(7);
  }
  return null;
}

export function requirePlatformOwner(request: Request): PlatformJWTPayload | null {
  const token = getPlatformTokenFromRequest(request);
  if (!token) return null;
  return verifyPlatformToken(token);
}
