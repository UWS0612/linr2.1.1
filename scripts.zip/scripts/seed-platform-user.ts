import { db } from '../lib/db';
import { platformUsers } from '../lib/schema';
import bcrypt from 'bcryptjs';
import { eq } from 'drizzle-orm';

async function seedPlatformUser() {
  const email = 'admin@uwswelding.com';
  const password = 'admin123';
  
  const existing = await db.select().from(platformUsers).where(eq(platformUsers.email, email));
  
  if (existing.length > 0) {
    console.log('Platform user already exists');
    return;
  }
  
  const passwordHash = await bcrypt.hash(password, 12);
  
  await db.insert(platformUsers).values({
    email,
    passwordHash,
    firstName: 'Platform',
    lastName: 'Admin',
    isActive: true,
  });
  
  console.log('Platform user created successfully');
  console.log('Email:', email);
  console.log('Password:', password);
}

seedPlatformUser()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Failed to seed platform user:', err);
    process.exit(1);
  });
