import { seedPlatformOwner } from '../lib/seed-platform';

async function main() {
  console.log('Running database seed...');
  await seedPlatformOwner();
  console.log('Seed complete!');
  process.exit(0);
}

main().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
