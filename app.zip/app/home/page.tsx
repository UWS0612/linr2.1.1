'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { 
  FolderOpen, 
  Settings, 
  Users, 
  ClipboardList, 
  LogOut, 
  Loader2,
  Plus,
  MapPin,
  Building2,
  ChevronRight
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Project {
  id: number;
  name: string;
  clientName: string | null;
  siteName: string | null;
  location: string | null;
  status: 'planned' | 'active' | 'completed' | 'archived';
  roleOnProject?: 'SUPERVISOR' | 'QA' | 'TECH';
}

export default function HomePage() {
  const router = useRouter();
  const { user, token, isLoading: authLoading, logout, isOrgAdmin } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [authLoading, user, router]);

  useEffect(() => {
    if (token) {
      fetchProjects();
    }
  }, [token]);

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/my-projects', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setProjects(data.projects || []);
      }
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'planned': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'completed': return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      case 'archived': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(220,25%,10%)]">
      <header className="bg-[hsl(220,25%,12%)] border-b border-[hsl(220,25%,20%)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <UWSIcon size="md" />
              <span className="text-xl font-bold text-white tracking-tight">LINR</span>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-white">{user.firstName} {user.lastName}</p>
                <p className="text-xs text-gray-400">{user.organisationName}</p>
              </div>
              <button
                onClick={handleLogout}
                className="p-2 text-gray-400 hover:text-white hover:bg-[hsl(220,25%,18%)] rounded-md transition-colors"
                title="Sign out"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-teal-500" />
                My Jobs
              </h2>
              {isOrgAdmin && (
                <button
                  onClick={() => router.push('/admin/projects/new')}
                  className="flex items-center gap-2 px-3 py-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-medium rounded-md transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  New Project
                </button>
              )}
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
              </div>
            ) : projects.length === 0 ? (
              <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-8 text-center">
                <FolderOpen className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">No Projects Assigned</h3>
                <p className="text-gray-400 text-sm">
                  {isOrgAdmin 
                    ? "Create your first project to get started."
                    : "You haven't been assigned to any projects yet."}
                </p>
                {isOrgAdmin && (
                  <button
                    onClick={() => router.push('/admin/projects/new')}
                    className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-md transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                    Create Project
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {projects.map((project) => (
                  <button
                    key={project.id}
                    onClick={() => router.push(`/linr/${project.id}`)}
                    className="w-full bg-[hsl(220,25%,15%)] hover:bg-[hsl(220,25%,18%)] rounded-lg border border-[hsl(220,25%,20%)] p-4 text-left transition-colors group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-medium text-white truncate">{project.name}</h3>
                          <span className={`px-2 py-0.5 text-xs font-medium rounded border ${getStatusColor(project.status)}`}>
                            {project.status}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                          {project.clientName && (
                            <span className="flex items-center gap-1">
                              <Building2 className="h-4 w-4" />
                              {project.clientName}
                            </span>
                          )}
                          {project.siteName && (
                            <span className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {project.siteName}
                            </span>
                          )}
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-gray-500 group-hover:text-teal-500 transition-colors flex-shrink-0 ml-4" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {isOrgAdmin && (
            <div className="lg:col-span-1">
              <h2 className="text-xl font-semibold text-white flex items-center gap-2 mb-6">
                <Settings className="h-5 w-5 text-orange-500" />
                Admin Console
              </h2>
              <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] overflow-hidden">
                <button
                  onClick={() => router.push('/admin/projects')}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[hsl(220,25%,18%)] transition-colors text-left border-b border-[hsl(220,25%,20%)]"
                >
                  <ClipboardList className="h-5 w-5 text-teal-500" />
                  <div className="flex-1">
                    <p className="font-medium text-white">Projects</p>
                    <p className="text-xs text-gray-400">Manage all organisation projects</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-500" />
                </button>
                <button
                  onClick={() => router.push('/admin/staff')}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[hsl(220,25%,18%)] transition-colors text-left"
                >
                  <Users className="h-5 w-5 text-teal-500" />
                  <div className="flex-1">
                    <p className="font-medium text-white">Staff</p>
                    <p className="text-xs text-gray-400">Manage team members and roles</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-500" />
                </button>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
