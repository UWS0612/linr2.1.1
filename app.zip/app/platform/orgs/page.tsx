'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Building2,
  Users,
  FolderKanban,
  HardDrive,
  Plus,
  Search,
  LogOut,
  BarChart3,
  Package,
  ChevronRight,
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Organisation {
  id: number;
  name: string;
  slug: string;
  abn: string | null;
  country: string | null;
  state: string | null;
  billingStatus: 'trial' | 'active' | 'suspended' | 'cancelled';
  planType: 'basic' | 'pro' | 'enterprise';
  storageUsedMb: number;
  createdAt: string;
  usersCount: number;
  projectsCount: number;
}

export default function PlatformOrgsPage() {
  const router = useRouter();
  const [orgs, setOrgs] = useState<Organisation[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showNewOrgModal, setShowNewOrgModal] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('platform_token');
    if (!token) {
      router.push('/platform/login');
      return;
    }
    fetchOrgs();
  }, [router]);

  const fetchOrgs = async () => {
    try {
      const token = localStorage.getItem('platform_token');
      const res = await fetch('/api/platform/orgs', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.status === 403) {
        router.push('/platform/login');
        return;
      }

      const data = await res.json();
      setOrgs(data.organisations || []);
    } catch (error) {
      console.error('Failed to fetch orgs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('platform_token');
    localStorage.removeItem('platform_user');
    router.push('/platform/login');
  };

  const filteredOrgs = orgs.filter(
    (org) =>
      org.name.toLowerCase().includes(search.toLowerCase()) ||
      org.slug.toLowerCase().includes(search.toLowerCase())
  );

  const getBillingBadge = (status: string) => {
    const styles: Record<string, string> = {
      trial: 'bg-yellow-500/20 text-yellow-400',
      active: 'bg-green-500/20 text-green-400',
      suspended: 'bg-red-500/20 text-red-400',
      cancelled: 'bg-slate-500/20 text-slate-400',
    };
    return styles[status] || styles.trial;
  };

  const getPlanBadge = (plan: string) => {
    const styles: Record<string, string> = {
      basic: 'bg-slate-500/20 text-slate-400',
      pro: 'bg-purple-500/20 text-purple-400',
      enterprise: 'bg-blue-500/20 text-blue-400',
    };
    return styles[plan] || styles.basic;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <nav className="bg-slate-800/50 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <UWSIcon size="md" />
                <span className="font-semibold text-white">UWS Platform</span>
              </div>
              <div className="hidden md:flex items-center gap-4">
                <Link
                  href="/platform/orgs"
                  className="text-purple-400 px-3 py-2 rounded-lg bg-purple-500/10"
                >
                  <Building2 className="w-4 h-4 inline mr-2" />
                  Organisations
                </Link>
                <Link
                  href="/platform/releases"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <Package className="w-4 h-4 inline mr-2" />
                  Releases
                </Link>
                <Link
                  href="/platform/metrics"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <BarChart3 className="w-4 h-4 inline mr-2" />
                  Metrics
                </Link>
              </div>
            </div>
            <div className="flex items-center">
              <button
                onClick={handleLogout}
                className="text-slate-400 hover:text-white p-2"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Organisations</h1>
            <p className="text-slate-400 mt-1">
              {orgs.length} organisation{orgs.length !== 1 ? 's' : ''} registered
            </p>
          </div>
          <button
            onClick={() => setShowNewOrgModal(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Organisation
          </button>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search organisations..."
              className="w-full pl-10 pr-4 py-3 bg-slate-800/50 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="grid gap-4">
          {filteredOrgs.map((org) => (
            <Link
              key={org.id}
              href={`/platform/orgs/${org.id}`}
              className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6 hover:border-purple-500/50 transition-colors group"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-white group-hover:text-purple-400 transition-colors">
                      {org.name}
                    </h3>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getBillingBadge(org.billingStatus)}`}>
                      {org.billingStatus}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPlanBadge(org.planType)}`}>
                      {org.planType}
                    </span>
                  </div>
                  {org.abn && (
                    <p className="text-sm text-slate-500 mb-3">ABN: {org.abn}</p>
                  )}
                  <div className="flex items-center gap-6 text-sm text-slate-400">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      {org.usersCount} users
                    </div>
                    <div className="flex items-center gap-2">
                      <FolderKanban className="w-4 h-4" />
                      {org.projectsCount} projects
                    </div>
                    <div className="flex items-center gap-2">
                      <HardDrive className="w-4 h-4" />
                      {org.storageUsedMb} MB
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-purple-400 transition-colors" />
              </div>
            </Link>
          ))}

          {filteredOrgs.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              {search ? 'No organisations match your search.' : 'No organisations yet.'}
            </div>
          )}
        </div>
      </main>

      {showNewOrgModal && (
        <NewOrgModal
          onClose={() => setShowNewOrgModal(false)}
          onCreated={() => {
            setShowNewOrgModal(false);
            fetchOrgs();
          }}
        />
      )}
    </div>
  );
}

function NewOrgModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: () => void;
}) {
  const [name, setName] = useState('');
  const [abn, setAbn] = useState('');
  const [country, setCountry] = useState('');
  const [state, setState] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [planType, setPlanType] = useState('basic');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const token = localStorage.getItem('platform_token');
      const res = await fetch('/api/platform/orgs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ name, abn, country, state, contactEmail, planType }),
      });

      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Failed to create organisation');
        setLoading(false);
        return;
      }

      onCreated();
    } catch {
      setError('An error occurred');
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 rounded-2xl p-6 w-full max-w-md border border-slate-700">
        <h2 className="text-xl font-bold text-white mb-6">New Organisation</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Organisation Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              ABN
            </label>
            <input
              type="text"
              value={abn}
              onChange={(e) => setAbn(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">
                Country
              </label>
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1">
                State
              </label>
              <input
                type="text"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Contact Email
            </label>
            <input
              type="email"
              value={contactEmail}
              onChange={(e) => setContactEmail(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">
              Plan Type
            </label>
            <select
              value={planType}
              onChange={(e) => setPlanType(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
            >
              <option value="basic">Basic</option>
              <option value="pro">Pro</option>
              <option value="enterprise">Enterprise</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
