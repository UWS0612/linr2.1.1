'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Building2,
  Users,
  FolderKanban,
  HardDrive,
  Calendar,
  CreditCard,
  Shield,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Organisation {
  id: number;
  name: string;
  slug: string;
  abn: string | null;
  country: string | null;
  state: string | null;
  contactEmail: string | null;
  billingStatus: 'trial' | 'active' | 'suspended' | 'cancelled';
  planType: 'basic' | 'pro' | 'enterprise';
  trialEndsAt: string | null;
  subscriptionStartDate: string | null;
  nextRenewalDate: string | null;
  storageUsedMb: number;
  lastActiveAt: string | null;
  createdAt: string;
}

interface OrgStats {
  usersCount: number;
  totalProjects: number;
  activeProjects: number;
}

interface SupportAccessInfo {
  id: number;
  scope: string;
  grantedAt: string;
  expiresAt: string;
  grantedByFirstName: string;
  grantedByLastName: string;
}

export default function OrgDetailPage() {
  const router = useRouter();
  const params = useParams();
  const orgId = params.id as string;

  const [org, setOrg] = useState<Organisation | null>(null);
  const [stats, setStats] = useState<OrgStats | null>(null);
  const [supportAccess, setSupportAccess] = useState<SupportAccessInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'subscription' | 'support'>('overview');
  const [updating, setUpdating] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('platform_token');
    if (!token) {
      router.push('/platform/login');
      return;
    }
    fetchOrg();
  }, [router, orgId]);

  const fetchOrg = async () => {
    try {
      const token = localStorage.getItem('platform_token');
      const res = await fetch(`/api/platform/orgs/${orgId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.status === 403) {
        router.push('/platform/login');
        return;
      }

      const data = await res.json();
      setOrg(data.organisation);
      setStats(data.stats);
      setSupportAccess(data.supportAccess);
    } catch (error) {
      console.error('Failed to fetch org:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateOrg = async (updates: Record<string, unknown>) => {
    setUpdating(true);
    try {
      const token = localStorage.getItem('platform_token');
      const res = await fetch(`/api/platform/orgs/${orgId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(updates),
      });

      if (res.ok) {
        const data = await res.json();
        setOrg(data.organisation);
      }
    } catch (error) {
      console.error('Failed to update org:', error);
    } finally {
      setUpdating(false);
    }
  };

  const getBillingBadge = (status: string) => {
    const styles: Record<string, string> = {
      trial: 'bg-yellow-500/20 text-yellow-400',
      active: 'bg-green-500/20 text-green-400',
      suspended: 'bg-red-500/20 text-red-400',
      cancelled: 'bg-slate-500/20 text-slate-400',
    };
    return styles[status] || styles.trial;
  };

  const getPlanBadge = (plan: string) => {
    const styles: Record<string, string> = {
      basic: 'bg-slate-500/20 text-slate-400',
      pro: 'bg-purple-500/20 text-purple-400',
      enterprise: 'bg-blue-500/20 text-blue-400',
    };
    return styles[plan] || styles.basic;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  if (!org) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-slate-400">Organisation not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <nav className="bg-slate-800/50 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16 gap-4">
            <Link href="/platform/orgs" className="text-slate-400 hover:text-white p-2">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="flex items-center gap-2">
              <UWSIcon size="md" />
              <span className="font-semibold text-white">UWS Platform</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-2">
            <h1 className="text-2xl font-bold text-white">{org.name}</h1>
            <span className={`px-3 py-1 text-sm font-medium rounded-full ${getBillingBadge(org.billingStatus)}`}>
              {org.billingStatus}
            </span>
            <span className={`px-3 py-1 text-sm font-medium rounded-full ${getPlanBadge(org.planType)}`}>
              {org.planType}
            </span>
          </div>
          {org.abn && <p className="text-slate-400">ABN: {org.abn}</p>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Users className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats?.usersCount || 0}</p>
                <p className="text-sm text-slate-400">Active Users</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <FolderKanban className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats?.activeProjects || 0}</p>
                <p className="text-sm text-slate-400">Active Projects</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <FolderKanban className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{stats?.totalProjects || 0}</p>
                <p className="text-sm text-slate-400">Total Projects</p>
              </div>
            </div>
          </div>
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <HardDrive className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{org.storageUsedMb} MB</p>
                <p className="text-sm text-slate-400">Storage Used</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-2 mb-6 border-b border-slate-700/50">
          {(['overview', 'subscription', 'support'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-3 font-medium transition-colors ${
                activeTab === tab
                  ? 'text-purple-400 border-b-2 border-purple-400'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Organisation Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="text-sm text-slate-400">Name</label>
                <p className="text-white">{org.name}</p>
              </div>
              <div>
                <label className="text-sm text-slate-400">Slug</label>
                <p className="text-white">{org.slug}</p>
              </div>
              <div>
                <label className="text-sm text-slate-400">ABN</label>
                <p className="text-white">{org.abn || '—'}</p>
              </div>
              <div>
                <label className="text-sm text-slate-400">Contact Email</label>
                <p className="text-white">{org.contactEmail || '—'}</p>
              </div>
              <div>
                <label className="text-sm text-slate-400">Location</label>
                <p className="text-white">
                  {org.country || org.state
                    ? `${org.state || ''}${org.state && org.country ? ', ' : ''}${org.country || ''}`
                    : '—'}
                </p>
              </div>
              <div>
                <label className="text-sm text-slate-400">Created</label>
                <p className="text-white">{new Date(org.createdAt).toLocaleDateString()}</p>
              </div>
              <div>
                <label className="text-sm text-slate-400">Last Active</label>
                <p className="text-white">
                  {org.lastActiveAt ? new Date(org.lastActiveAt).toLocaleDateString() : '—'}
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'subscription' && (
          <div className="space-y-6">
            <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
              <h2 className="text-lg font-semibold text-white mb-4">Subscription Management</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Billing Status</label>
                  <select
                    value={org.billingStatus}
                    onChange={(e) => updateOrg({ billingStatus: e.target.value })}
                    disabled={updating}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
                  >
                    <option value="trial">Trial</option>
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-slate-400 mb-2 block">Plan Type</label>
                  <select
                    value={org.planType}
                    onChange={(e) => updateOrg({ planType: e.target.value })}
                    disabled={updating}
                    className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
                  >
                    <option value="basic">Basic</option>
                    <option value="pro">Pro</option>
                    <option value="enterprise">Enterprise</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-slate-400 mb-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">Trial Ends</span>
                  </div>
                  <p className="text-white">
                    {org.trialEndsAt ? new Date(org.trialEndsAt).toLocaleDateString() : '—'}
                  </p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-slate-400 mb-1">
                    <CreditCard className="w-4 h-4" />
                    <span className="text-sm">Subscription Start</span>
                  </div>
                  <p className="text-white">
                    {org.subscriptionStartDate
                      ? new Date(org.subscriptionStartDate).toLocaleDateString()
                      : '—'}
                  </p>
                </div>
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-slate-400 mb-1">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Next Renewal</span>
                  </div>
                  <p className="text-white">
                    {org.nextRenewalDate
                      ? new Date(org.nextRenewalDate).toLocaleDateString()
                      : '—'}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Quick Actions</h3>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => {
                    const newDate = new Date();
                    newDate.setDate(newDate.getDate() + 14);
                    updateOrg({ trialEndsAt: newDate.toISOString() });
                  }}
                  disabled={updating}
                  className="px-4 py-2 bg-yellow-600/20 hover:bg-yellow-600/30 text-yellow-400 rounded-lg transition-colors"
                >
                  Extend Trial +14 Days
                </button>
                <button
                  onClick={() => updateOrg({ billingStatus: 'active' })}
                  disabled={updating}
                  className="px-4 py-2 bg-green-600/20 hover:bg-green-600/30 text-green-400 rounded-lg transition-colors"
                >
                  Activate Subscription
                </button>
                <button
                  onClick={() => updateOrg({ billingStatus: 'suspended' })}
                  disabled={updating}
                  className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg transition-colors"
                >
                  Suspend Account
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'support' && (
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Support Access</h2>
            
            {supportAccess ? (
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400 mt-0.5" />
                  <div>
                    <p className="text-green-400 font-medium">Support Access Active</p>
                    <p className="text-sm text-slate-400 mt-1">
                      Granted by {supportAccess.grantedByFirstName} {supportAccess.grantedByLastName}
                    </p>
                    <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-slate-500">Scope:</span>
                        <span className="text-white ml-2">{supportAccess.scope}</span>
                      </div>
                      <div>
                        <span className="text-slate-500">Expires:</span>
                        <span className="text-white ml-2">
                          {new Date(supportAccess.expiresAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-slate-700/50 border border-slate-600/50 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-slate-500 mt-0.5" />
                  <div>
                    <p className="text-slate-400 font-medium">No Active Support Access</p>
                    <p className="text-sm text-slate-500 mt-1">
                      An ORG_ADMIN from this organisation must grant support access before you can view their QA data.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-6 p-4 bg-slate-700/30 rounded-lg">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-purple-400 mt-0.5" />
                <div>
                  <p className="text-slate-300 font-medium">Privacy Notice</p>
                  <p className="text-sm text-slate-500 mt-1">
                    You cannot access this organisation's QA data (seam logs, defect logs, tests, photos) 
                    unless they explicitly grant support access. All access is time-limited and auditable.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
