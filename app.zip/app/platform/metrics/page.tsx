'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Building2,
  Users,
  FolderKanban,
  HardDrive,
  Package,
  BarChart3,
  LogOut,
  TrendingUp,
  Activity,
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Metrics {
  organisations: {
    total: number;
    active: number;
    trial: number;
    suspended: number;
  };
  users: {
    total: number;
    activeOrgUsers: number;
  };
  projects: {
    total: number;
    active: number;
  };
  storage: {
    totalUsedMb: number;
  };
  planDistribution: Array<{
    plan: string;
    count: number;
  }>;
}

export default function MetricsPage() {
  const router = useRouter();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('platform_token');
    if (!token) {
      router.push('/platform/login');
      return;
    }
    fetchMetrics();
  }, [router]);

  const fetchMetrics = async () => {
    try {
      const token = localStorage.getItem('platform_token');
      const res = await fetch('/api/platform/metrics', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.status === 403) {
        router.push('/platform/login');
        return;
      }

      const data = await res.json();
      setMetrics(data.metrics);
    } catch (error) {
      console.error('Failed to fetch metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('platform_token');
    localStorage.removeItem('platform_user');
    router.push('/platform/login');
  };

  const formatStorage = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(2)} GB`;
    }
    return `${mb} MB`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <nav className="bg-slate-800/50 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <UWSIcon size="md" />
                <span className="font-semibold text-white">UWS Platform</span>
              </div>
              <div className="hidden md:flex items-center gap-4">
                <Link
                  href="/platform/orgs"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <Building2 className="w-4 h-4 inline mr-2" />
                  Organisations
                </Link>
                <Link
                  href="/platform/releases"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <Package className="w-4 h-4 inline mr-2" />
                  Releases
                </Link>
                <Link
                  href="/platform/metrics"
                  className="text-purple-400 px-3 py-2 rounded-lg bg-purple-500/10"
                >
                  <BarChart3 className="w-4 h-4 inline mr-2" />
                  Metrics
                </Link>
              </div>
            </div>
            <div className="flex items-center">
              <button onClick={handleLogout} className="text-slate-400 hover:text-white p-2">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white">Platform Metrics</h1>
          <p className="text-slate-400 mt-1">Overview of system usage and health</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Building2 className="w-6 h-6 text-blue-400" />
              </div>
              <TrendingUp className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white">{metrics?.organisations.total || 0}</p>
            <p className="text-sm text-slate-400">Total Organisations</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Users className="w-6 h-6 text-green-400" />
              </div>
              <Activity className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-3xl font-bold text-white">{metrics?.users.total || 0}</p>
            <p className="text-sm text-slate-400">Total Users</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <FolderKanban className="w-6 h-6 text-purple-400" />
              </div>
            </div>
            <p className="text-3xl font-bold text-white">{metrics?.projects.total || 0}</p>
            <p className="text-sm text-slate-400">Total Projects</p>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <HardDrive className="w-6 h-6 text-orange-400" />
              </div>
            </div>
            <p className="text-3xl font-bold text-white">
              {formatStorage(metrics?.storage.totalUsedMb || 0)}
            </p>
            <p className="text-sm text-slate-400">Total Storage Used</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Organisation Status</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                  <span className="text-slate-300">Active</span>
                </div>
                <span className="text-white font-medium">{metrics?.organisations.active || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                  <span className="text-slate-300">Trial</span>
                </div>
                <span className="text-white font-medium">{metrics?.organisations.trial || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                  <span className="text-slate-300">Suspended</span>
                </div>
                <span className="text-white font-medium">{metrics?.organisations.suspended || 0}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Plan Distribution</h2>
            <div className="space-y-4">
              {metrics?.planDistribution.map((plan) => (
                <div key={plan.plan} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        plan.plan === 'enterprise'
                          ? 'bg-blue-400'
                          : plan.plan === 'pro'
                          ? 'bg-purple-400'
                          : 'bg-slate-400'
                      }`}
                    ></div>
                    <span className="text-slate-300 capitalize">{plan.plan}</span>
                  </div>
                  <span className="text-white font-medium">{plan.count}</span>
                </div>
              ))}
              {(!metrics?.planDistribution || metrics.planDistribution.length === 0) && (
                <p className="text-slate-500 text-sm">No organisations yet</p>
              )}
            </div>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">Project Activity</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Active Projects</span>
                <span className="text-white font-medium">{metrics?.projects.active || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Total Projects</span>
                <span className="text-white font-medium">{metrics?.projects.total || 0}</span>
              </div>
              <div className="pt-2 border-t border-slate-700">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-sm">Activity Rate</span>
                  <span className="text-green-400 font-medium">
                    {metrics?.projects.total
                      ? Math.round((metrics.projects.active / metrics.projects.total) * 100)
                      : 0}
                    %
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6">
            <h2 className="text-lg font-semibold text-white mb-4">User Stats</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Registered Users</span>
                <span className="text-white font-medium">{metrics?.users.total || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Active Org Users</span>
                <span className="text-white font-medium">{metrics?.users.activeOrgUsers || 0}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 p-4 bg-slate-800/30 border border-slate-700/30 rounded-lg">
          <p className="text-sm text-slate-500 text-center">
            Note: This dashboard shows aggregated metrics only. No raw QA data is accessible from this console.
          </p>
        </div>
      </main>
    </div>
  );
}
