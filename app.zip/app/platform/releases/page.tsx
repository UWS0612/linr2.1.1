'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Package,
  Plus,
  Building2,
  BarChart3,
  LogOut,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Flag,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Release {
  id: number;
  version: string;
  status: 'stable' | 'beta' | 'deprecated';
  notes: string | null;
  releaseDate: string;
}

interface FeatureFlag {
  id: number;
  key: string;
  name: string;
  description: string | null;
  enabledForAll: boolean;
  enabledPlans: string[];
}

export default function ReleasesPage() {
  const router = useRouter();
  const [releases, setReleases] = useState<Release[]>([]);
  const [featureFlags, setFeatureFlags] = useState<FeatureFlag[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'releases' | 'features'>('releases');
  const [showNewReleaseModal, setShowNewReleaseModal] = useState(false);
  const [showNewFeatureModal, setShowNewFeatureModal] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('platform_token');
    if (!token) {
      router.push('/platform/login');
      return;
    }
    fetchData();
  }, [router]);

  const fetchData = async () => {
    const token = localStorage.getItem('platform_token');
    try {
      const [releasesRes, flagsRes] = await Promise.all([
        fetch('/api/platform/releases', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/platform/feature-flags', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (releasesRes.status === 403) {
        router.push('/platform/login');
        return;
      }

      const releasesData = await releasesRes.json();
      const flagsData = await flagsRes.json();

      setReleases(releasesData.releases || []);
      setFeatureFlags(flagsData.featureFlags || []);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('platform_token');
    localStorage.removeItem('platform_user');
    router.push('/platform/login');
  };

  const updateRelease = async (id: number, status: string) => {
    const token = localStorage.getItem('platform_token');
    await fetch(`/api/platform/releases/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ status }),
    });
    fetchData();
  };

  const toggleFeatureFlag = async (id: number, enabledForAll: boolean) => {
    const token = localStorage.getItem('platform_token');
    await fetch(`/api/platform/feature-flags/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ enabledForAll }),
    });
    fetchData();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'stable':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'beta':
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'deprecated':
        return <XCircle className="w-4 h-4 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      stable: 'bg-green-500/20 text-green-400',
      beta: 'bg-yellow-500/20 text-yellow-400',
      deprecated: 'bg-red-500/20 text-red-400',
    };
    return styles[status] || styles.beta;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900">
      <nav className="bg-slate-800/50 border-b border-slate-700/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <UWSIcon size="md" />
                <span className="font-semibold text-white">UWS Platform</span>
              </div>
              <div className="hidden md:flex items-center gap-4">
                <Link
                  href="/platform/orgs"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <Building2 className="w-4 h-4 inline mr-2" />
                  Organisations
                </Link>
                <Link
                  href="/platform/releases"
                  className="text-purple-400 px-3 py-2 rounded-lg bg-purple-500/10"
                >
                  <Package className="w-4 h-4 inline mr-2" />
                  Releases
                </Link>
                <Link
                  href="/platform/metrics"
                  className="text-slate-400 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-700/50"
                >
                  <BarChart3 className="w-4 h-4 inline mr-2" />
                  Metrics
                </Link>
              </div>
            </div>
            <div className="flex items-center">
              <button onClick={handleLogout} className="text-slate-400 hover:text-white p-2">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-2 mb-6 border-b border-slate-700/50">
          <button
            onClick={() => setActiveTab('releases')}
            className={`px-4 py-3 font-medium transition-colors flex items-center gap-2 ${
              activeTab === 'releases'
                ? 'text-purple-400 border-b-2 border-purple-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            Releases
          </button>
          <button
            onClick={() => setActiveTab('features')}
            className={`px-4 py-3 font-medium transition-colors flex items-center gap-2 ${
              activeTab === 'features'
                ? 'text-purple-400 border-b-2 border-purple-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Flag className="w-4 h-4" />
            Feature Flags
          </button>
        </div>

        {activeTab === 'releases' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-white">App Releases</h1>
              <button
                onClick={() => setShowNewReleaseModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                New Release
              </button>
            </div>

            <div className="space-y-4">
              {releases.map((release) => (
                <div
                  key={release.id}
                  className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      {getStatusIcon(release.status)}
                      <div>
                        <div className="flex items-center gap-3">
                          <h3 className="text-lg font-semibold text-white">{release.version}</h3>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(release.status)}`}>
                            {release.status}
                          </span>
                        </div>
                        {release.notes && (
                          <p className="text-sm text-slate-400 mt-1">{release.notes}</p>
                        )}
                        <p className="text-xs text-slate-500 mt-2">
                          Released: {new Date(release.releaseDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <select
                      value={release.status}
                      onChange={(e) => updateRelease(release.id, e.target.value)}
                      className="px-3 py-1 bg-slate-700 border border-slate-600 rounded-lg text-white text-sm"
                    >
                      <option value="beta">Beta</option>
                      <option value="stable">Stable</option>
                      <option value="deprecated">Deprecated</option>
                    </select>
                  </div>
                </div>
              ))}

              {releases.length === 0 && (
                <div className="text-center py-12 text-slate-500">No releases yet.</div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'features' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-2xl font-bold text-white">Feature Flags</h1>
              <button
                onClick={() => setShowNewFeatureModal(true)}
                className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                <Plus className="w-4 h-4" />
                New Feature Flag
              </button>
            </div>

            <div className="space-y-4">
              {featureFlags.map((flag) => (
                <div
                  key={flag.id}
                  className="bg-slate-800/50 border border-slate-700/50 rounded-xl p-6"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-semibold text-white">{flag.name}</h3>
                        <code className="px-2 py-1 bg-slate-700 text-purple-400 text-xs rounded">
                          {flag.key}
                        </code>
                      </div>
                      {flag.description && (
                        <p className="text-sm text-slate-400 mt-1">{flag.description}</p>
                      )}
                    </div>
                    <button
                      onClick={() => toggleFeatureFlag(flag.id, !flag.enabledForAll)}
                      className={`flex items-center gap-2 px-3 py-1 rounded-lg transition-colors ${
                        flag.enabledForAll
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-slate-700 text-slate-400'
                      }`}
                    >
                      {flag.enabledForAll ? (
                        <>
                          <ToggleRight className="w-5 h-5" />
                          Enabled
                        </>
                      ) : (
                        <>
                          <ToggleLeft className="w-5 h-5" />
                          Disabled
                        </>
                      )}
                    </button>
                  </div>
                </div>
              ))}

              {featureFlags.length === 0 && (
                <div className="text-center py-12 text-slate-500">No feature flags yet.</div>
              )}
            </div>
          </div>
        )}
      </main>

      {showNewReleaseModal && (
        <NewReleaseModal
          onClose={() => setShowNewReleaseModal(false)}
          onCreated={() => {
            setShowNewReleaseModal(false);
            fetchData();
          }}
        />
      )}

      {showNewFeatureModal && (
        <NewFeatureModal
          onClose={() => setShowNewFeatureModal(false)}
          onCreated={() => {
            setShowNewFeatureModal(false);
            fetchData();
          }}
        />
      )}
    </div>
  );
}

function NewReleaseModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [version, setVersion] = useState('');
  const [status, setStatus] = useState('beta');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const token = localStorage.getItem('platform_token');
    await fetch('/api/platform/releases', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ version, status, notes }),
    });

    onCreated();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 rounded-2xl p-6 w-full max-w-md border border-slate-700">
        <h2 className="text-xl font-bold text-white mb-6">New Release</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Version *</label>
            <input
              type="text"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="v1.0.0"
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
            >
              <option value="beta">Beta</option>
              <option value="stable">Stable</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Notes</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              rows={3}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function NewFeatureModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [key, setKey] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const token = localStorage.getItem('platform_token');
    await fetch('/api/platform/feature-flags', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ key, name, description }),
    });

    onCreated();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-slate-800 rounded-2xl p-6 w-full max-w-md border border-slate-700">
        <h2 className="text-xl font-bold text-white mb-6">New Feature Flag</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Key *</label>
            <input
              type="text"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="3d_as_built"
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Name *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="3D As-Built View"
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-white"
              rows={3}
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
