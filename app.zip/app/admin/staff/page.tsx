'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { 
  ArrowLeft, 
  Loader2, 
  Users,
  Plus,
  X,
  Eye,
  EyeOff
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface StaffMember {
  orgUserId: number;
  userId: number;
  email: string;
  firstName: string;
  lastName: string;
  role: 'ORG_ADMIN' | 'SUPERVISOR' | 'QA' | 'TECH';
  isActive: boolean;
}

export default function AdminStaffPage() {
  const router = useRouter();
  const { user, token, isLoading: authLoading, isOrgAdmin } = useAuth();
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showInvite, setShowInvite] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [inviteForm, setInviteForm] = useState({
    email: '',
    firstName: '',
    lastName: '',
    role: 'TECH' as const,
    password: '',
  });

  useEffect(() => {
    if (!authLoading && (!user || !isOrgAdmin)) {
      router.push('/home');
    }
  }, [authLoading, user, isOrgAdmin, router]);

  useEffect(() => {
    if (token && isOrgAdmin) {
      fetchStaff();
    }
  }, [token, isOrgAdmin]);

  const fetchStaff = async () => {
    try {
      const response = await fetch('/api/staff', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setStaff(data.staff || []);
      }
    } catch (error) {
      console.error('Failed to fetch staff:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/staff', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(inviteForm),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to add staff member');
      }

      await fetchStaff();
      setShowInvite(false);
      setInviteForm({
        email: '',
        firstName: '',
        lastName: '',
        role: 'TECH',
        password: '',
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add staff member');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ORG_ADMIN': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      case 'SUPERVISOR': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
      case 'QA': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'TECH': return 'bg-green-500/20 text-green-400 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  if (authLoading || !user || !isOrgAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(220,25%,10%)]">
      <header className="bg-[hsl(220,25%,12%)] border-b border-[hsl(220,25%,20%)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/home')}
              className="p-2 text-gray-400 hover:text-white hover:bg-[hsl(220,25%,18%)] rounded-md transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <UWSIcon size="md" />
              <span className="text-lg font-bold text-white">LINR</span>
            </div>
            <span className="text-gray-500">/</span>
            <span className="text-white font-medium">Staff</span>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Users className="h-6 w-6 text-teal-500" />
            <h1 className="text-2xl font-bold text-white">Team Members</h1>
          </div>
          <button
            onClick={() => setShowInvite(true)}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-md transition-colors"
          >
            <Plus className="h-4 w-4" />
            Add Staff
          </button>
        </div>

        {showInvite && (
          <div className="mb-6 bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-white">Add New Staff Member</h3>
              <button onClick={() => setShowInvite(false)} className="text-gray-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleInvite} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">First Name</label>
                  <input
                    type="text"
                    value={inviteForm.firstName}
                    onChange={(e) => setInviteForm({ ...inviteForm, firstName: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Last Name</label>
                  <input
                    type="text"
                    value={inviteForm.lastName}
                    onChange={(e) => setInviteForm({ ...inviteForm, lastName: e.target.value })}
                    required
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                <input
                  type="email"
                  value={inviteForm.email}
                  onChange={(e) => setInviteForm({ ...inviteForm, email: e.target.value })}
                  required
                  className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={inviteForm.password}
                    onChange={(e) => setInviteForm({ ...inviteForm, password: e.target.value })}
                    required
                    minLength={8}
                    placeholder="Minimum 8 characters"
                    className="w-full px-3 py-2 pr-10 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Role</label>
                <select
                  value={inviteForm.role}
                  onChange={(e) => setInviteForm({ ...inviteForm, role: e.target.value as any })}
                  className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                >
                  <option value="ORG_ADMIN">Admin</option>
                  <option value="SUPERVISOR">Supervisor</option>
                  <option value="QA">QA</option>
                  <option value="TECH">Tech</option>
                </select>
              </div>

              {error && (
                <div className="p-3 bg-red-900/30 border border-red-700 rounded-md text-red-300 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-800 text-white font-medium rounded-md transition-colors"
              >
                {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
                Add Staff Member
              </button>
            </form>
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
          </div>
        ) : staff.length === 0 ? (
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-8 text-center">
            <Users className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No Team Members</h3>
            <p className="text-gray-400 text-sm">Add your first staff member to get started.</p>
          </div>
        ) : (
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] overflow-hidden">
            {staff.map((member) => (
              <div
                key={member.orgUserId}
                className="flex items-center justify-between p-4 border-b border-[hsl(220,25%,20%)] last:border-0"
              >
                <div>
                  <p className="font-medium text-white">{member.firstName} {member.lastName}</p>
                  <p className="text-sm text-gray-400">{member.email}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded border ${getRoleColor(member.role)}`}>
                  {member.role}
                </span>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
