'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { 
  ArrowLeft, 
  Plus, 
  Loader2,
  ClipboardList,
  MapPin,
  Building2,
  ChevronRight,
  Search
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Project {
  id: number;
  name: string;
  clientName: string | null;
  siteName: string | null;
  location: string | null;
  status: 'planned' | 'active' | 'completed' | 'archived';
}

export default function AdminProjectsPage() {
  const router = useRouter();
  const { user, token, isLoading: authLoading, isOrgAdmin } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!authLoading && (!user || !isOrgAdmin)) {
      router.push('/home');
    }
  }, [authLoading, user, isOrgAdmin, router]);

  useEffect(() => {
    if (token && isOrgAdmin) {
      fetchProjects();
    }
  }, [token, isOrgAdmin]);

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/org-projects', {
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setProjects(data.projects || []);
      }
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'planned': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'completed': return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      case 'archived': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.siteName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (authLoading || !user || !isOrgAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(220,25%,10%)]">
      <header className="bg-[hsl(220,25%,12%)] border-b border-[hsl(220,25%,20%)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/home')}
              className="p-2 text-gray-400 hover:text-white hover:bg-[hsl(220,25%,18%)] rounded-md transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <UWSIcon size="md" />
              <span className="text-lg font-bold text-white">LINR</span>
            </div>
            <span className="text-gray-500">/</span>
            <span className="text-white font-medium">Projects</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <ClipboardList className="h-6 w-6 text-teal-500" />
            <h1 className="text-2xl font-bold text-white">All Projects</h1>
          </div>
          <button
            onClick={() => router.push('/admin/projects/new')}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-md transition-colors"
          >
            <Plus className="h-4 w-4" />
            New Project
          </button>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search projects..."
              className="w-full pl-10 pr-4 py-2 bg-[hsl(220,25%,15%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-teal-500" />
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-8 text-center">
            <ClipboardList className="h-12 w-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">
              {searchTerm ? 'No Projects Found' : 'No Projects Yet'}
            </h3>
            <p className="text-gray-400 text-sm">
              {searchTerm ? 'Try adjusting your search.' : 'Create your first project to get started.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredProjects.map((project) => (
              <button
                key={project.id}
                onClick={() => router.push(`/admin/projects/${project.id}`)}
                className="w-full bg-[hsl(220,25%,15%)] hover:bg-[hsl(220,25%,18%)] rounded-lg border border-[hsl(220,25%,20%)] p-4 text-left transition-colors group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-medium text-white truncate">{project.name}</h3>
                      <span className={`px-2 py-0.5 text-xs font-medium rounded border ${getStatusColor(project.status)}`}>
                        {project.status}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm text-gray-400">
                      {project.clientName && (
                        <span className="flex items-center gap-1">
                          <Building2 className="h-4 w-4" />
                          {project.clientName}
                        </span>
                      )}
                      {project.siteName && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {project.siteName}
                        </span>
                      )}
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-gray-500 group-hover:text-teal-500 transition-colors flex-shrink-0 ml-4" />
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
