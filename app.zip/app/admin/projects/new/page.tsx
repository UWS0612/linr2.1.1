'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { ArrowLeft, Loader2, Save } from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

export default function NewProjectPage() {
  const router = useRouter();
  const { user, token, isLoading: authLoading, isOrgAdmin } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    clientName: '',
    siteName: '',
    location: '',
    status: 'planned' as const,
  });

  useEffect(() => {
    if (!authLoading && (!user || !isOrgAdmin)) {
      router.push('/home');
    }
  }, [authLoading, user, isOrgAdmin, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to create project');
      }

      const data = await response.json();
      router.push(`/admin/projects/${data.project.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create project');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading || !user || !isOrgAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(220,25%,10%)]">
      <header className="bg-[hsl(220,25%,12%)] border-b border-[hsl(220,25%,20%)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push('/admin/projects')}
              className="p-2 text-gray-400 hover:text-white hover:bg-[hsl(220,25%,18%)] rounded-md transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <UWSIcon size="md" />
              <span className="text-lg font-bold text-white">LINR</span>
            </div>
            <span className="text-gray-500">/</span>
            <span className="text-gray-400">Projects</span>
            <span className="text-gray-500">/</span>
            <span className="text-white font-medium">New Project</span>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-white mb-8">Create New Project</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Project Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                placeholder="e.g., Cell 5 Liner Installation"
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Client Name
              </label>
              <input
                type="text"
                value={formData.clientName}
                onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                placeholder="e.g., ABC Waste Management"
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Site Name
              </label>
              <input
                type="text"
                value={formData.siteName}
                onChange={(e) => setFormData({ ...formData, siteName: e.target.value })}
                placeholder="e.g., Northern Landfill"
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Location
              </label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g., Sydney, NSW"
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="planned">Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-900/30 border border-red-700 rounded-md text-red-300 text-sm">
              {error}
            </div>
          )}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => router.push('/admin/projects')}
              className="flex-1 px-4 py-2 bg-[hsl(220,25%,20%)] hover:bg-[hsl(220,25%,25%)] text-white font-medium rounded-md transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-800 disabled:cursor-not-allowed text-white font-medium rounded-md transition-colors"
            >
              {isSubmitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              Create Project
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
