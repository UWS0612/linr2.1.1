'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { 
  ArrowLeft, 
  Loader2, 
  Save, 
  Settings,
  Users,
  FileText,
  Trash2,
  Plus,
  X,
  Play
} from 'lucide-react';
import { UWSIcon } from '@/components/uws-icon';

interface Project {
  id: number;
  name: string;
  clientName: string | null;
  siteName: string | null;
  location: string | null;
  status: 'planned' | 'active' | 'completed' | 'archived';
}

interface ProjectSpecs {
  id: number;
  projectNumber: string | null;
  geomembraneType: string | null;
  specifiedThickness: string | null;
  totalArea: string | null;
  startDate: string | null;
  supervisor: string | null;
  contractor: string | null;
  qualityStandards: string | null;
  testingRequirements: string | null;
  minPeelPass: string | null;
  minShearPass: string | null;
  destructiveTestFrequency: string | null;
  minWedgeTemp: number | null;
  maxWedgeTemp: number | null;
  minExtrusionTemp: number | null;
  maxExtrusionTemp: number | null;
  configJson: Record<string, any> | null;
}

interface Assignment {
  id: number;
  orgUserId: number;
  roleOnProject: 'SUPERVISOR' | 'QA' | 'TECH';
  firstName: string;
  lastName: string;
  email: string;
}

interface StaffMember {
  orgUserId: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
}

export default function ProjectDetailPage() {
  const router = useRouter();
  const params = useParams();
  const projectId = params.id as string;
  const { user, token, isLoading: authLoading, isOrgAdmin } = useAuth();
  
  const [activeTab, setActiveTab] = useState<'overview' | 'specs' | 'staff'>('overview');
  const [project, setProject] = useState<Project | null>(null);
  const [specs, setSpecs] = useState<ProjectSpecs | null>(null);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [allStaff, setAllStaff] = useState<StaffMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const [projectForm, setProjectForm] = useState({
    name: '',
    clientName: '',
    siteName: '',
    location: '',
    status: 'planned' as const,
  });

  const [specsForm, setSpecsForm] = useState({
    linerType: '',
    gclType: '',
    sheetWidthMm: '',
    minWedgeTemp: '',
    maxWedgeTemp: '',
    minExtrusionTemp: '',
    maxExtrusionTemp: '',
  });

  const [showAddStaff, setShowAddStaff] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState<number | null>(null);
  const [selectedRole, setSelectedRole] = useState<'SUPERVISOR' | 'QA' | 'TECH'>('TECH');

  useEffect(() => {
    if (!authLoading && (!user || !isOrgAdmin)) {
      router.push('/home');
    }
  }, [authLoading, user, isOrgAdmin, router]);

  useEffect(() => {
    if (token && isOrgAdmin && projectId) {
      fetchProjectData();
    }
  }, [token, isOrgAdmin, projectId]);

  const fetchProjectData = async () => {
    try {
      const [projectRes, specsRes, assignmentsRes, staffRes] = await Promise.all([
        fetch(`/api/projects/${projectId}`, {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
        fetch(`/api/projects/${projectId}/specs`, {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
        fetch(`/api/projects/${projectId}/assignments`, {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
        fetch('/api/staff', {
          headers: { 'Authorization': `Bearer ${token}` },
        }),
      ]);

      if (projectRes.ok) {
        const data = await projectRes.json();
        setProject(data.project);
        setProjectForm({
          name: data.project.name || '',
          clientName: data.project.clientName || '',
          siteName: data.project.siteName || '',
          location: data.project.location || '',
          status: data.project.status || 'planned',
        });
      }

      if (specsRes.ok) {
        const data = await specsRes.json();
        setSpecs(data.specs);
        if (data.specs) {
          setSpecsForm({
            linerType: data.specs.linerType || '',
            gclType: data.specs.gclType || '',
            sheetWidthMm: data.specs.sheetWidthMm?.toString() || '',
            minWedgeTemp: data.specs.minWedgeTemp?.toString() || '',
            maxWedgeTemp: data.specs.maxWedgeTemp?.toString() || '',
            minExtrusionTemp: data.specs.minExtrusionTemp?.toString() || '',
            maxExtrusionTemp: data.specs.maxExtrusionTemp?.toString() || '',
          });
        }
      }

      if (assignmentsRes.ok) {
        const data = await assignmentsRes.json();
        setAssignments(data.assignments || []);
      }

      if (staffRes.ok) {
        const data = await staffRes.json();
        setAllStaff(data.staff || []);
      }
    } catch (error) {
      console.error('Failed to fetch project data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveProject = async () => {
    setError('');
    setSuccessMessage('');
    setIsSaving(true);

    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(projectForm),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to save');
      }

      setSuccessMessage('Project saved successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setIsSaving(false);
    }
  };

  const saveSpecs = async () => {
    setError('');
    setSuccessMessage('');
    setIsSaving(true);

    try {
      const response = await fetch(`/api/projects/${projectId}/specs`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          linerType: specsForm.linerType || null,
          gclType: specsForm.gclType || null,
          sheetWidthMm: specsForm.sheetWidthMm ? parseInt(specsForm.sheetWidthMm) : null,
          minWedgeTemp: specsForm.minWedgeTemp ? parseInt(specsForm.minWedgeTemp) : null,
          maxWedgeTemp: specsForm.maxWedgeTemp ? parseInt(specsForm.maxWedgeTemp) : null,
          minExtrusionTemp: specsForm.minExtrusionTemp ? parseInt(specsForm.minExtrusionTemp) : null,
          maxExtrusionTemp: specsForm.maxExtrusionTemp ? parseInt(specsForm.maxExtrusionTemp) : null,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to save specs');
      }

      setSuccessMessage('Specifications saved successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setIsSaving(false);
    }
  };

  const addAssignment = async () => {
    if (!selectedStaffId) return;

    try {
      const response = await fetch(`/api/projects/${projectId}/assignments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          orgUserId: selectedStaffId,
          roleOnProject: selectedRole,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to add staff');
      }

      await fetchProjectData();
      setShowAddStaff(false);
      setSelectedStaffId(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add staff');
    }
  };

  const removeAssignment = async (assignmentId: number) => {
    try {
      const response = await fetch(`/api/projects/${projectId}/assignments/${assignmentId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to remove staff');
      }

      setAssignments(assignments.filter(a => a.id !== assignmentId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to remove staff');
    }
  };

  const unassignedStaff = allStaff.filter(
    s => !assignments.find(a => a.orgUserId === s.orgUserId) && s.role !== 'ORG_ADMIN'
  );

  if (authLoading || !user || !isOrgAdmin || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <Loader2 className="h-8 w-8 animate-spin text-teal-500" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[hsl(220,25%,10%)]">
        <p className="text-gray-400">Project not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(220,25%,10%)]">
      <header className="bg-[hsl(220,25%,12%)] border-b border-[hsl(220,25%,20%)]">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => router.push('/admin/projects')}
                className="p-2 text-gray-400 hover:text-white hover:bg-[hsl(220,25%,18%)] rounded-md transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="flex items-center gap-2">
                <UWSIcon size="md" />
                <span className="text-lg font-bold text-white">LINR</span>
              </div>
              <span className="text-gray-500">/</span>
              <span className="text-gray-400">Projects</span>
              <span className="text-gray-500">/</span>
              <span className="text-white font-medium truncate max-w-xs">{project.name}</span>
            </div>
            <button
              onClick={() => router.push(`/linr/${projectId}`)}
              className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium rounded-md transition-colors"
            >
              <Play className="h-4 w-4" />
              Enter LINR Tool
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex gap-2 mb-6 border-b border-[hsl(220,25%,20%)]">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2 font-medium transition-colors border-b-2 -mb-px ${
              activeTab === 'overview' 
                ? 'text-teal-400 border-teal-500' 
                : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            <FileText className="h-4 w-4" />
            Overview
          </button>
          <button
            onClick={() => setActiveTab('specs')}
            className={`flex items-center gap-2 px-4 py-2 font-medium transition-colors border-b-2 -mb-px ${
              activeTab === 'specs' 
                ? 'text-teal-400 border-teal-500' 
                : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            <Settings className="h-4 w-4" />
            Specs
          </button>
          <button
            onClick={() => setActiveTab('staff')}
            className={`flex items-center gap-2 px-4 py-2 font-medium transition-colors border-b-2 -mb-px ${
              activeTab === 'staff' 
                ? 'text-teal-400 border-teal-500' 
                : 'text-gray-400 border-transparent hover:text-white'
            }`}
          >
            <Users className="h-4 w-4" />
            Staff
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-md text-red-300 text-sm">
            {error}
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 bg-green-900/30 border border-green-700 rounded-md text-green-300 text-sm">
            {successMessage}
          </div>
        )}

        {activeTab === 'overview' && (
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Project Name</label>
              <input
                type="text"
                value={projectForm.name}
                onChange={(e) => setProjectForm({ ...projectForm, name: e.target.value })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Client Name</label>
              <input
                type="text"
                value={projectForm.clientName}
                onChange={(e) => setProjectForm({ ...projectForm, clientName: e.target.value })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Site Name</label>
              <input
                type="text"
                value={projectForm.siteName}
                onChange={(e) => setProjectForm({ ...projectForm, siteName: e.target.value })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Location</label>
              <input
                type="text"
                value={projectForm.location}
                onChange={(e) => setProjectForm({ ...projectForm, location: e.target.value })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Status</label>
              <select
                value={projectForm.status}
                onChange={(e) => setProjectForm({ ...projectForm, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="planned">Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="archived">Archived</option>
              </select>
            </div>
            <button
              onClick={saveProject}
              disabled={isSaving}
              className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-800 text-white font-medium rounded-md transition-colors"
            >
              {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save Changes
            </button>
          </div>
        )}

        {activeTab === 'specs' && (
          <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Liner Type</label>
                <input
                  type="text"
                  value={specsForm.linerType}
                  onChange={(e) => setSpecsForm({ ...specsForm, linerType: e.target.value })}
                  placeholder="e.g., HDPE 1.5mm"
                  className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">GCL Type</label>
                <input
                  type="text"
                  value={specsForm.gclType}
                  onChange={(e) => setSpecsForm({ ...specsForm, gclType: e.target.value })}
                  placeholder="e.g., Bentomat ST"
                  className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Sheet Width (mm)</label>
              <input
                type="number"
                value={specsForm.sheetWidthMm}
                onChange={(e) => setSpecsForm({ ...specsForm, sheetWidthMm: e.target.value })}
                placeholder="e.g., 7000"
                className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div className="border-t border-[hsl(220,25%,25%)] pt-4 mt-4">
              <h3 className="text-sm font-medium text-gray-300 mb-3">Wedge Weld Temperature Window</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Min Temp (°C)</label>
                  <input
                    type="number"
                    value={specsForm.minWedgeTemp}
                    onChange={(e) => setSpecsForm({ ...specsForm, minWedgeTemp: e.target.value })}
                    placeholder="380"
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Max Temp (°C)</label>
                  <input
                    type="number"
                    value={specsForm.maxWedgeTemp}
                    onChange={(e) => setSpecsForm({ ...specsForm, maxWedgeTemp: e.target.value })}
                    placeholder="450"
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-[hsl(220,25%,25%)] pt-4">
              <h3 className="text-sm font-medium text-gray-300 mb-3">Extrusion Weld Temperature Window</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Min Temp (°C)</label>
                  <input
                    type="number"
                    value={specsForm.minExtrusionTemp}
                    onChange={(e) => setSpecsForm({ ...specsForm, minExtrusionTemp: e.target.value })}
                    placeholder="200"
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-gray-500 mb-1">Max Temp (°C)</label>
                  <input
                    type="number"
                    value={specsForm.maxExtrusionTemp}
                    onChange={(e) => setSpecsForm({ ...specsForm, maxExtrusionTemp: e.target.value })}
                    placeholder="250"
                    className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>
            </div>

            <button
              onClick={saveSpecs}
              disabled={isSaving}
              className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-teal-800 text-white font-medium rounded-md transition-colors"
            >
              {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save Specifications
            </button>
          </div>
        )}

        {activeTab === 'staff' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-white">Assigned Staff</h3>
              {unassignedStaff.length > 0 && (
                <button
                  onClick={() => setShowAddStaff(true)}
                  className="flex items-center gap-2 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-medium rounded-md transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  Add Staff
                </button>
              )}
            </div>

            {showAddStaff && (
              <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-4">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-medium text-white">Add Staff Member</h4>
                  <button onClick={() => setShowAddStaff(false)} className="text-gray-400 hover:text-white">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Staff Member</label>
                    <select
                      value={selectedStaffId || ''}
                      onChange={(e) => setSelectedStaffId(parseInt(e.target.value))}
                      className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    >
                      <option value="">Select staff...</option>
                      {unassignedStaff.map(s => (
                        <option key={s.orgUserId} value={s.orgUserId}>
                          {s.firstName} {s.lastName} ({s.email})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-1">Role on Project</label>
                    <select
                      value={selectedRole}
                      onChange={(e) => setSelectedRole(e.target.value as any)}
                      className="w-full px-3 py-2 bg-[hsl(220,25%,12%)] border border-[hsl(220,25%,25%)] rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    >
                      <option value="SUPERVISOR">Supervisor</option>
                      <option value="QA">QA</option>
                      <option value="TECH">Tech</option>
                    </select>
                  </div>
                </div>
                <button
                  onClick={addAssignment}
                  disabled={!selectedStaffId}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 disabled:bg-gray-600 text-white font-medium rounded-md transition-colors"
                >
                  Add to Project
                </button>
              </div>
            )}

            {assignments.length === 0 ? (
              <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] p-8 text-center">
                <Users className="h-12 w-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-white mb-2">No Staff Assigned</h3>
                <p className="text-gray-400 text-sm">Add team members to this project.</p>
              </div>
            ) : (
              <div className="bg-[hsl(220,25%,15%)] rounded-lg border border-[hsl(220,25%,20%)] overflow-hidden">
                {assignments.map((assignment) => (
                  <div
                    key={assignment.id}
                    className="flex items-center justify-between p-4 border-b border-[hsl(220,25%,20%)] last:border-0"
                  >
                    <div>
                      <p className="font-medium text-white">{assignment.firstName} {assignment.lastName}</p>
                      <p className="text-sm text-gray-400">{assignment.email}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-2 py-1 text-xs font-medium bg-teal-500/20 text-teal-400 rounded border border-teal-500/30">
                        {assignment.roleOnProject}
                      </span>
                      <button
                        onClick={() => removeAssignment(assignment.id)}
                        className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-900/20 rounded transition-colors"
                        title="Remove from project"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
