import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users, organisations, orgUsers } from '@/lib/schema';
import { hashPassword, generateToken, type JWTPayload } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, firstName, lastName, organisationName } = body;

    if (!email || !password || !firstName || !lastName || !organisationName) {
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    const existingUser = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase()))
      .limit(1);

    if (existingUser.length > 0) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 400 }
      );
    }

    const passwordHash = await hashPassword(password);
    const slug = organisationName.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');

    const [newOrg] = await db
      .insert(organisations)
      .values({
        name: organisationName,
        slug: slug + '-' + Date.now(),
      })
      .returning();

    const [newUser] = await db
      .insert(users)
      .values({
        email: email.toLowerCase(),
        passwordHash,
        firstName,
        lastName,
      })
      .returning();

    const [newOrgUser] = await db
      .insert(orgUsers)
      .values({
        userId: newUser.id,
        organisationId: newOrg.id,
        role: 'ORG_ADMIN',
        isActive: true,
      })
      .returning();

    const payload: JWTPayload = {
      userId: newUser.id,
      organisationId: newOrg.id,
      orgUserId: newOrgUser.id,
      role: 'ORG_ADMIN',
      email: newUser.email,
      firstName: newUser.firstName,
      lastName: newUser.lastName,
    };

    const token = generateToken(payload);

    return NextResponse.json({
      token,
      user: {
        ...payload,
        organisationName: newOrg.name,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
