import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { organisations, orgUsers, projects, users } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { count, eq, sql, sum } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const [totalOrgs] = await db.select({ count: count() }).from(organisations);
    
    const [activeOrgs] = await db
      .select({ count: count() })
      .from(organisations)
      .where(eq(organisations.billingStatus, 'active'));
    
    const [trialOrgs] = await db
      .select({ count: count() })
      .from(organisations)
      .where(eq(organisations.billingStatus, 'trial'));
    
    const [suspendedOrgs] = await db
      .select({ count: count() })
      .from(organisations)
      .where(eq(organisations.billingStatus, 'suspended'));

    const [totalUsers] = await db.select({ count: count() }).from(users);
    
    const [activeUsers] = await db
      .select({ count: count() })
      .from(orgUsers)
      .where(eq(orgUsers.isActive, true));

    const [totalProjects] = await db.select({ count: count() }).from(projects);
    
    const [activeProjects] = await db
      .select({ count: count() })
      .from(projects)
      .where(eq(projects.status, 'active'));

    const [storageStats] = await db
      .select({ total: sum(organisations.storageUsedMb) })
      .from(organisations);

    const planDistribution = await db
      .select({
        planType: organisations.planType,
        count: count(),
      })
      .from(organisations)
      .groupBy(organisations.planType);

    return NextResponse.json({
      metrics: {
        organisations: {
          total: Number(totalOrgs?.count || 0),
          active: Number(activeOrgs?.count || 0),
          trial: Number(trialOrgs?.count || 0),
          suspended: Number(suspendedOrgs?.count || 0),
        },
        users: {
          total: Number(totalUsers?.count || 0),
          activeOrgUsers: Number(activeUsers?.count || 0),
        },
        projects: {
          total: Number(totalProjects?.count || 0),
          active: Number(activeProjects?.count || 0),
        },
        storage: {
          totalUsedMb: Number(storageStats?.total || 0),
        },
        planDistribution: planDistribution.map(p => ({
          plan: p.planType,
          count: Number(p.count),
        })),
      },
    });
  } catch (error) {
    console.error('Failed to fetch metrics:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
