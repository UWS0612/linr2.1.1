import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { featureFlags } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq } from 'drizzle-orm';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const flagId = parseInt(params.id);
  if (isNaN(flagId)) {
    return NextResponse.json({ error: 'Invalid feature flag ID' }, { status: 400 });
  }

  try {
    const body = await request.json();
    const { name, description, enabledForAll, enabledPlans } = body;

    const updateData: Record<string, unknown> = { updatedAt: new Date() };
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (enabledForAll !== undefined) updateData.enabledForAll = enabledForAll;
    if (enabledPlans !== undefined) updateData.enabledPlans = enabledPlans;

    const [updated] = await db
      .update(featureFlags)
      .set(updateData)
      .where(eq(featureFlags.id, flagId))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: 'Feature flag not found' }, { status: 404 });
    }

    return NextResponse.json({ featureFlag: updated });
  } catch (error) {
    console.error('Failed to update feature flag:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const flagId = parseInt(params.id);
  if (isNaN(flagId)) {
    return NextResponse.json({ error: 'Invalid feature flag ID' }, { status: 400 });
  }

  try {
    await db.delete(featureFlags).where(eq(featureFlags.id, flagId));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete feature flag:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
