import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { featureFlags } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const flags = await db.select().from(featureFlags);
    return NextResponse.json({ featureFlags: flags });
  } catch (error) {
    console.error('Failed to fetch feature flags:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { key, name, description, enabledForAll, enabledPlans } = body;

    if (!key || !name) {
      return NextResponse.json({ error: 'Key and name are required' }, { status: 400 });
    }

    const [newFlag] = await db.insert(featureFlags).values({
      key,
      name,
      description: description || null,
      enabledForAll: enabledForAll || false,
      enabledPlans: enabledPlans || [],
    }).returning();

    return NextResponse.json({ featureFlag: newFlag }, { status: 201 });
  } catch (error) {
    console.error('Failed to create feature flag:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
