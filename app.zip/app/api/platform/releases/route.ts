import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { releases } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq, desc } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const allReleases = await db
      .select()
      .from(releases)
      .orderBy(desc(releases.releaseDate));

    return NextResponse.json({ releases: allReleases });
  } catch (error) {
    console.error('Failed to fetch releases:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { version, status, notes } = body;

    if (!version) {
      return NextResponse.json({ error: 'Version is required' }, { status: 400 });
    }

    const [newRelease] = await db.insert(releases).values({
      version,
      status: status || 'beta',
      notes: notes || null,
    }).returning();

    return NextResponse.json({ release: newRelease }, { status: 201 });
  } catch (error) {
    console.error('Failed to create release:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
