import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { releases } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq } from 'drizzle-orm';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const releaseId = parseInt(params.id);
  if (isNaN(releaseId)) {
    return NextResponse.json({ error: 'Invalid release ID' }, { status: 400 });
  }

  try {
    const body = await request.json();
    const { status, notes } = body;

    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status;
    if (notes !== undefined) updateData.notes = notes;

    const [updated] = await db
      .update(releases)
      .set(updateData)
      .where(eq(releases.id, releaseId))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: 'Release not found' }, { status: 404 });
    }

    return NextResponse.json({ release: updated });
  } catch (error) {
    console.error('Failed to update release:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const releaseId = parseInt(params.id);
  if (isNaN(releaseId)) {
    return NextResponse.json({ error: 'Invalid release ID' }, { status: 400 });
  }

  try {
    await db.delete(releases).where(eq(releases.id, releaseId));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete release:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
