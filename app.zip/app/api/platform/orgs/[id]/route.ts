import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { organisations, orgUsers, projects, supportAccess, users } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq, count, and, gt } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const orgId = parseInt(params.id);
  if (isNaN(orgId)) {
    return NextResponse.json({ error: 'Invalid organisation ID' }, { status: 400 });
  }

  try {
    const [org] = await db.select().from(organisations).where(eq(organisations.id, orgId));
    
    if (!org) {
      return NextResponse.json({ error: 'Organisation not found' }, { status: 404 });
    }

    const [userCount] = await db
      .select({ count: count() })
      .from(orgUsers)
      .where(and(eq(orgUsers.organisationId, orgId), eq(orgUsers.isActive, true)));

    const [projectCount] = await db
      .select({ count: count() })
      .from(projects)
      .where(eq(projects.organisationId, orgId));

    const [activeProjectCount] = await db
      .select({ count: count() })
      .from(projects)
      .where(and(eq(projects.organisationId, orgId), eq(projects.status, 'active')));

    const now = new Date();
    const [activeSupportAccess] = await db
      .select({
        id: supportAccess.id,
        scope: supportAccess.scope,
        grantedAt: supportAccess.grantedAt,
        expiresAt: supportAccess.expiresAt,
        grantedByFirstName: users.firstName,
        grantedByLastName: users.lastName,
      })
      .from(supportAccess)
      .innerJoin(orgUsers, eq(supportAccess.grantedByOrgUserId, orgUsers.id))
      .innerJoin(users, eq(orgUsers.userId, users.id))
      .where(
        and(
          eq(supportAccess.organisationId, orgId),
          gt(supportAccess.expiresAt, now)
        )
      )
      .limit(1);

    return NextResponse.json({
      organisation: org,
      stats: {
        usersCount: Number(userCount?.count || 0),
        totalProjects: Number(projectCount?.count || 0),
        activeProjects: Number(activeProjectCount?.count || 0),
      },
      supportAccess: activeSupportAccess || null,
    });
  } catch (error) {
    console.error('Failed to fetch organisation:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  const orgId = parseInt(params.id);
  if (isNaN(orgId)) {
    return NextResponse.json({ error: 'Invalid organisation ID' }, { status: 400 });
  }

  try {
    const body = await request.json();
    const { billingStatus, planType, trialEndsAt, subscriptionStartDate, nextRenewalDate } = body;

    const updateData: Record<string, unknown> = { updatedAt: new Date() };
    
    if (billingStatus) updateData.billingStatus = billingStatus;
    if (planType) updateData.planType = planType;
    if (trialEndsAt) updateData.trialEndsAt = new Date(trialEndsAt);
    if (subscriptionStartDate) updateData.subscriptionStartDate = new Date(subscriptionStartDate);
    if (nextRenewalDate) updateData.nextRenewalDate = new Date(nextRenewalDate);

    const [updated] = await db
      .update(organisations)
      .set(updateData)
      .where(eq(organisations.id, orgId))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: 'Organisation not found' }, { status: 404 });
    }

    return NextResponse.json({ organisation: updated });
  } catch (error) {
    console.error('Failed to update organisation:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
