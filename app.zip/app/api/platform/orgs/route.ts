import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { organisations, orgUsers, projects } from '@/lib/schema';
import { requirePlatformOwner } from '@/lib/platform-auth';
import { eq, count, sql } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const orgsWithStats = await db
      .select({
        id: organisations.id,
        name: organisations.name,
        slug: organisations.slug,
        abn: organisations.abn,
        country: organisations.country,
        state: organisations.state,
        contactEmail: organisations.contactEmail,
        billingStatus: organisations.billingStatus,
        planType: organisations.planType,
        trialEndsAt: organisations.trialEndsAt,
        storageUsedMb: organisations.storageUsedMb,
        lastActiveAt: organisations.lastActiveAt,
        createdAt: organisations.createdAt,
      })
      .from(organisations)
      .orderBy(organisations.createdAt);

    const orgIds = orgsWithStats.map(o => o.id);
    
    const userCounts = await db
      .select({
        organisationId: orgUsers.organisationId,
        count: count(),
      })
      .from(orgUsers)
      .where(eq(orgUsers.isActive, true))
      .groupBy(orgUsers.organisationId);

    const projectCounts = await db
      .select({
        organisationId: projects.organisationId,
        count: count(),
      })
      .from(projects)
      .groupBy(projects.organisationId);

    const userCountMap = new Map(userCounts.map(u => [u.organisationId, Number(u.count)]));
    const projectCountMap = new Map(projectCounts.map(p => [p.organisationId, Number(p.count)]));

    const orgsData = orgsWithStats.map(org => ({
      ...org,
      usersCount: userCountMap.get(org.id) || 0,
      projectsCount: projectCountMap.get(org.id) || 0,
    }));

    return NextResponse.json({ organisations: orgsData });
  } catch (error) {
    console.error('Failed to fetch organisations:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const user = requirePlatformOwner(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Platform owner access required' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { name, abn, country, state, contactEmail, planType } = body;

    if (!name) {
      return NextResponse.json({ error: 'Organisation name is required' }, { status: 400 });
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 14);

    const [newOrg] = await db.insert(organisations).values({
      name,
      slug,
      abn: abn || null,
      country: country || null,
      state: state || null,
      contactEmail: contactEmail || null,
      planType: planType || 'basic',
      billingStatus: 'trial',
      trialEndsAt,
    }).returning();

    return NextResponse.json({ organisation: newOrg }, { status: 201 });
  } catch (error) {
    console.error('Failed to create organisation:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
