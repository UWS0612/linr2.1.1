import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects, projectAssignments, orgUsers } from '@/lib/schema';
import { requireAuth } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requireAuth(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    if (user.role === 'ORG_ADMIN') {
      const orgProjects = await db
        .select()
        .from(projects)
        .where(eq(projects.organisationId, user.organisationId));

      return NextResponse.json({ projects: orgProjects });
    }

    const assignedProjects = await db
      .select({
        id: projects.id,
        name: projects.name,
        clientName: projects.clientName,
        siteName: projects.siteName,
        location: projects.location,
        status: projects.status,
        roleOnProject: projectAssignments.roleOnProject,
      })
      .from(projectAssignments)
      .innerJoin(projects, eq(projectAssignments.projectId, projects.id))
      .where(
        and(
          eq(projectAssignments.orgUserId, user.orgUserId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    return NextResponse.json({ projects: assignedProjects });
  } catch (error) {
    console.error('Failed to fetch projects:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
