import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects, projectSpecs, projectAssignments } from '@/lib/schema';
import { requireAuth, requireOrgAdmin } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requireAuth(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const projectId = parseInt(params.id);

    if (isNaN(projectId)) {
      return NextResponse.json({ error: 'Invalid project ID' }, { status: 400 });
    }

    const [project] = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    if (user.role !== 'ORG_ADMIN') {
      const [assignment] = await db
        .select()
        .from(projectAssignments)
        .where(
          and(
            eq(projectAssignments.projectId, projectId),
            eq(projectAssignments.orgUserId, user.orgUserId)
          )
        );

      if (!assignment) {
        return NextResponse.json({ error: 'Access denied - not assigned to this project' }, { status: 403 });
      }
    }

    const [specs] = await db
      .select()
      .from(projectSpecs)
      .where(eq(projectSpecs.projectId, projectId));

    return NextResponse.json({ 
      project,
      specs: specs || null 
    });
  } catch (error) {
    console.error('Failed to fetch project specs:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const projectId = parseInt(params.id);
    
    if (isNaN(projectId)) {
      return NextResponse.json({ error: 'Invalid project ID' }, { status: 400 });
    }
    
    const body = await request.json();

    const [project] = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    const [existingSpecs] = await db
      .select()
      .from(projectSpecs)
      .where(eq(projectSpecs.projectId, projectId));

    const specsData = {
      projectNumber: body.projectNumber ?? null,
      geomembraneType: body.geomembraneType ?? null,
      specifiedThickness: body.specifiedThickness ?? null,
      totalArea: body.totalArea ?? null,
      startDate: body.startDate ?? null,
      supervisor: body.supervisor ?? null,
      contractor: body.contractor ?? null,
      qualityStandards: body.qualityStandards ?? null,
      testingRequirements: body.testingRequirements ?? null,
      minPeelPass: body.minPeelPass ?? null,
      minShearPass: body.minShearPass ?? null,
      destructiveTestFrequency: body.destructiveTestFrequency ?? null,
      minWedgeTemp: body.minWedgeTemp ?? null,
      maxWedgeTemp: body.maxWedgeTemp ?? null,
      minExtrusionTemp: body.minExtrusionTemp ?? null,
      maxExtrusionTemp: body.maxExtrusionTemp ?? null,
      configJson: body.configJson ?? null,
      updatedAt: new Date(),
    };

    let specs;
    if (existingSpecs) {
      [specs] = await db
        .update(projectSpecs)
        .set(specsData)
        .where(eq(projectSpecs.projectId, projectId))
        .returning();
    } else {
      [specs] = await db
        .insert(projectSpecs)
        .values({
          projectId,
          ...specsData,
        })
        .returning();
    }

    return NextResponse.json({ specs });
  } catch (error) {
    console.error('Failed to update project specs:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
