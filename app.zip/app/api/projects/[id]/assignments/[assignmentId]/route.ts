import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects, projectAssignments } from '@/lib/schema';
import { requireOrgAdmin } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string; assignmentId: string } }
) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const projectId = parseInt(params.id);
    const assignmentId = parseInt(params.assignmentId);
    
    if (isNaN(projectId) || isNaN(assignmentId)) {
      return NextResponse.json({ error: 'Invalid project ID or assignment ID' }, { status: 400 });
    }

    const [project] = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    const [assignment] = await db
      .select()
      .from(projectAssignments)
      .where(
        and(
          eq(projectAssignments.id, assignmentId),
          eq(projectAssignments.projectId, projectId)
        )
      );

    if (!assignment) {
      return NextResponse.json({ error: 'Assignment not found' }, { status: 404 });
    }

    await db.delete(projectAssignments).where(eq(projectAssignments.id, assignmentId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete assignment:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
