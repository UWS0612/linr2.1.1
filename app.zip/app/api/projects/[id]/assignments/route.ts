import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects, projectAssignments, orgUsers, users } from '@/lib/schema';
import { requireOrgAdmin } from '@/lib/auth';
import { eq, and } from 'drizzle-orm';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const projectId = parseInt(params.id);
    
    if (isNaN(projectId)) {
      return NextResponse.json({ error: 'Invalid project ID' }, { status: 400 });
    }

    const [project] = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    const assignments = await db
      .select({
        id: projectAssignments.id,
        orgUserId: projectAssignments.orgUserId,
        roleOnProject: projectAssignments.roleOnProject,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        orgRole: orgUsers.role,
      })
      .from(projectAssignments)
      .innerJoin(orgUsers, eq(projectAssignments.orgUserId, orgUsers.id))
      .innerJoin(users, eq(orgUsers.userId, users.id))
      .where(eq(projectAssignments.projectId, projectId));

    return NextResponse.json({ assignments });
  } catch (error) {
    console.error('Failed to fetch project assignments:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const projectId = parseInt(params.id);
    
    if (isNaN(projectId)) {
      return NextResponse.json({ error: 'Invalid project ID' }, { status: 400 });
    }
    
    const body = await request.json();
    const { orgUserId, roleOnProject } = body;

    if (!orgUserId || !roleOnProject) {
      return NextResponse.json({ error: 'orgUserId and roleOnProject are required' }, { status: 400 });
    }

    const [project] = await db
      .select()
      .from(projects)
      .where(
        and(
          eq(projects.id, projectId),
          eq(projects.organisationId, user.organisationId)
        )
      );

    if (!project) {
      return NextResponse.json({ error: 'Project not found' }, { status: 404 });
    }

    const [orgUser] = await db
      .select()
      .from(orgUsers)
      .where(
        and(
          eq(orgUsers.id, orgUserId),
          eq(orgUsers.organisationId, user.organisationId)
        )
      );

    if (!orgUser) {
      return NextResponse.json({ error: 'User not found in organisation' }, { status: 404 });
    }

    const existingAssignment = await db
      .select()
      .from(projectAssignments)
      .where(
        and(
          eq(projectAssignments.projectId, projectId),
          eq(projectAssignments.orgUserId, orgUserId)
        )
      );

    if (existingAssignment.length > 0) {
      const [updated] = await db
        .update(projectAssignments)
        .set({ roleOnProject })
        .where(eq(projectAssignments.id, existingAssignment[0].id))
        .returning();
      return NextResponse.json({ assignment: updated });
    }

    const [assignment] = await db
      .insert(projectAssignments)
      .values({
        projectId,
        orgUserId,
        roleOnProject,
      })
      .returning();

    return NextResponse.json({ assignment }, { status: 201 });
  } catch (error) {
    console.error('Failed to create assignment:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
