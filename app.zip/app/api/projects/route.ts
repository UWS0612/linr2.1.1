import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects, projectSpecs } from '@/lib/schema';
import { requireOrgAdmin } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const orgProjects = await db
      .select()
      .from(projects)
      .where(eq(projects.organisationId, user.organisationId));

    return NextResponse.json({ projects: orgProjects });
  } catch (error) {
    console.error('Failed to fetch projects:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { name, clientName, siteName, location, status } = body;

    if (!name) {
      return NextResponse.json({ error: 'Project name is required' }, { status: 400 });
    }

    const [newProject] = await db
      .insert(projects)
      .values({
        organisationId: user.organisationId,
        name,
        clientName: clientName || null,
        siteName: siteName || null,
        location: location || null,
        status: status || 'planned',
      })
      .returning();

    await db.insert(projectSpecs).values({
      projectId: newProject.id,
    });

    return NextResponse.json({ project: newProject }, { status: 201 });
  } catch (error) {
    console.error('Failed to create project:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
