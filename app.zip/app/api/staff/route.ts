import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { users, orgUsers } from '@/lib/schema';
import { requireOrgAdmin, hashPassword } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const staff = await db
      .select({
        orgUserId: orgUsers.id,
        userId: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        role: orgUsers.role,
        isActive: orgUsers.isActive,
        createdAt: orgUsers.createdAt,
      })
      .from(orgUsers)
      .innerJoin(users, eq(orgUsers.userId, users.id))
      .where(eq(orgUsers.organisationId, user.organisationId));

    return NextResponse.json({ staff });
  } catch (error) {
    console.error('Failed to fetch staff:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const body = await request.json();
    const { email, firstName, lastName, role, password } = body;

    if (!email || !firstName || !lastName || !role || !password) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    const existingUser = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase()))
      .limit(1);

    let userId: number;

    if (existingUser.length > 0) {
      const existingOrgUser = await db
        .select()
        .from(orgUsers)
        .where(eq(orgUsers.userId, existingUser[0].id))
        .limit(1);

      if (existingOrgUser.length > 0 && existingOrgUser[0].organisationId === user.organisationId) {
        return NextResponse.json({ error: 'User already exists in this organisation' }, { status: 400 });
      }

      if (existingOrgUser.length > 0) {
        return NextResponse.json({ error: 'User belongs to another organisation' }, { status: 400 });
      }

      userId = existingUser[0].id;
    } else {
      const passwordHash = await hashPassword(password);
      const [newUser] = await db
        .insert(users)
        .values({
          email: email.toLowerCase(),
          passwordHash,
          firstName,
          lastName,
        })
        .returning();
      userId = newUser.id;
    }

    const [newOrgUser] = await db
      .insert(orgUsers)
      .values({
        userId,
        organisationId: user.organisationId,
        role,
        isActive: true,
      })
      .returning();

    return NextResponse.json({
      staff: {
        orgUserId: newOrgUser.id,
        userId,
        email: email.toLowerCase(),
        firstName,
        lastName,
        role,
        isActive: true,
      },
    }, { status: 201 });
  } catch (error) {
    console.error('Failed to create staff member:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
