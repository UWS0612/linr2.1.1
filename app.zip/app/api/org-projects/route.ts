import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { projects } from '@/lib/schema';
import { requireOrgAdmin } from '@/lib/auth';
import { eq } from 'drizzle-orm';

export async function GET(request: NextRequest) {
  const user = requireOrgAdmin(request);
  
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized - Admin access required' }, { status: 403 });
  }

  try {
    const orgProjects = await db
      .select()
      .from(projects)
      .where(eq(projects.organisationId, user.organisationId));

    return NextResponse.json({ projects: orgProjects });
  } catch (error) {
    console.error('Failed to fetch organisation projects:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
