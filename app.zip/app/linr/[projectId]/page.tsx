"use client"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Download, Printer, Settings as SettingsIcon, Upload, Trash2, ChevronDown, FolderOpen, Plus, Home as HomeIcon, X, Pencil, ArrowLeft } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import JSZip from "jszip"
import { InstallPrompt } from "./install-prompt"
import { useAuth } from "@/lib/auth-context"

type LogEntry = string[]

type SubmissionRole = "Technician" | "QA" | "Supervisor" | "Engineer" | "Foreman"

interface LogSnapshot {
  logType: string
  entries: LogEntry[]
  count: number
}

interface RoleSubmission {
  id: string
  role: SubmissionRole
  submittedBy: string
  crew?: string
  timestamp: string
  logSnapshots: LogSnapshot[]
  notes: string
  status: "submitted" | "reopened"
  reopenHistory?: Array<{
    reopenedAt: string
    reopenedBy: string
    reason: string
  }>
}

interface DailySubmissions {
  date: string
  submissions: RoleSubmission[]
  completionStatus: "complete" | "incomplete" | "reopened"
  requiredRoles: SubmissionRole[]
}

interface FinalPortalData {
  [date: string]: DailySubmissions
}

interface Settings {
  company: string
  contact: string
  region: string
  logo: string
}

interface AsBuiltObject {
  type: 'line' | 'curve' | 'rectangle' | 'rounded-rectangle' | 'structure' | 'text' | 'gps-marker' | 'erase'
  color: string
  weight: number
  lineType: number[]
  x1?: number
  y1?: number
  x2?: number
  y2?: number
  p0?: { x: number, y: number }
  p1?: { x: number, y: number }
  p2?: { x: number, y: number }
  x?: number
  y?: number
  w?: number
  h?: number
  cornerRadius?: number
  text?: string
  lat?: number
  lon?: number
  rotation?: number
  seamNumber?: string
  panelId?: string
  layerType?: string
  membraneType?: string
  length?: number
}

interface AsBuiltLayer {
  id: number
  name: string
  objects: AsBuiltObject[]
  isVisible: boolean
}

interface AsBuiltData {
  layers: AsBuiltLayer[]
  activeLayerId: number
  nextLayerId: number
}

interface MaterialRoll {
  id: string
  rollId: string
  widthM: number
  fullLengthM: number
  remainingLengthM: number
  materialType: string
  isActive: boolean
  linkedRegisterIndex?: number
  consumptionLog: Array<{
    panelId: string
    lengthUsed: number
    timestamp: string
  }>
}

interface PanelPlacement {
  id: string
  panelNumber: string
  rollId: string
  lengthM: number
  widthM: number
  asBuiltObjectId?: string
  placedAt: string
  location?: string
}

interface MaterialInventory {
  rolls: MaterialRoll[]
  panelPlacements: PanelPlacement[]
  nextPanelNumber: number
}

interface ProjectSpecs {
  projectName: string
  projectNumber: string
  clientName: string
  siteLocation: string
  geomembraneType: string
  specifiedThickness: string
  totalArea: string
  startDate: string
  supervisor: string
  contractor: string
  qualityStandards: string
  testingRequirements: string
  minPeelPass: string
  minShearPass: string
  destructiveTestFrequency: string
}

interface Project {
  id: string
  name: string
  createdAt: string
  lastModified: string
  settings: Settings
  projectSpecs: ProjectSpecs
  signOnLogs: LogEntry[]
  dailyLogs: LogEntry[]
  panelPlacementLogs: LogEntry[]
  materialRegisterLogs: LogEntry[]
  weldLogs: LogEntry[]
  repairLogs: LogEntry[]
  airLogs: LogEntry[]
  vacuumLogs: LogEntry[]
  sparkLogs: LogEntry[]
  destructiveLogs: LogEntry[]
  machinePreStartLogs: LogEntry[]
  trialWeldLogs: LogEntry[]
  ncrLogs: LogEntry[]
  finalPortal: FinalPortalData
  asBuiltData: AsBuiltData
  materialInventory: MaterialInventory
}

interface FinalJointPortalProps {
  finalPortal: FinalPortalData
  setFinalPortal: (data: FinalPortalData) => void
  projectSpecs: ProjectSpecs
  signOnLogs: LogEntry[]
  dailyLogs: LogEntry[]
  panelPlacementLogs: LogEntry[]
  weldLogs: LogEntry[]
  trialWeldLogs: LogEntry[]
  repairLogs: LogEntry[]
  airLogs: LogEntry[]
  vacuumLogs: LogEntry[]
  sparkLogs: LogEntry[]
  destructiveLogs: LogEntry[]
  machinePreStartLogs: LogEntry[]
  ncrLogs: LogEntry[]
}

const ROLE_LOG_MAP: Record<SubmissionRole, { logTypes: string[], description: string }> = {
  "Technician": {
    logTypes: ["weldLogs", "trialWeldLogs", "repairLogs"],
    description: "Submit completed weld logs, trial welds, and repair logs from today's work"
  },
  "QA": {
    logTypes: ["panelPlacementLogs", "airLogs", "vacuumLogs", "sparkLogs", "destructiveLogs"],
    description: "Submit panel placement logs and all testing results (air, vacuum, spark, destructive)"
  },
  "Supervisor": {
    logTypes: ["signOnLogs", "dailyLogs", "machinePreStartLogs"],
    description: "Submit sign-on sheets, daily summaries, and machine pre-start checks"
  },
  "Engineer": {
    logTypes: ["destructiveLogs", "ncrLogs"],
    description: "Submit destructive test results and non-conformance reports"
  },
  "Foreman": {
    logTypes: ["machinePreStartLogs", "dailyLogs", "panelPlacementLogs"],
    description: "Submit machine pre-start checks, daily summaries, and panel placement logs"
  }
}

function FinalJointPortal(props: FinalJointPortalProps) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0])
  const [selectedRole, setSelectedRole] = useState<SubmissionRole | null>(null)
  const [submittedBy, setSubmittedBy] = useState("")
  const [crew, setCrew] = useState("")
  const [notes, setNotes] = useState("")
  const [viewTab, setViewTab] = useState<"submit" | "history" | "supervisor">("submit")
  const [supervisorDate, setSupervisorDate] = useState(new Date().toISOString().split('T')[0])

  const getTodayDate = () => new Date().toISOString().split('T')[0]

  const getLogsByType = (logType: string): LogEntry[] => {
    const logMap: Record<string, LogEntry[]> = {
      signOnLogs: props.signOnLogs,
      dailyLogs: props.dailyLogs,
      panelPlacementLogs: props.panelPlacementLogs,
      weldLogs: props.weldLogs,
      trialWeldLogs: props.trialWeldLogs,
      repairLogs: props.repairLogs,
      airLogs: props.airLogs,
      vacuumLogs: props.vacuumLogs,
      sparkLogs: props.sparkLogs,
      destructiveLogs: props.destructiveLogs,
      machinePreStartLogs: props.machinePreStartLogs,
      ncrLogs: props.ncrLogs
    }
    return logMap[logType] || []
  }

  const getLogTypeLabel = (logType: string): string => {
    const labels: Record<string, string> = {
      signOnLogs: "Sign-On Sheets",
      dailyLogs: "Daily Summaries",
      panelPlacementLogs: "Panel Placement",
      weldLogs: "Weld Logs",
      trialWeldLogs: "Trial Welds",
      repairLogs: "Repair Logs",
      airLogs: "Air Tests",
      vacuumLogs: "Vacuum Tests",
      sparkLogs: "Spark Tests",
      destructiveLogs: "Destructive Tests",
      machinePreStartLogs: "Machine Pre-Start Checks",
      ncrLogs: "NCR Reports"
    }
    return labels[logType] || logType
  }

  const getRoleSubmissions = (date: string): RoleSubmission[] => {
    const dailyData = props.finalPortal[date]
    return dailyData ? dailyData.submissions : []
  }

  const hasRoleSubmitted = (date: string, role: SubmissionRole): boolean => {
    const submissions = getRoleSubmissions(date)
    const roleSubmissions = submissions.filter(s => s.role === role)
    if (roleSubmissions.length === 0) return false
    const latestSubmission = roleSubmissions[roleSubmissions.length - 1]
    return latestSubmission.status === "submitted"
  }
  
  const getLatestSubmissionPerRole = (submissions: RoleSubmission[]): RoleSubmission[] => {
    const roleMap = new Map<SubmissionRole, RoleSubmission>()
    submissions.forEach(sub => {
      const existing = roleMap.get(sub.role)
      if (!existing || new Date(sub.timestamp) > new Date(existing.timestamp)) {
        roleMap.set(sub.role, sub)
      }
    })
    return Array.from(roleMap.values())
  }

  const handleSubmit = () => {
    if (!selectedRole || !submittedBy.trim()) {
      alert("Please select a role and enter your name before submitting.")
      return
    }

    const roleConfig = ROLE_LOG_MAP[selectedRole]
    const logSnapshots: LogSnapshot[] = roleConfig.logTypes.map(logType => ({
      logType,
      entries: getLogsByType(logType),
      count: getLogsByType(logType).length
    }))

    const newSubmission: RoleSubmission = {
      id: Date.now().toString(),
      role: selectedRole,
      submittedBy: submittedBy.trim(),
      crew: crew.trim(),
      timestamp: new Date().toISOString(),
      logSnapshots,
      notes: notes.trim(),
      status: "submitted"
    }

    const currentDayData = props.finalPortal[selectedDate] || {
      date: selectedDate,
      submissions: [],
      completionStatus: "incomplete" as const,
      requiredRoles: ["Technician", "QA", "Supervisor"] as SubmissionRole[]
    }

    const updatedSubmissions = [...currentDayData.submissions, newSubmission]
    
    const requiredRoles = currentDayData.requiredRoles
    const latestSubmissions = getLatestSubmissionPerRole(updatedSubmissions)
    const completedRoles = new Set(latestSubmissions.filter(s => s.status === "submitted").map(s => s.role))
    const allRequiredSubmitted = requiredRoles.every(r => completedRoles.has(r))
    const hasReopened = latestSubmissions.some(s => s.status === "reopened")

    const updatedDayData: DailySubmissions = {
      ...currentDayData,
      submissions: updatedSubmissions,
      completionStatus: hasReopened ? "reopened" : (allRequiredSubmitted ? "complete" : "incomplete")
    }

    const updatedPortal = {
      ...props.finalPortal,
      [selectedDate]: updatedDayData
    }

    props.setFinalPortal(updatedPortal)
    
    setSubmittedBy("")
    setCrew("")
    setNotes("")
    setSelectedRole(null)
    
    alert(`Submission successful! Your ${selectedRole} logs for ${selectedDate} have been finalized.`)
  }

  const handleReopen = (date: string, submissionId: string, reopenedBy: string, reason: string) => {
    const dayData = props.finalPortal[date]
    if (!dayData) return

    const updatedSubmissions = dayData.submissions.map(s => {
      if (s.id === submissionId) {
        return {
          ...s,
          status: "reopened" as const,
          reopenHistory: [
            ...(s.reopenHistory || []),
            {
              reopenedAt: new Date().toISOString(),
              reopenedBy,
              reason
            }
          ]
        }
      }
      return s
    })

    const latestSubmissions = getLatestSubmissionPerRole(updatedSubmissions)
    const requiredRoles = dayData.requiredRoles
    const completedRoles = new Set(latestSubmissions.filter(s => s.status === "submitted").map(s => s.role))
    const allRequiredSubmitted = requiredRoles.every(r => completedRoles.has(r))
    const hasReopened = latestSubmissions.some(s => s.status === "reopened")

    const updatedDayData: DailySubmissions = {
      ...dayData,
      submissions: updatedSubmissions,
      completionStatus: hasReopened ? "reopened" : (allRequiredSubmitted ? "complete" : "incomplete")
    }

    props.setFinalPortal({
      ...props.finalPortal,
      [date]: updatedDayData
    })
  }

  const getAllSubmissionDates = (): string[] => {
    return Object.keys(props.finalPortal).sort().reverse()
  }

  return (
    <Card className="shadow-sm bg-card">
      <CardHeader>
        <CardTitle>Final Joint Portal - End of Day Submissions</CardTitle>
        <CardDescription>
          Role-based log submission system for daily completion tracking and quality assurance
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-6 border-b pb-4">
          <Button
            onClick={() => setViewTab("submit")}
            variant={viewTab === "submit" ? "default" : "outline"}
            className={viewTab === "submit" ? "bg-primary text-primary-foreground" : ""}
          >
            Submit Logs
          </Button>
          <Button
            onClick={() => setViewTab("supervisor")}
            variant={viewTab === "supervisor" ? "default" : "outline"}
            className={viewTab === "supervisor" ? "bg-primary text-primary-foreground" : ""}
          >
            Supervisor Dashboard
          </Button>
          <Button
            onClick={() => setViewTab("history")}
            variant={viewTab === "history" ? "default" : "outline"}
            className={viewTab === "history" ? "bg-primary text-primary-foreground" : ""}
          >
            Submission History
          </Button>
        </div>

        {viewTab === "submit" && (
          <div className="space-y-6">
            <div className="bg-muted/30 p-4 rounded-lg border border-border">
              <Label className="text-base font-semibold mb-3 block">Select Date</Label>
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full sm:max-w-xs"
              />
              {selectedDate === getTodayDate() && (
                <p className="text-sm text-muted-foreground mt-2">Today's submissions</p>
              )}
            </div>

            <div className="bg-muted/30 p-4 rounded-lg border border-border">
              <Label className="text-base font-semibold mb-3 block">Select Your Role</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 tablet:grid-cols-3 lg:grid-cols-3 gap-3 sm:gap-4">
                {(Object.keys(ROLE_LOG_MAP) as SubmissionRole[]).map((role) => {
                  const isSubmitted = hasRoleSubmitted(selectedDate, role)
                  return (
                    <button
                      key={role}
                      onClick={() => !isSubmitted && setSelectedRole(role)}
                      disabled={isSubmitted}
                      className={`p-4 rounded-lg border-2 text-left transition-all ${
                        selectedRole === role
                          ? "border-primary bg-primary/10"
                          : isSubmitted
                          ? "border-border bg-muted/50 opacity-50 cursor-not-allowed"
                          : "border-border hover:border-primary/50 hover:bg-muted/50 cursor-pointer"
                      }`}
                    >
                      <div className="font-semibold mb-1">{role}</div>
                      <div className="text-xs text-muted-foreground">
                        {ROLE_LOG_MAP[role].description}
                      </div>
                      {isSubmitted && (
                        <div className="mt-2 text-xs text-primary font-medium">✓ Already submitted</div>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>

            {selectedRole && (
              <div className="bg-muted/30 p-4 rounded-lg border border-border space-y-4">
                <h3 className="text-lg font-semibold">Submission Details - {selectedRole}</h3>
                <p className="text-sm text-muted-foreground">{ROLE_LOG_MAP[selectedRole].description}</p>

                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <Label htmlFor="submittedBy">Your Name *</Label>
                    <Input
                      id="submittedBy"
                      value={submittedBy}
                      onChange={(e) => setSubmittedBy(e.target.value)}
                      placeholder="Enter your full name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="crew">Crew/Team (Optional)</Label>
                    <Input
                      id="crew"
                      value={crew}
                      onChange={(e) => setCrew(e.target.value)}
                      placeholder="Crew name or team identifier"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Logs to be Submitted</Label>
                    <div className="bg-card p-3 rounded border border-border space-y-2">
                      {ROLE_LOG_MAP[selectedRole].logTypes.map(logType => {
                        const count = getLogsByType(logType).length
                        return (
                          <div key={logType} className="flex justify-between items-center text-sm">
                            <span>{getLogTypeLabel(logType)}</span>
                            <span className={`font-mono ${count > 0 ? "text-primary" : "text-muted-foreground"}`}>
                              {count} {count === 1 ? "entry" : "entries"}
                            </span>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Any additional notes or comments for this submission..."
                      rows={3}
                    />
                  </div>

                  <Button
                    onClick={handleSubmit}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    size="lg"
                  >
                    Finalize & Submit {selectedRole} Logs
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {viewTab === "history" && (
          <div className="space-y-6">
            <div className="bg-muted/30 p-4 rounded-lg border border-border">
              <h3 className="text-lg font-semibold mb-3">Submission History</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Complete audit trail of all daily submissions across all dates
              </p>

              {getAllSubmissionDates().length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No submissions recorded yet. Start by submitting logs for today.
                </div>
              ) : (
                <div className="space-y-4">
                  {getAllSubmissionDates().map(date => {
                    const dayData = props.finalPortal[date]
                    if (!dayData) return null

                    return (
                      <div key={date} className="bg-card p-4 rounded-lg border border-border">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-base">
                              {new Date(date).toLocaleDateString('en-US', { 
                                weekday: 'long', 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric' 
                              })}
                            </h4>
                            <p className="text-xs text-muted-foreground">
                              {dayData.submissions.length} submission{dayData.submissions.length !== 1 ? 's' : ''}
                            </p>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                            dayData.completionStatus === "complete" 
                              ? "bg-green-500/20 text-green-700 dark:text-green-400"
                              : dayData.completionStatus === "reopened"
                              ? "bg-orange-500/20 text-orange-700 dark:text-orange-400"
                              : "bg-yellow-500/20 text-yellow-700 dark:text-yellow-400"
                          }`}>
                            {dayData.completionStatus === "complete" ? "✓ Complete" : 
                             dayData.completionStatus === "reopened" ? "↻ Reopened" : "⚠ Incomplete"}
                          </div>
                        </div>

                        <div className="hidden md:block overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b border-border">
                                <th className="text-left py-2 px-2 font-medium">Role</th>
                                <th className="text-left py-2 px-2 font-medium">Submitted By</th>
                                <th className="text-left py-2 px-2 font-medium">Crew</th>
                                <th className="text-left py-2 px-2 font-medium">Timestamp</th>
                                <th className="text-left py-2 px-2 font-medium">Logs Count</th>
                                <th className="text-left py-2 px-2 font-medium">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              {dayData.submissions.map(submission => (
                                <tr key={submission.id} className="border-b border-border/50">
                                  <td className="py-2 px-2 font-medium">{submission.role}</td>
                                  <td className="py-2 px-2">{submission.submittedBy}</td>
                                  <td className="py-2 px-2 text-muted-foreground">{submission.crew || "-"}</td>
                                  <td className="py-2 px-2 text-muted-foreground">
                                    {new Date(submission.timestamp).toLocaleString()}
                                  </td>
                                  <td className="py-2 px-2">
                                    {submission.logSnapshots.reduce((sum, snap) => sum + snap.count, 0)} entries
                                  </td>
                                  <td className="py-2 px-2">
                                    <span className={`px-2 py-1 rounded text-xs ${
                                      submission.status === "submitted" 
                                        ? "bg-primary/20 text-primary" 
                                        : "bg-accent/20 text-accent"
                                    }`}>
                                      {submission.status}
                                    </span>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        <div className="md:hidden space-y-3">
                          {dayData.submissions.map(submission => (
                            <div key={submission.id} className="bg-muted/20 p-3 rounded border border-border/50">
                              <div className="flex items-start justify-between mb-2">
                                <div>
                                  <div className="font-semibold text-sm">{submission.role}</div>
                                  <div className="text-xs text-muted-foreground">{submission.submittedBy}</div>
                                </div>
                                <span className={`px-2 py-1 rounded text-xs font-medium ${
                                  submission.status === "submitted" 
                                    ? "bg-primary/20 text-primary" 
                                    : "bg-accent/20 text-accent"
                                }`}>
                                  {submission.status}
                                </span>
                              </div>
                              <div className="space-y-1 text-xs">
                                {submission.crew && (
                                  <div className="flex justify-between">
                                    <span className="text-muted-foreground">Crew:</span>
                                    <span>{submission.crew}</span>
                                  </div>
                                )}
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Time:</span>
                                  <span>{new Date(submission.timestamp).toLocaleTimeString()}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Logs:</span>
                                  <span>{submission.logSnapshots.reduce((sum, snap) => sum + snap.count, 0)} entries</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

interface AsBuiltDrawingProps {
  asBuiltData: AsBuiltData
  setAsBuiltData: (data: AsBuiltData) => void
  materialInventory?: MaterialInventory
  onPlacePanel?: (rollId: string, lengthM: number) => PanelPlacement | null
  getActiveRolls?: () => MaterialRoll[]
}

function AsBuiltDrawing({ asBuiltData, setAsBuiltData, materialInventory, onPlacePanel, getActiveRolls }: AsBuiltDrawingProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [tool, setTool] = useState<'select' | 'line' | 'curve' | 'rectangle' | 'rounded-rectangle' | 'structure' | 'text' | 'measure' | 'gps-marker' | 'eraser-click' | 'eraser-box' | 'copy-last' | 'panel'>('select')
  const [selectedRollId, setSelectedRollId] = useState<string>('')
  const [panelLength, setPanelLength] = useState<string>('')
  const [color, setColor] = useState('#FFFFFF')
  const [lineWeight, setLineWeight] = useState(2)
  const [lineType, setLineType] = useState<number[]>([])
  const [isDrawing, setIsDrawing] = useState(false)
  const [startPos, setStartPos] = useState({ x: 0, y: 0 })
  const [curveControlPoint, setCurveControlPoint] = useState<{x: number, y: number} | null>(null)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })
  const [showGrid, setShowGrid] = useState(true)
  const [snapEnabled, setSnapEnabled] = useState(false)
  const [history, setHistory] = useState<AsBuiltData[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [gpsCoords, setGpsCoords] = useState<{lat: number, lon: number} | null>(null)
  const [measureStart, setMeasureStart] = useState<{x: number, y: number} | null>(null)
  const [measureDistance, setMeasureDistance] = useState<number | null>(null)
  const [zoom, setZoom] = useState(1.0)
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 })
  const [isPanning, setIsPanning] = useState(false)
  const [panMode, setPanMode] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [cornerRadius, setCornerRadius] = useState(20)
  const [hoveredObject, setHoveredObject] = useState<{layerId: number, index: number} | null>(null)
  const [fullscreenMenuOpen, setFullscreenMenuOpen] = useState(false)
  const [lastPinchDistance, setLastPinchDistance] = useState<number | null>(null)
  const [selectedObject, setSelectedObject] = useState<{layerId: number, index: number} | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [showObjectDetails, setShowObjectDetails] = useState(false)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const container = canvas.parentElement
    if (container) {
      canvas.width = container.clientWidth
      canvas.height = isFullscreen ? window.innerHeight : 600
    }
    
    redrawCanvas()
  }, [asBuiltData, zoom, panOffset, showGrid, isFullscreen, selectedObject])

  useEffect(() => {
    const handleResize = () => {
      const canvas = canvasRef.current
      if (!canvas) return
      const container = canvas.parentElement
      if (container) {
        canvas.width = container.clientWidth
        canvas.height = isFullscreen ? window.innerHeight : 600
        redrawCanvas()
      }
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [isFullscreen])

  const toggleFullscreen = () => {
    const container = containerRef.current
    if (!container) return
    
    if (!isFullscreen) {
      if (container.requestFullscreen) {
        container.requestFullscreen()
      }
      setIsFullscreen(true)
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
      setIsFullscreen(false)
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false)
      }
    }
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange)
  }, [])

  const screenToCanvas = (screenX: number, screenY: number) => {
    return {
      x: (screenX - panOffset.x) / zoom,
      y: (screenY - panOffset.y) / zoom
    }
  }

  const snapToGrid = (point: {x: number, y: number}): {x: number, y: number} => {
    if (!snapEnabled) return point
    const gridSize = 40
    return {
      x: Math.round(point.x / gridSize) * gridSize,
      y: Math.round(point.y / gridSize) * gridSize
    }
  }

  const redrawCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    ctx.save()
    ctx.fillStyle = '#1a2332'
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    ctx.translate(panOffset.x, panOffset.y)
    ctx.scale(zoom, zoom)

    if (showGrid) {
      const gridSize = 40
      const startX = Math.floor(-panOffset.x / zoom / gridSize) * gridSize
      const endX = Math.ceil((canvas.width - panOffset.x) / zoom / gridSize) * gridSize
      const startY = Math.floor(-panOffset.y / zoom / gridSize) * gridSize
      const endY = Math.ceil((canvas.height - panOffset.y) / zoom / gridSize) * gridSize
      
      for (let x = startX; x <= endX; x += gridSize) {
        ctx.strokeStyle = x % (gridSize * 2) === 0 ? '#3d4f66' : '#2d3d52'
        ctx.lineWidth = (x % (gridSize * 2) === 0 ? 1 : 0.5) / zoom
        ctx.beginPath()
        ctx.moveTo(x, startY)
        ctx.lineTo(x, endY)
        ctx.stroke()
      }
      for (let y = startY; y <= endY; y += gridSize) {
        ctx.strokeStyle = y % (gridSize * 2) === 0 ? '#3d4f66' : '#2d3d52'
        ctx.lineWidth = (y % (gridSize * 2) === 0 ? 1 : 0.5) / zoom
        ctx.beginPath()
        ctx.moveTo(startX, y)
        ctx.lineTo(endX, y)
        ctx.stroke()
      }
    }

    asBuiltData.layers.filter(l => l.isVisible).forEach(layer => {
      layer.objects.forEach((obj, index) => {
        const isHovered = (hoveredObject !== null && layer.id === hoveredObject.layerId && index === hoveredObject.index && (tool === 'eraser-click' || tool === 'select'))
        const isSelected = (selectedObject !== null && layer.id === selectedObject.layerId && index === selectedObject.index && tool === 'select')
        
        ctx.strokeStyle = obj.color
        ctx.fillStyle = obj.color
        ctx.lineWidth = obj.weight
        ctx.setLineDash(obj.lineType || [])

        if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
          ctx.beginPath()
          ctx.moveTo(obj.x1, obj.y1)
          ctx.lineTo(obj.x2, obj.y2)
          ctx.stroke()
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = obj.weight + 4
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.moveTo(obj.x1, obj.y1)
            ctx.lineTo(obj.x2, obj.y2)
            ctx.stroke()
          }
        } else if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
          ctx.beginPath()
          ctx.moveTo(obj.p0.x, obj.p0.y)
          ctx.quadraticCurveTo(obj.p1.x, obj.p1.y, obj.p2.x, obj.p2.y)
          ctx.stroke()
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = obj.weight + 4
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.moveTo(obj.p0.x, obj.p0.y)
            ctx.quadraticCurveTo(obj.p1.x, obj.p1.y, obj.p2.x, obj.p2.y)
            ctx.stroke()
          }
        } else if (obj.type === 'rectangle' && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
          const cx = obj.x + obj.w / 2
          const cy = obj.y + obj.h / 2
          const rotation = (obj.rotation || 0) * Math.PI / 180
          
          ctx.save()
          ctx.translate(cx, cy)
          ctx.rotate(rotation)
          ctx.translate(-cx, -cy)
          
          ctx.beginPath()
          ctx.rect(obj.x, obj.y, obj.w, obj.h)
          ctx.stroke()
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = 3
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.rect(obj.x - 5, obj.y - 5, obj.w + 10, obj.h + 10)
            ctx.stroke()
          }
          ctx.restore()
        } else if (obj.type === 'rounded-rectangle' && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
          const radius = obj.cornerRadius || 20
          const cx = obj.x + obj.w / 2
          const cy = obj.y + obj.h / 2
          const rotation = (obj.rotation || 0) * Math.PI / 180
          
          ctx.save()
          ctx.translate(cx, cy)
          ctx.rotate(rotation)
          ctx.translate(-cx, -cy)
          
          ctx.beginPath()
          ctx.roundRect(obj.x, obj.y, obj.w, obj.h, radius)
          ctx.stroke()
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = 3
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.roundRect(obj.x - 5, obj.y - 5, obj.w + 10, obj.h + 10, radius + 5)
            ctx.stroke()
          }
          ctx.restore()
        } else if (obj.type === 'structure' && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
          const cx = obj.x + obj.w / 2
          const cy = obj.y + obj.h / 2
          const rotation = (obj.rotation || 0) * Math.PI / 180
          
          ctx.save()
          ctx.translate(cx, cy)
          ctx.rotate(rotation)
          ctx.translate(-cx, -cy)
          
          ctx.globalAlpha = 0.3
          ctx.fillRect(obj.x, obj.y, obj.w, obj.h)
          ctx.globalAlpha = 1.0
          ctx.strokeRect(obj.x, obj.y, obj.w, obj.h)
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = 3
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.rect(obj.x - 5, obj.y - 5, obj.w + 10, obj.h + 10)
            ctx.stroke()
          }
          ctx.restore()
        } else if (obj.type === 'text' && obj.x !== undefined && obj.y !== undefined && obj.text) {
          const rotation = (obj.rotation || 0) * Math.PI / 180
          
          ctx.save()
          ctx.translate(obj.x, obj.y)
          ctx.rotate(rotation)
          ctx.translate(-obj.x, -obj.y)
          
          ctx.font = '16px Inter, sans-serif'
          ctx.fillText(obj.text, obj.x, obj.y)
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = 2
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.rect(obj.x - 5, obj.y - 20, 100, 30)
            ctx.stroke()
          }
          ctx.restore()
        } else if (obj.type === 'gps-marker' && obj.x !== undefined && obj.y !== undefined) {
          ctx.beginPath()
          ctx.arc(obj.x, obj.y, 8, 0, Math.PI * 2)
          ctx.fill()
          ctx.strokeStyle = '#FFFFFF'
          ctx.lineWidth = 2
          ctx.stroke()
          if (obj.lat && obj.lon) {
            ctx.font = '11px Inter, sans-serif'
            ctx.fillStyle = '#FFFFFF'
            ctx.fillText(`${obj.lat.toFixed(6)}, ${obj.lon.toFixed(6)}`, obj.x + 12, obj.y + 4)
          }
          
          if (isHovered || isSelected) {
            ctx.strokeStyle = isSelected ? '#00ccff' : '#ff0000'
            ctx.lineWidth = 3
            ctx.setLineDash([])
            ctx.beginPath()
            ctx.arc(obj.x, obj.y, 15, 0, Math.PI * 2)
            ctx.stroke()
          }
        }
      })
    })

    ctx.setLineDash([])
    ctx.restore()
  }

  const saveToHistory = (data: AsBuiltData) => {
    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(JSON.parse(JSON.stringify(data)))
    if (newHistory.length > 50) newHistory.shift()
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)
  }

  const addObject = (obj: AsBuiltObject) => {
    const updatedLayers = asBuiltData.layers.map(layer => {
      if (layer.id === asBuiltData.activeLayerId) {
        return { ...layer, objects: [...layer.objects, obj] }
      }
      return layer
    })
    const newData = { ...asBuiltData, layers: updatedLayers }
    setAsBuiltData(newData)
    saveToHistory(newData)
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const screenX = e.clientX - rect.left
    const screenY = e.clientY - rect.top
    const rawCoords = screenToCanvas(screenX, screenY)
    
    if ((tool === 'select' && e.shiftKey) || panMode) {
      setIsPanning(true)
      setStartPos({ x: screenX, y: screenY })
      return
    }

    const isDrawingTool = ['line', 'curve', 'rectangle', 'rounded-rectangle', 'structure', 'measure'].includes(tool)
    const canvasCoords = (snapEnabled && isDrawingTool) ? snapToGrid(rawCoords) : rawCoords

    if (tool === 'select') {
      const foundObject = findObjectAtPointAcrossLayers(canvasCoords.x, canvasCoords.y)
      if (foundObject) {
        setSelectedObject(foundObject)
        setIsDragging(true)
        setDragOffset({ x: canvasCoords.x, y: canvasCoords.y })
        setStartPos(canvasCoords)
      } else {
        setSelectedObject(null)
      }
      redrawCanvas()
      return
    }

    if (!(tool === 'curve' && curveControlPoint)) {
      setStartPos(canvasCoords)
    }
    
    setIsDrawing(true)

    if (tool === 'text') {
      const text = prompt('Enter label text:')
      if (text) {
        addObject({
          type: 'text',
          text,
          x: canvasCoords.x,
          y: canvasCoords.y,
          color,
          weight: 1,
          lineType
        })
      }
      setIsDrawing(false)
    } else if (tool === 'gps-marker') {
      if (gpsCoords) {
        addObject({
          type: 'gps-marker',
          x: canvasCoords.x,
          y: canvasCoords.y,
          lat: gpsCoords.lat,
          lon: gpsCoords.lon,
          color,
          weight: lineWeight,
          lineType: []
        })
      } else {
        alert('GPS location not available. Enable location in your browser.')
      }
      setIsDrawing(false)
    } else if (tool === 'panel') {
      if (selectedRollId && panelLength && onPlacePanel && getActiveRolls) {
        const roll = getActiveRolls().find(r => r.id === selectedRollId)
        if (roll) {
          const length = parseFloat(panelLength)
          if (length > 0 && length <= roll.remainingLengthM) {
            const placement = onPlacePanel(selectedRollId, length)
            if (placement) {
              const scaleFactor = 20
              addObject({
                type: 'rectangle',
                x: canvasCoords.x,
                y: canvasCoords.y,
                w: length * scaleFactor,
                h: roll.widthM * scaleFactor,
                color: '#4A90D9',
                weight: 2,
                lineType: [],
                panelId: placement.panelNumber,
                layerType: 'Primary',
                membraneType: roll.materialType
              })
              setPanelLength('')
            }
          } else {
            alert(`Not enough material on roll. Available: ${roll.remainingLengthM.toFixed(1)}m`)
          }
        }
      } else if (!selectedRollId) {
        alert('Please select an active roll first.')
      } else if (!panelLength) {
        alert('Please enter a panel length.')
      }
      setIsDrawing(false)
    } else if (tool === 'eraser-click') {
      deleteClickedObject(canvasCoords.x, canvasCoords.y)
      setIsDrawing(false)
    } else if (tool === 'measure') {
      setMeasureStart(canvasCoords)
    } else if (tool === 'copy-last') {
      copyLastObject(canvasCoords.x, canvasCoords.y)
      setIsDrawing(false)
    }
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const screenX = e.clientX - rect.left
    const screenY = e.clientY - rect.top
    const rawCoords = screenToCanvas(screenX, screenY)
    setMousePos(rawCoords)

    const isDrawingTool = ['line', 'curve', 'rectangle', 'structure', 'measure'].includes(tool)
    const canvasCoords = (snapEnabled && isDrawingTool && isDrawing) ? snapToGrid(rawCoords) : rawCoords

    if (isPanning) {
      const dx = screenX - startPos.x
      const dy = screenY - startPos.y
      setPanOffset({ x: panOffset.x + dx, y: panOffset.y + dy })
      setStartPos({ x: screenX, y: screenY })
      redrawCanvas()
      return
    }

    if (tool === 'select' && isDragging && selectedObject) {
      const dx = canvasCoords.x - startPos.x
      const dy = canvasCoords.y - startPos.y
      
      const activeLayer = asBuiltData.layers.find(l => l.id === selectedObject.layerId)
      if (activeLayer && activeLayer.objects[selectedObject.index]) {
        const obj = activeLayer.objects[selectedObject.index]
        const updatedObj = { ...obj }
        
        if (updatedObj.x1 !== undefined) updatedObj.x1 += dx
        if (updatedObj.y1 !== undefined) updatedObj.y1 += dy
        if (updatedObj.x2 !== undefined) updatedObj.x2 += dx
        if (updatedObj.y2 !== undefined) updatedObj.y2 += dy
        if (updatedObj.x !== undefined) updatedObj.x += dx
        if (updatedObj.y !== undefined) updatedObj.y += dy
        if (updatedObj.p0) updatedObj.p0 = { x: updatedObj.p0.x + dx, y: updatedObj.p0.y + dy }
        if (updatedObj.p1) updatedObj.p1 = { x: updatedObj.p1.x + dx, y: updatedObj.p1.y + dy }
        if (updatedObj.p2) updatedObj.p2 = { x: updatedObj.p2.x + dx, y: updatedObj.p2.y + dy }
        
        const updatedLayers = asBuiltData.layers.map(layer => {
          if (layer.id === selectedObject.layerId) {
            const newObjects = [...layer.objects]
            newObjects[selectedObject.index] = updatedObj
            return { ...layer, objects: newObjects }
          }
          return layer
        })
        
        setAsBuiltData({ ...asBuiltData, layers: updatedLayers })
        setStartPos(canvasCoords)
      }
      return
    }

    if (tool === 'eraser-click' || tool === 'select') {
      const foundObject = findObjectAtPointAcrossLayers(canvasCoords.x, canvasCoords.y)
      if (foundObject) {
        setHoveredObject(foundObject)
      } else {
        setHoveredObject(null)
      }
      redrawCanvas()
    } else {
      if (hoveredObject !== null) {
        setHoveredObject(null)
        redrawCanvas()
      }
    }

    if (tool === 'measure' && measureStart) {
      const dist = Math.sqrt(Math.pow(canvasCoords.x - measureStart.x, 2) + Math.pow(canvasCoords.y - measureStart.y, 2))
      setMeasureDistance(dist)
    }

    if (!isDrawing || tool === 'text' || tool === 'gps-marker' || tool === 'eraser-click' || tool === 'copy-last') return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    redrawCanvas()
    
    ctx.save()
    ctx.translate(panOffset.x, panOffset.y)
    ctx.scale(zoom, zoom)

    ctx.strokeStyle = color
    ctx.lineWidth = lineWeight
    ctx.setLineDash(lineType)

    if (tool === 'line') {
      ctx.beginPath()
      ctx.moveTo(startPos.x, startPos.y)
      ctx.lineTo(canvasCoords.x, canvasCoords.y)
      ctx.stroke()
    } else if (tool === 'curve') {
      if (curveControlPoint) {
        ctx.beginPath()
        ctx.moveTo(startPos.x, startPos.y)
        ctx.quadraticCurveTo(curveControlPoint.x, curveControlPoint.y, canvasCoords.x, canvasCoords.y)
        ctx.stroke()
      }
    } else if (tool === 'rectangle') {
      ctx.strokeRect(startPos.x, startPos.y, canvasCoords.x - startPos.x, canvasCoords.y - startPos.y)
    } else if (tool === 'rounded-rectangle') {
      ctx.beginPath()
      ctx.roundRect(startPos.x, startPos.y, canvasCoords.x - startPos.x, canvasCoords.y - startPos.y, cornerRadius)
      ctx.stroke()
    } else if (tool === 'structure') {
      ctx.globalAlpha = 0.3
      ctx.fillRect(startPos.x, startPos.y, canvasCoords.x - startPos.x, canvasCoords.y - startPos.y)
      ctx.globalAlpha = 1.0
      ctx.strokeRect(startPos.x, startPos.y, canvasCoords.x - startPos.x, canvasCoords.y - startPos.y)
    } else if (tool === 'eraser-box') {
      ctx.strokeStyle = '#ff0000'
      ctx.setLineDash([5, 5])
      ctx.strokeRect(startPos.x, startPos.y, canvasCoords.x - startPos.x, canvasCoords.y - startPos.y)
    } else if (tool === 'measure') {
      ctx.setLineDash([])
      ctx.strokeStyle = '#10b981'
      ctx.beginPath()
      ctx.moveTo(startPos.x, startPos.y)
      ctx.lineTo(canvasCoords.x, canvasCoords.y)
      ctx.stroke()
    }

    ctx.setLineDash([])
    ctx.restore()
  }

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isPanning) {
      setIsPanning(false)
      return
    }
    
    if (tool === 'select' && isDragging) {
      setIsDragging(false)
      saveToHistory(asBuiltData)
      return
    }
    
    if (!isDrawing || tool === 'text' || tool === 'gps-marker' || tool === 'eraser-click' || tool === 'copy-last') {
      return
    }
    const canvas = canvasRef.current
    if (!canvas) return
    const rect = canvas.getBoundingClientRect()
    const screenX = e.clientX - rect.left
    const screenY = e.clientY - rect.top
    const rawCoords = screenToCanvas(screenX, screenY)
    
    const isDrawingTool = ['line', 'curve', 'rectangle', 'rounded-rectangle', 'structure', 'measure'].includes(tool)
    const canvasCoords = (snapEnabled && isDrawingTool) ? snapToGrid(rawCoords) : rawCoords
    
    if (tool === 'line') {
      addObject({
        type: 'line',
        x1: startPos.x,
        y1: startPos.y,
        x2: canvasCoords.x,
        y2: canvasCoords.y,
        color,
        weight: lineWeight,
        lineType
      })
    } else if (tool === 'curve') {
      if (!curveControlPoint) {
        setCurveControlPoint(canvasCoords)
        setIsDrawing(false)
        return
      } else {
        addObject({
          type: 'curve',
          p0: startPos,
          p1: curveControlPoint,
          p2: canvasCoords,
          color,
          weight: lineWeight,
          lineType
        })
        setCurveControlPoint(null)
      }
    } else if (tool === 'rectangle') {
      addObject({
        type: 'rectangle',
        x: Math.min(startPos.x, canvasCoords.x),
        y: Math.min(startPos.y, canvasCoords.y),
        w: Math.abs(canvasCoords.x - startPos.x),
        h: Math.abs(canvasCoords.y - startPos.y),
        color,
        weight: lineWeight,
        lineType
      })
    } else if (tool === 'rounded-rectangle') {
      addObject({
        type: 'rounded-rectangle',
        x: Math.min(startPos.x, canvasCoords.x),
        y: Math.min(startPos.y, canvasCoords.y),
        w: Math.abs(canvasCoords.x - startPos.x),
        h: Math.abs(canvasCoords.y - startPos.y),
        cornerRadius,
        color,
        weight: lineWeight,
        lineType
      })
    } else if (tool === 'structure') {
      addObject({
        type: 'structure',
        x: Math.min(startPos.x, canvasCoords.x),
        y: Math.min(startPos.y, canvasCoords.y),
        w: Math.abs(canvasCoords.x - startPos.x),
        h: Math.abs(canvasCoords.y - startPos.y),
        color,
        weight: lineWeight,
        lineType
      })
    } else if (tool === 'eraser-box') {
      deleteInBox(startPos.x, startPos.y, canvasCoords.x, canvasCoords.y)
      setTimeout(() => redrawCanvas(), 10)
    } else if (tool === 'measure') {
      setMeasureStart(null)
      setMeasureDistance(null)
    }

    setIsDrawing(false)
  }

  // Touch event handlers for mobile/tablet support with pinch-to-zoom
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    
    if (e.touches.length === 2) {
      const touch1 = e.touches[0]
      const touch2 = e.touches[1]
      const distance = Math.sqrt(
        Math.pow(touch2.clientX - touch1.clientX, 2) + 
        Math.pow(touch2.clientY - touch1.clientY, 2)
      )
      setLastPinchDistance(distance)
      return
    }
    
    const touch = e.touches[0]
    const mouseEvent = {
      clientX: touch.clientX,
      clientY: touch.clientY,
      shiftKey: false
    } as React.MouseEvent<HTMLCanvasElement>
    
    handleMouseDown(mouseEvent)
  }

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    const canvas = canvasRef.current
    if (!canvas) return
    
    if (e.touches.length === 2 && lastPinchDistance !== null) {
      const touch1 = e.touches[0]
      const touch2 = e.touches[1]
      const newDistance = Math.sqrt(
        Math.pow(touch2.clientX - touch1.clientX, 2) + 
        Math.pow(touch2.clientY - touch1.clientY, 2)
      )
      
      const rect = canvas.getBoundingClientRect()
      const centerX = (touch1.clientX + touch2.clientX) / 2 - rect.left
      const centerY = (touch1.clientY + touch2.clientY) / 2 - rect.top
      
      const scale = newDistance / lastPinchDistance
      const newZoom = Math.max(0.1, Math.min(5, zoom * scale))
      
      const worldPosX = (centerX - panOffset.x) / zoom
      const worldPosY = (centerY - panOffset.y) / zoom
      const newPanX = centerX - worldPosX * newZoom
      const newPanY = centerY - worldPosY * newZoom
      
      setZoom(newZoom)
      setPanOffset({ x: newPanX, y: newPanY })
      setLastPinchDistance(newDistance)
      return
    }
    
    const touch = e.touches[0]
    const mouseEvent = {
      clientX: touch.clientX,
      clientY: touch.clientY
    } as React.MouseEvent<HTMLCanvasElement>
    
    handleMouseMove(mouseEvent)
  }

  const handleTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    
    if (e.touches.length < 2) {
      setLastPinchDistance(null)
    }
    
    if (e.changedTouches.length === 0) return
    
    const touch = e.changedTouches[0]
    const canvas = canvasRef.current
    if (!canvas) return
    
    const mouseEvent = {
      clientX: touch.clientX,
      clientY: touch.clientY
    } as React.MouseEvent<HTMLCanvasElement>
    
    handleMouseUp(mouseEvent)
  }

  const findObjectAtPoint = (x: number, y: number): number => {
    const activeLayer = asBuiltData.layers.find(l => l.id === asBuiltData.activeLayerId)
    if (!activeLayer) return -1
    
    const hitRadius = 20
    
    for (let i = activeLayer.objects.length - 1; i >= 0; i--) {
      const obj = activeLayer.objects[i]
      if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
        const dist = pointToLineDistance(x, y, obj.x1, obj.y1, obj.x2, obj.y2)
        if (dist < hitRadius) return i
      } else if ((obj.type === 'rectangle' || obj.type === 'rounded-rectangle' || obj.type === 'structure') && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
        const rectLeft = Math.min(obj.x, obj.x + obj.w)
        const rectRight = Math.max(obj.x, obj.x + obj.w)
        const rectTop = Math.min(obj.y, obj.y + obj.h)
        const rectBottom = Math.max(obj.y, obj.y + obj.h)
        if (x >= rectLeft && x <= rectRight && y >= rectTop && y <= rectBottom) return i
      } else if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
        for (let t = 0; t <= 1; t += 0.05) {
          const curveX = Math.pow(1-t, 2) * obj.p0.x + 2 * (1-t) * t * obj.p1.x + Math.pow(t, 2) * obj.p2.x
          const curveY = Math.pow(1-t, 2) * obj.p0.y + 2 * (1-t) * t * obj.p1.y + Math.pow(t, 2) * obj.p2.y
          const dist = Math.sqrt(Math.pow(x - curveX, 2) + Math.pow(y - curveY, 2))
          if (dist < hitRadius) return i
        }
      } else if (obj.type === 'text' && obj.x !== undefined && obj.y !== undefined) {
        if (Math.abs(x - obj.x) < 50 && Math.abs(y - obj.y) < 20) return i
      } else if (obj.type === 'gps-marker' && obj.x !== undefined && obj.y !== undefined) {
        const dist = Math.sqrt(Math.pow(x - obj.x, 2) + Math.pow(y - obj.y, 2))
        if (dist < 15) return i
      }
    }
    return -1
  }

  const findObjectAtPointAcrossLayers = (x: number, y: number): {layerId: number, index: number} | null => {
    const hitRadius = 20
    
    const visibleLayers = asBuiltData.layers.filter(l => l.isVisible).reverse()
    
    for (const layer of visibleLayers) {
      for (let i = layer.objects.length - 1; i >= 0; i--) {
        const obj = layer.objects[i]
        if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
          const dist = pointToLineDistance(x, y, obj.x1, obj.y1, obj.x2, obj.y2)
          if (dist < hitRadius) return { layerId: layer.id, index: i }
        } else if ((obj.type === 'rectangle' || obj.type === 'rounded-rectangle' || obj.type === 'structure') && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
          const rectLeft = Math.min(obj.x, obj.x + obj.w)
          const rectRight = Math.max(obj.x, obj.x + obj.w)
          const rectTop = Math.min(obj.y, obj.y + obj.h)
          const rectBottom = Math.max(obj.y, obj.y + obj.h)
          if (x >= rectLeft && x <= rectRight && y >= rectTop && y <= rectBottom) return { layerId: layer.id, index: i }
        } else if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
          for (let t = 0; t <= 1; t += 0.05) {
            const curveX = Math.pow(1-t, 2) * obj.p0.x + 2 * (1-t) * t * obj.p1.x + Math.pow(t, 2) * obj.p2.x
            const curveY = Math.pow(1-t, 2) * obj.p0.y + 2 * (1-t) * t * obj.p1.y + Math.pow(t, 2) * obj.p2.y
            const dist = Math.sqrt(Math.pow(x - curveX, 2) + Math.pow(y - curveY, 2))
            if (dist < hitRadius) return { layerId: layer.id, index: i }
          }
        } else if (obj.type === 'text' && obj.x !== undefined && obj.y !== undefined) {
          if (Math.abs(x - obj.x) < 50 && Math.abs(y - obj.y) < 20) return { layerId: layer.id, index: i }
        } else if (obj.type === 'gps-marker' && obj.x !== undefined && obj.y !== undefined) {
          const dist = Math.sqrt(Math.pow(x - obj.x, 2) + Math.pow(y - obj.y, 2))
          if (dist < 15) return { layerId: layer.id, index: i }
        }
      }
    }
    return null
  }

  const pointToLineDistance = (px: number, py: number, x1: number, y1: number, x2: number, y2: number): number => {
    const A = px - x1
    const B = py - y1
    const C = x2 - x1
    const D = y2 - y1
    const dot = A * C + B * D
    const lenSq = C * C + D * D
    let param = -1
    if (lenSq !== 0) param = dot / lenSq
    let xx, yy
    if (param < 0) {
      xx = x1
      yy = y1
    } else if (param > 1) {
      xx = x2
      yy = y2
    } else {
      xx = x1 + param * C
      yy = y1 + param * D
    }
    const dx = px - xx
    const dy = py - yy
    return Math.sqrt(dx * dx + dy * dy)
  }

  const rotateSelectedObject = (angleDegrees: number) => {
    if (!selectedObject) return
    
    const activeLayer = asBuiltData.layers.find(l => l.id === selectedObject.layerId)
    if (!activeLayer || !activeLayer.objects[selectedObject.index]) return
    
    const obj = activeLayer.objects[selectedObject.index]
    const angleRad = (angleDegrees * Math.PI) / 180
    
    const rotatePoint = (px: number, py: number, cx: number, cy: number) => {
      const cos = Math.cos(angleRad)
      const sin = Math.sin(angleRad)
      const dx = px - cx
      const dy = py - cy
      return {
        x: cx + dx * cos - dy * sin,
        y: cy + dx * sin + dy * cos
      }
    }
    
    let updatedObj = { ...obj }
    
    if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
      const cx = (obj.x1 + obj.x2) / 2
      const cy = (obj.y1 + obj.y2) / 2
      const p1 = rotatePoint(obj.x1, obj.y1, cx, cy)
      const p2 = rotatePoint(obj.x2, obj.y2, cx, cy)
      updatedObj = { ...obj, x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y }
    } else if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
      const cx = (obj.p0.x + obj.p2.x) / 2
      const cy = (obj.p0.y + obj.p2.y) / 2
      const newP0 = rotatePoint(obj.p0.x, obj.p0.y, cx, cy)
      const newP1 = rotatePoint(obj.p1.x, obj.p1.y, cx, cy)
      const newP2 = rotatePoint(obj.p2.x, obj.p2.y, cx, cy)
      updatedObj = { ...obj, p0: newP0, p1: newP1, p2: newP2 }
    } else if ((obj.type === 'rectangle' || obj.type === 'rounded-rectangle' || obj.type === 'structure') && obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
      const cx = obj.x + obj.w / 2
      const cy = obj.y + obj.h / 2
      const currentRotation = obj.rotation || 0
      updatedObj = { ...obj, rotation: currentRotation + angleDegrees }
    } else if (obj.type === 'text' && obj.x !== undefined && obj.y !== undefined) {
      const currentRotation = obj.rotation || 0
      updatedObj = { ...obj, rotation: currentRotation + angleDegrees }
    } else if (obj.type === 'gps-marker' && obj.x !== undefined && obj.y !== undefined) {
      const currentRotation = obj.rotation || 0
      updatedObj = { ...obj, rotation: currentRotation + angleDegrees }
    }
    
    const updatedLayers = asBuiltData.layers.map(layer => {
      if (layer.id === selectedObject.layerId) {
        const newObjects = [...layer.objects]
        newObjects[selectedObject.index] = updatedObj
        return { ...layer, objects: newObjects }
      }
      return layer
    })
    
    const newData = { ...asBuiltData, layers: updatedLayers }
    setAsBuiltData(newData)
    saveToHistory(newData)
  }

  const calculateLineLength = (obj: AsBuiltObject): number => {
    if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
      return Math.sqrt(Math.pow(obj.x2 - obj.x1, 2) + Math.pow(obj.y2 - obj.y1, 2))
    }
    if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
      const dx1 = obj.p1.x - obj.p0.x
      const dy1 = obj.p1.y - obj.p0.y
      const dx2 = obj.p2.x - obj.p1.x
      const dy2 = obj.p2.y - obj.p1.y
      return Math.sqrt(dx1*dx1 + dy1*dy1) + Math.sqrt(dx2*dx2 + dy2*dy2)
    }
    return 0
  }

  const updateSelectedObjectProperty = (property: keyof AsBuiltObject, value: string | number) => {
    if (!selectedObject) return
    
    const activeLayer = asBuiltData.layers.find(l => l.id === selectedObject.layerId)
    if (!activeLayer || !activeLayer.objects[selectedObject.index]) return
    
    const obj = activeLayer.objects[selectedObject.index]
    const updatedObj = { ...obj, [property]: value }
    
    const updatedLayers = asBuiltData.layers.map(layer => {
      if (layer.id === selectedObject.layerId) {
        const newObjects = [...layer.objects]
        newObjects[selectedObject.index] = updatedObj
        return { ...layer, objects: newObjects }
      }
      return layer
    })
    
    const newData = { ...asBuiltData, layers: updatedLayers }
    setAsBuiltData(newData)
    saveToHistory(newData)
  }

  const getSelectedObjectData = (): AsBuiltObject | null => {
    if (!selectedObject) return null
    const layer = asBuiltData.layers.find(l => l.id === selectedObject.layerId)
    if (!layer || !layer.objects[selectedObject.index]) return null
    return layer.objects[selectedObject.index]
  }

  // ERASER FUNCTIONS - Simple and clean
  const deleteClickedObject = (x: number, y: number) => {
    const activeLayer = asBuiltData.layers.find(l => l.id === asBuiltData.activeLayerId)
    if (!activeLayer) return

    const clickedIndex = findObjectAtPoint(x, y)
    if (clickedIndex === -1) return

    const updatedLayers = asBuiltData.layers.map(layer => {
      if (layer.id === asBuiltData.activeLayerId) {
        return {
          ...layer,
          objects: layer.objects.filter((_, i) => i !== clickedIndex)
        }
      }
      return layer
    })

    const newData = { ...asBuiltData, layers: updatedLayers }
    setAsBuiltData(newData)
    saveToHistory(newData)
  }

  const deleteInBox = (x1: number, y1: number, x2: number, y2: number) => {
    const minX = Math.min(x1, x2)
    const maxX = Math.max(x1, x2)
    const minY = Math.min(y1, y2)
    const maxY = Math.max(y1, y2)

    const isPointInBox = (px: number, py: number) => 
      px >= minX && px <= maxX && py >= minY && py <= maxY

    const clipLineToBoxExterior = (lx1: number, ly1: number, lx2: number, ly2: number): Array<{x1: number, y1: number, x2: number, y2: number}> => {
      const p1Inside = isPointInBox(lx1, ly1)
      const p2Inside = isPointInBox(lx2, ly2)

      if (p1Inside && p2Inside) {
        return []
      }

      if (!p1Inside && !p2Inside) {
        const intersections = getLineBoxIntersections(lx1, ly1, lx2, ly2, minX, minY, maxX, maxY)
        if (intersections.length < 2) {
          return [{ x1: lx1, y1: ly1, x2: lx2, y2: ly2 }]
        }
        const [int1, int2] = intersections.sort((a, b) => {
          const distA = (a.x - lx1) ** 2 + (a.y - ly1) ** 2
          const distB = (b.x - lx1) ** 2 + (b.y - ly1) ** 2
          return distA - distB
        })
        return [
          { x1: lx1, y1: ly1, x2: int1.x, y2: int1.y },
          { x1: int2.x, y1: int2.y, x2: lx2, y2: ly2 }
        ]
      }

      const intersections = getLineBoxIntersections(lx1, ly1, lx2, ly2, minX, minY, maxX, maxY)
      if (intersections.length === 0) {
        return [{ x1: lx1, y1: ly1, x2: lx2, y2: ly2 }]
      }
      const intersection = intersections[0]
      if (p1Inside) {
        return [{ x1: intersection.x, y1: intersection.y, x2: lx2, y2: ly2 }]
      } else {
        return [{ x1: lx1, y1: ly1, x2: intersection.x, y2: intersection.y }]
      }
    }

    const getLineBoxIntersections = (lx1: number, ly1: number, lx2: number, ly2: number, bMinX: number, bMinY: number, bMaxX: number, bMaxY: number): Array<{x: number, y: number}> => {
      const intersections: Array<{x: number, y: number}> = []
      const dx = lx2 - lx1
      const dy = ly2 - ly1

      const edges = [
        { x1: bMinX, y1: bMinY, x2: bMaxX, y2: bMinY },
        { x1: bMaxX, y1: bMinY, x2: bMaxX, y2: bMaxY },
        { x1: bMaxX, y1: bMaxY, x2: bMinX, y2: bMaxY },
        { x1: bMinX, y1: bMaxY, x2: bMinX, y2: bMinY }
      ]

      for (const edge of edges) {
        const edgeDx = edge.x2 - edge.x1
        const edgeDy = edge.y2 - edge.y1
        const denom = dx * edgeDy - dy * edgeDx
        if (Math.abs(denom) < 0.0001) continue

        const t = ((edge.x1 - lx1) * edgeDy - (edge.y1 - ly1) * edgeDx) / denom
        const u = ((edge.x1 - lx1) * dy - (edge.y1 - ly1) * dx) / denom

        if (t >= 0 && t <= 1 && u >= 0 && u <= 1) {
          const ix = lx1 + t * dx
          const iy = ly1 + t * dy
          const isDuplicate = intersections.some(p => Math.abs(p.x - ix) < 0.1 && Math.abs(p.y - iy) < 0.1)
          if (!isDuplicate) {
            intersections.push({ x: ix, y: iy })
          }
        }
      }
      return intersections
    }

    const updatedLayers = asBuiltData.layers.map(layer => {
      if (layer.id === asBuiltData.activeLayerId) {
        const newObjects: AsBuiltObject[] = []
        
        for (const obj of layer.objects) {
          if (obj.type === 'line' && obj.x1 !== undefined && obj.y1 !== undefined && obj.x2 !== undefined && obj.y2 !== undefined) {
            const clippedSegments = clipLineToBoxExterior(obj.x1, obj.y1, obj.x2, obj.y2)
            for (const seg of clippedSegments) {
              const segLength = Math.sqrt((seg.x2 - seg.x1) ** 2 + (seg.y2 - seg.y1) ** 2)
              if (segLength > 1) {
                newObjects.push({
                  ...obj,
                  x1: seg.x1,
                  y1: seg.y1,
                  x2: seg.x2,
                  y2: seg.y2
                })
              }
            }
          } else if ((obj.type === 'rectangle' || obj.type === 'rounded-rectangle' || obj.type === 'structure') && 
              obj.x !== undefined && obj.y !== undefined && obj.w !== undefined && obj.h !== undefined) {
            const rectLeft = obj.w >= 0 ? obj.x : obj.x + obj.w
            const rectRight = obj.w >= 0 ? obj.x + obj.w : obj.x
            const rectTop = obj.h >= 0 ? obj.y : obj.y + obj.h
            const rectBottom = obj.h >= 0 ? obj.y + obj.h : obj.y
            const fullyContained = (rectLeft >= minX && rectRight <= maxX && rectTop >= minY && rectBottom <= maxY)
            if (!fullyContained) {
              newObjects.push(obj)
            }
          } else if (obj.type === 'curve' && obj.p0 && obj.p1 && obj.p2) {
            const fullyContained = isPointInBox(obj.p0.x, obj.p0.y) &&
                                  isPointInBox(obj.p1.x, obj.p1.y) &&
                                  isPointInBox(obj.p2.x, obj.p2.y)
            if (!fullyContained) {
              newObjects.push(obj)
            }
          } else if ((obj.type === 'text' || obj.type === 'gps-marker') && obj.x !== undefined && obj.y !== undefined) {
            if (!isPointInBox(obj.x, obj.y)) {
              newObjects.push(obj)
            }
          } else {
            newObjects.push(obj)
          }
        }
        
        return { ...layer, objects: newObjects }
      }
      return layer
    })

    const newData = { ...asBuiltData, layers: updatedLayers }
    setAsBuiltData(newData)
    saveToHistory(newData)
  }

  const copyLastObject = (x: number, y: number) => {
    const activeLayer = asBuiltData.layers.find(l => l.id === asBuiltData.activeLayerId)
    if (!activeLayer || activeLayer.objects.length === 0) return
    
    const lastObj = activeLayer.objects[activeLayer.objects.length - 1]
    const offsetX = x - (lastObj.x1 || lastObj.x || 0)
    const offsetY = y - (lastObj.y1 || lastObj.y || 0)
    
    const copiedObj = JSON.parse(JSON.stringify(lastObj))
    if (copiedObj.x1 !== undefined) copiedObj.x1 += offsetX
    if (copiedObj.y1 !== undefined) copiedObj.y1 += offsetY
    if (copiedObj.x2 !== undefined) copiedObj.x2 += offsetX
    if (copiedObj.y2 !== undefined) copiedObj.y2 += offsetY
    if (copiedObj.x !== undefined) copiedObj.x += offsetX
    if (copiedObj.y !== undefined) copiedObj.y += offsetY
    if (copiedObj.p0) {
      copiedObj.p0 = { x: copiedObj.p0.x + offsetX, y: copiedObj.p0.y + offsetY }
      copiedObj.p1 = { x: copiedObj.p1.x + offsetX, y: copiedObj.p1.y + offsetY }
      copiedObj.p2 = { x: copiedObj.p2.x + offsetX, y: copiedObj.p2.y + offsetY }
    }
    
    addObject(copiedObj)
  }

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1)
      setAsBuiltData(history[historyIndex - 1])
    }
  }

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1)
      setAsBuiltData(history[historyIndex + 1])
    }
  }

  const clearCanvas = () => {
    if (confirm('Clear all drawings on this layer?')) {
      const updatedLayers = asBuiltData.layers.map(layer => {
        if (layer.id === asBuiltData.activeLayerId) {
          return { ...layer, objects: [] }
        }
        return layer
      })
      const newData = { ...asBuiltData, layers: updatedLayers }
      setAsBuiltData(newData)
      saveToHistory(newData)
    }
  }

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setGpsCoords({
            lat: position.coords.latitude,
            lon: position.coords.longitude
          })
        },
        (error) => console.log('GPS error:', error)
      )
    }
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault()
      const delta = e.deltaY > 0 ? 1 / 1.1 : 1.1
      const newZoom = Math.max(0.1, Math.min(5, zoom * delta))
      
      const rect = canvas.getBoundingClientRect()
      const mouseX = e.clientX - rect.left
      const mouseY = e.clientY - rect.top
      
      const worldPosX = (mouseX - panOffset.x) / zoom
      const worldPosY = (mouseY - panOffset.y) / zoom
      
      const newPanX = mouseX - worldPosX * newZoom
      const newPanY = mouseY - worldPosY * newZoom
      
      setZoom(newZoom)
      setPanOffset({ x: newPanX, y: newPanY })
    }

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault()
      setTool(prev => {
        if (prev === 'eraser-click') return 'eraser-box'
        if (prev === 'eraser-box') return 'select'
        return 'eraser-click'
      })
    }

    canvas.addEventListener('wheel', handleWheel, { passive: false })
    canvas.addEventListener('contextmenu', handleContextMenu)
    return () => {
      canvas.removeEventListener('wheel', handleWheel)
      canvas.removeEventListener('contextmenu', handleContextMenu)
    }
  }, [zoom, panOffset])

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'z') {
          e.preventDefault()
          undo()
        } else if (e.key === 'y') {
          e.preventDefault()
          redo()
        }
      } else {
        switch (e.key) {
          case 'F1': e.preventDefault(); setTool('select'); break
          case 'F2': e.preventDefault(); setTool('line'); break
          case 'F3': e.preventDefault(); setTool('curve'); break
          case 'F4': e.preventDefault(); setTool('rectangle'); break
          case 'F5': e.preventDefault(); setTool('structure'); break
          case 'F6': e.preventDefault(); setTool('text'); break
          case 'F7': e.preventDefault(); setTool('measure'); break
          case 'F8': e.preventDefault(); setTool('gps-marker'); break
          case 'F9': e.preventDefault(); setTool('copy-last'); break
          case 'w':
          case 'W':
            e.preventDefault()
            setZoom(Math.max(0.1, Math.min(5, zoom * 1.05)))
            break
          case 'a':
          case 'A':
            e.preventDefault()
            setZoom(Math.max(0.1, Math.min(5, zoom / 1.05)))
            break
          case 'ArrowUp':
            e.preventDefault()
            setPanOffset({ x: panOffset.x, y: panOffset.y + 20 })
            break
          case 'ArrowDown':
            e.preventDefault()
            setPanOffset({ x: panOffset.x, y: panOffset.y - 20 })
            break
          case 'ArrowLeft':
            e.preventDefault()
            setPanOffset({ x: panOffset.x + 20, y: panOffset.y })
            break
          case 'ArrowRight':
            e.preventDefault()
            setPanOffset({ x: panOffset.x - 20, y: panOffset.y })
            break
        }
        switch (e.key.toLowerCase()) {
          case 'v': setTool('select'); break
          case 'l': setTool('line'); break
          case 'c': setTool('curve'); break
          case 'r': setTool('rectangle'); break
          case 'f': setTool('structure'); break
          case 't': setTool('text'); break
          case 'm': setTool('measure'); break
          case 'e': setTool('eraser-click'); break
          case 'q': setTool('copy-last'); break
          case 's': setSnapEnabled(!snapEnabled); break
          case 'g': if (e.shiftKey) setShowGrid(!showGrid); break
        }
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [historyIndex, history, showGrid, snapEnabled, zoom, panOffset])

  return (
    <Card className="shadow-sm bg-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>As-Built Drawings</CardTitle>
            <CardDescription>Create site plans, as-built drawings, and layout diagrams</CardDescription>
          </div>
          <Button size="lg" variant={isFullscreen ? 'default' : 'outline'} onClick={toggleFullscreen} className="font-medium">
            {isFullscreen ? '✕ Exit Fullscreen' : '⛶ Fullscreen'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2 p-3 bg-muted rounded-lg border">
            <span className="text-sm font-medium mr-2">Draw:</span>
            <Button size="sm" variant={tool === 'select' ? 'default' : 'outline'} onClick={() => setTool('select')}>Select (V)</Button>
            <Button size="sm" variant={tool === 'line' ? 'default' : 'outline'} onClick={() => setTool('line')}>Line (L)</Button>
            <Button size="sm" variant={tool === 'curve' ? 'default' : 'outline'} onClick={() => setTool('curve')}>Curve (C)</Button>
            <Button size="sm" variant={tool === 'rectangle' ? 'default' : 'outline'} onClick={() => setTool('rectangle')}>Rectangle (R)</Button>
            <Button size="sm" variant={tool === 'rounded-rectangle' ? 'default' : 'outline'} onClick={() => setTool('rounded-rectangle')}>Rounded Rect</Button>
            <Button size="sm" variant={tool === 'structure' ? 'default' : 'outline'} onClick={() => setTool('structure')}>Structure (F)</Button>
            <Button size="sm" variant={tool === 'text' ? 'default' : 'outline'} onClick={() => setTool('text')}>Text (T)</Button>
            <Button size="sm" variant={tool === 'measure' ? 'default' : 'outline'} onClick={() => setTool('measure')}>Measure (M)</Button>
            <Button size="sm" variant={tool === 'copy-last' ? 'default' : 'outline'} onClick={() => setTool('copy-last')}>Copy Last (Q)</Button>
            <Button size="sm" variant={tool === 'panel' ? 'default' : 'outline'} onClick={() => setTool('panel')} className="bg-blue-600 hover:bg-blue-700 text-white">Panel (P)</Button>
            
            <Separator orientation="vertical" className="h-8" />
            
            <span className="text-sm font-medium mr-2">Erase:</span>
            <Button size="sm" variant={tool === 'eraser-click' ? 'default' : 'outline'} onClick={() => setTool('eraser-click')}>Click (E)</Button>
            <Button size="sm" variant={tool === 'eraser-box' ? 'default' : 'outline'} onClick={() => setTool('eraser-box')}>Box</Button>
          </div>

          <div className="flex flex-wrap gap-2 p-3 bg-muted rounded-lg border">
            <div className="flex items-center gap-2">
              <Label className="text-sm">Zoom: {(zoom * 100).toFixed(0)}%</Label>
              <Button size="sm" variant="outline" onClick={() => setZoom(Math.max(0.1, zoom / 1.05))}>-</Button>
              <Button size="sm" variant="outline" onClick={() => setZoom(Math.min(5, zoom * 1.05))}>+</Button>
              <Button size="sm" variant="outline" onClick={() => { setZoom(1); setPanOffset({ x: 0, y: 0 }) }}>Reset</Button>
            </div>
            
            {tool === 'rounded-rectangle' && (
              <div className="flex items-center gap-2">
                <Label className="text-sm">Corner Radius: {cornerRadius}px</Label>
                <input type="range" min="5" max="50" value={cornerRadius} onChange={(e) => setCornerRadius(Number(e.target.value))} className="w-24" />
              </div>
            )}
            
            <Separator orientation="vertical" className="h-8" />
            
            <Button size="sm" variant={panMode ? 'default' : 'outline'} onClick={() => setPanMode(!panMode)}>Pan Mode</Button>
            <Button size="sm" variant="outline" onClick={undo} disabled={historyIndex <= 0}>Undo</Button>
            <Button size="sm" variant="outline" onClick={redo} disabled={historyIndex >= history.length - 1}>Redo</Button>
            <Button size="sm" variant="outline" onClick={() => setShowGrid(!showGrid)}>{showGrid ? 'Hide' : 'Show'} Grid</Button>
            <Button size="sm" variant={snapEnabled ? 'default' : 'outline'} onClick={() => setSnapEnabled(!snapEnabled)}>Snap (S)</Button>
            
            {selectedObject && tool === 'select' && (
              <>
                <Separator orientation="vertical" className="h-8" />
                <span className="text-sm font-medium text-primary mr-1">Rotate:</span>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(-90)}>-90°</Button>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(-45)}>-45°</Button>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(-15)}>-15°</Button>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(15)}>+15°</Button>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(45)}>+45°</Button>
                <Button size="sm" variant="outline" onClick={() => rotateSelectedObject(90)}>+90°</Button>
              </>
            )}
          </div>

          {tool === 'panel' && (
            <div className="flex flex-wrap gap-4 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2">
                <Label className="text-sm font-medium">Active Roll:</Label>
                {getActiveRolls && getActiveRolls().length > 0 ? (
                  <select 
                    value={selectedRollId} 
                    onChange={(e) => setSelectedRollId(e.target.value)}
                    className="px-3 py-1.5 rounded border bg-background text-sm min-w-[200px]"
                  >
                    <option value="">Select a roll...</option>
                    {getActiveRolls().map(roll => (
                      <option key={roll.id} value={roll.id}>
                        {roll.rollId} ({roll.widthM.toFixed(1)}m wide, {roll.remainingLengthM.toFixed(1)}m left)
                      </option>
                    ))}
                  </select>
                ) : (
                  <span className="text-sm text-muted-foreground">No active rolls - add from Material Register</span>
                )}
              </div>
              
              {selectedRollId && (
                <>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm font-medium">Panel Length (m):</Label>
                    <Input 
                      type="number" 
                      step="0.1" 
                      value={panelLength} 
                      onChange={(e) => setPanelLength(e.target.value)}
                      className="w-24 h-8"
                      placeholder="0.0"
                    />
                  </div>
                  
                  {(() => {
                    const roll = getActiveRolls?.().find(r => r.id === selectedRollId)
                    if (roll && panelLength) {
                      const length = parseFloat(panelLength)
                      if (length > roll.remainingLengthM) {
                        return (
                          <span className="text-sm text-red-500 font-medium">
                            Not enough material! ({roll.remainingLengthM.toFixed(1)}m available)
                          </span>
                        )
                      }
                      return (
                        <span className="text-sm text-green-600 font-medium">
                          Panel: {length.toFixed(1)}m x {roll.widthM.toFixed(1)}m | Click canvas to place
                        </span>
                      )
                    }
                    return null
                  })()}
                </>
              )}
            </div>
          )}

          <div className="flex flex-wrap gap-2 p-3 bg-muted rounded-lg border">
            <div className="flex items-center gap-2">
              <Label className="text-sm">Color:</Label>
              <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="w-12 h-8 rounded cursor-pointer" />
            </div>
            
            <div className="flex items-center gap-2">
              <Label className="text-sm">Weight: {lineWeight}px</Label>
              <input type="range" min="1" max="10" value={lineWeight} onChange={(e) => setLineWeight(Number(e.target.value))} className="w-24" />
            </div>

            <div className="flex items-center gap-2">
              <Label className="text-sm">Line Type:</Label>
              <select 
                value={JSON.stringify(lineType)} 
                onChange={(e) => setLineType(JSON.parse(e.target.value))}
                className="px-2 py-1 rounded border bg-background text-sm"
              >
                <option value="[]">Solid</option>
                <option value="[10,10]">Dashed</option>
                <option value="[2,5]">Dotted</option>
                <option value="[10,5,2,5]">Dash-Dot</option>
                <option value="[20,5,5,5]">Center Line</option>
              </select>
            </div>
            
            <Separator orientation="vertical" className="h-8" />
            
            <Button size="sm" variant="destructive" onClick={clearCanvas}>Clear Layer</Button>
          </div>

          {selectedObject && tool === 'select' && getSelectedObjectData() && (
            <div className="flex flex-wrap gap-3 p-3 bg-primary/10 rounded-lg border border-primary/30">
              <span className="text-sm font-semibold text-primary">Selected Object Properties:</span>
              
              {(getSelectedObjectData()?.type === 'line' || getSelectedObjectData()?.type === 'curve') && (
                <>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Seam #:</Label>
                    <select 
                      value={getSelectedObjectData()?.seamNumber || ""}
                      onChange={(e) => updateSelectedObjectProperty('seamNumber', e.target.value)}
                      className="px-2 py-1 rounded border bg-background text-sm min-w-[80px]"
                    >
                      <option value="">None</option>
                      {Array.from({length: 100}, (_, i) => `S${String(i + 1).padStart(3, '0')}`).map(seam => (
                        <option key={seam} value={seam}>{seam}</option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Layer Type:</Label>
                    <select 
                      value={getSelectedObjectData()?.layerType || ""}
                      onChange={(e) => updateSelectedObjectProperty('layerType', e.target.value)}
                      className="px-2 py-1 rounded border bg-background text-sm min-w-[100px]"
                    >
                      <option value="">Select...</option>
                      <option value="Primary">Primary</option>
                      <option value="Secondary">Secondary</option>
                      <option value="Tertiary">Tertiary</option>
                      <option value="Leak Detection">Leak Detection</option>
                      <option value="Cover">Cover</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Membrane:</Label>
                    <select 
                      value={getSelectedObjectData()?.membraneType || ""}
                      onChange={(e) => updateSelectedObjectProperty('membraneType', e.target.value)}
                      className="px-2 py-1 rounded border bg-background text-sm min-w-[100px]"
                    >
                      <option value="">Select...</option>
                      <option value="HDPE 1.5mm">HDPE 1.5mm</option>
                      <option value="HDPE 2.0mm">HDPE 2.0mm</option>
                      <option value="HDPE 2.5mm">HDPE 2.5mm</option>
                      <option value="LLDPE 1.0mm">LLDPE 1.0mm</option>
                      <option value="LLDPE 1.5mm">LLDPE 1.5mm</option>
                      <option value="GCL">GCL</option>
                      <option value="Geotextile">Geotextile</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center gap-2 bg-black/30 px-2 py-1 rounded">
                    <span className="text-xs text-muted-foreground">Length:</span>
                    <span className="text-sm font-mono text-primary">{calculateLineLength(getSelectedObjectData()!).toFixed(1)}px</span>
                  </div>
                </>
              )}
              
              {(getSelectedObjectData()?.type === 'rectangle' || getSelectedObjectData()?.type === 'rounded-rectangle' || getSelectedObjectData()?.type === 'structure') && (
                <>
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Panel ID:</Label>
                    <input 
                      type="text"
                      value={getSelectedObjectData()?.panelId || ""}
                      onChange={(e) => updateSelectedObjectProperty('panelId', e.target.value)}
                      placeholder="e.g., P001"
                      className="px-2 py-1 rounded border bg-background text-sm w-20"
                    />
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Layer Type:</Label>
                    <select 
                      value={getSelectedObjectData()?.layerType || ""}
                      onChange={(e) => updateSelectedObjectProperty('layerType', e.target.value)}
                      className="px-2 py-1 rounded border bg-background text-sm min-w-[100px]"
                    >
                      <option value="">Select...</option>
                      <option value="Primary">Primary</option>
                      <option value="Secondary">Secondary</option>
                      <option value="Tertiary">Tertiary</option>
                      <option value="Leak Detection">Leak Detection</option>
                      <option value="Cover">Cover</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Label className="text-sm">Membrane:</Label>
                    <select 
                      value={getSelectedObjectData()?.membraneType || ""}
                      onChange={(e) => updateSelectedObjectProperty('membraneType', e.target.value)}
                      className="px-2 py-1 rounded border bg-background text-sm min-w-[100px]"
                    >
                      <option value="">Select...</option>
                      <option value="HDPE 1.5mm">HDPE 1.5mm</option>
                      <option value="HDPE 2.0mm">HDPE 2.0mm</option>
                      <option value="HDPE 2.5mm">HDPE 2.5mm</option>
                      <option value="LLDPE 1.0mm">LLDPE 1.0mm</option>
                      <option value="LLDPE 1.5mm">LLDPE 1.5mm</option>
                      <option value="GCL">GCL</option>
                      <option value="Geotextile">Geotextile</option>
                    </select>
                  </div>
                </>
              )}
            </div>
          )}

          <div ref={containerRef} className="relative border border-border rounded-lg overflow-hidden" style={{ backgroundColor: '#1a2332' }}>
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              className="w-full cursor-crosshair"
              style={{ display: 'block', touchAction: 'none' }}
            />
            
            <div className="absolute bottom-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs font-mono pointer-events-none">
              X: {Math.round(mousePos.x)} Y: {Math.round(mousePos.y)}
            </div>
            
            {hoveredObject && (() => {
              const layer = asBuiltData.layers.find(l => l.id === hoveredObject.layerId)
              const obj = layer?.objects[hoveredObject.index]
              if (!obj) return null
              const hasMetadata = obj.seamNumber || obj.panelId || obj.layerType || obj.membraneType
              if (!hasMetadata && obj.type !== 'line' && obj.type !== 'curve') return null
              
              return (
                <div 
                  className="absolute bg-black/90 backdrop-blur-sm text-white px-3 py-2 rounded-lg text-xs pointer-events-none border border-primary/50 shadow-lg z-50"
                  style={{ 
                    left: Math.min(mousePos.x * zoom + panOffset.x + 15, (canvasRef.current?.width || 400) - 180),
                    top: Math.max(mousePos.y * zoom + panOffset.y - 60, 10)
                  }}
                >
                  <div className="font-semibold text-primary mb-1 capitalize">{obj.type.replace('-', ' ')}</div>
                  {obj.seamNumber && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground">Seam #:</span>
                      <span className="font-mono text-cyan-400">{obj.seamNumber}</span>
                    </div>
                  )}
                  {obj.panelId && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground">Panel ID:</span>
                      <span className="font-mono text-cyan-400">{obj.panelId}</span>
                    </div>
                  )}
                  {(obj.type === 'line' || obj.type === 'curve') && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground">Length:</span>
                      <span className="font-mono text-emerald-400">{calculateLineLength(obj).toFixed(1)}px</span>
                    </div>
                  )}
                  {obj.layerType && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground">Layer:</span>
                      <span className="text-yellow-400">{obj.layerType}</span>
                    </div>
                  )}
                  {obj.membraneType && (
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground">Membrane:</span>
                      <span className="text-orange-400">{obj.membraneType}</span>
                    </div>
                  )}
                </div>
              )
            })()}
            
            {gpsCoords && (
              <div className="absolute bottom-2 right-2 bg-black/80 text-sky-400 px-2 py-1 rounded text-xs font-mono font-bold pointer-events-none">
                GPS: {gpsCoords.lat.toFixed(6)}, {gpsCoords.lon.toFixed(6)}
              </div>
            )}
            
            {measureDistance !== null && (
              <div className="absolute top-2 right-2 bg-black/80 text-emerald-400 px-2 py-1 rounded text-sm font-mono font-bold pointer-events-none">
                Distance: {measureDistance.toFixed(1)}px
              </div>
            )}
            
            {isFullscreen && (
              <>
                <div className="absolute top-4 left-4 z-50 pointer-events-auto">
                  <div className="relative">
                    <Button 
                      size="lg"
                      variant="default"
                      onClick={() => setFullscreenMenuOpen(!fullscreenMenuOpen)}
                      className="h-14 w-14 rounded-full bg-primary/90 hover:bg-primary shadow-lg text-xl"
                    >
                      {fullscreenMenuOpen ? '✕' : '☰'}
                    </Button>
                    
                    {fullscreenMenuOpen && (
                      <div className="absolute top-16 left-0 bg-black/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-xl min-w-[200px] max-h-[70vh] overflow-y-auto">
                        <div className="space-y-2">
                          <p className="text-xs text-muted-foreground px-2 pb-1 border-b border-border/50 sticky top-0 bg-black/95">Drawing Tools</p>
                          <Button size="sm" variant={tool === 'select' ? 'default' : 'ghost'} onClick={() => { setTool('select'); setFullscreenMenuOpen(false) }} className="w-full justify-start">↖ Select</Button>
                          <Button size="sm" variant={tool === 'line' ? 'default' : 'ghost'} onClick={() => { setTool('line'); setFullscreenMenuOpen(false) }} className="w-full justify-start">📏 Line</Button>
                          <Button size="sm" variant={tool === 'curve' ? 'default' : 'ghost'} onClick={() => { setTool('curve'); setFullscreenMenuOpen(false) }} className="w-full justify-start">〰️ Curve</Button>
                          <Button size="sm" variant={tool === 'rectangle' ? 'default' : 'ghost'} onClick={() => { setTool('rectangle'); setFullscreenMenuOpen(false) }} className="w-full justify-start">▭ Rectangle</Button>
                          <Button size="sm" variant={tool === 'rounded-rectangle' ? 'default' : 'ghost'} onClick={() => { setTool('rounded-rectangle'); setFullscreenMenuOpen(false) }} className="w-full justify-start">▢ Rounded Rect</Button>
                          <Button size="sm" variant={tool === 'structure' ? 'default' : 'ghost'} onClick={() => { setTool('structure'); setFullscreenMenuOpen(false) }} className="w-full justify-start">🏗️ Structure</Button>
                          <Button size="sm" variant={tool === 'text' ? 'default' : 'ghost'} onClick={() => { setTool('text'); setFullscreenMenuOpen(false) }} className="w-full justify-start">T Text</Button>
                          <Button size="sm" variant={tool === 'measure' ? 'default' : 'ghost'} onClick={() => { setTool('measure'); setFullscreenMenuOpen(false) }} className="w-full justify-start">📐 Measure</Button>
                          <Button size="sm" variant={tool === 'gps-marker' ? 'default' : 'ghost'} onClick={() => { setTool('gps-marker'); setFullscreenMenuOpen(false) }} className="w-full justify-start">📍 GPS Marker</Button>
                          <Button size="sm" variant={tool === 'copy-last' ? 'default' : 'ghost'} onClick={() => { setTool('copy-last'); setFullscreenMenuOpen(false) }} className="w-full justify-start">📋 Copy Last</Button>
                          
                          <p className="text-xs text-muted-foreground px-2 pt-2 pb-1 border-t border-b border-border/50">Erasers</p>
                          <Button size="sm" variant={tool === 'eraser-click' ? 'default' : 'ghost'} onClick={() => { setTool('eraser-click'); setFullscreenMenuOpen(false) }} className="w-full justify-start">🗑️ Click Eraser</Button>
                          <Button size="sm" variant={tool === 'eraser-box' ? 'default' : 'ghost'} onClick={() => { setTool('eraser-box'); setFullscreenMenuOpen(false) }} className="w-full justify-start">⬜ Box Eraser</Button>
                          
                          <p className="text-xs text-muted-foreground px-2 pt-2 pb-1 border-t border-b border-border/50">View & Edit</p>
                          <Button size="sm" variant={panMode ? 'default' : 'ghost'} onClick={() => { setPanMode(!panMode) }} className="w-full justify-start">{panMode ? '✋ Pan ON' : '🖐️ Pan Mode'}</Button>
                          <Button size="sm" variant={showGrid ? 'default' : 'ghost'} onClick={() => setShowGrid(!showGrid)} className="w-full justify-start">{showGrid ? '▦ Grid ON' : '▢ Grid OFF'}</Button>
                          <Button size="sm" variant={snapEnabled ? 'default' : 'ghost'} onClick={() => setSnapEnabled(!snapEnabled)} className="w-full justify-start">{snapEnabled ? '🧲 Snap ON' : '🧲 Snap OFF'}</Button>
                          <Button size="sm" variant="ghost" onClick={undo} disabled={historyIndex <= 0} className="w-full justify-start">↶ Undo</Button>
                          <Button size="sm" variant="ghost" onClick={redo} disabled={historyIndex >= history.length - 1} className="w-full justify-start">↷ Redo</Button>
                          <Button size="sm" variant="ghost" onClick={() => { setZoom(1); setPanOffset({ x: 0, y: 0 }) }} className="w-full justify-start">🔄 Reset View</Button>
                          
                          {selectedObject && (
                            <>
                              <p className="text-xs text-muted-foreground px-2 pt-2 pb-1 border-t border-b border-border/50">Rotate Selected</p>
                              <div className="grid grid-cols-3 gap-1">
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(-90)} className="text-xs">-90°</Button>
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(-45)} className="text-xs">-45°</Button>
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(-15)} className="text-xs">-15°</Button>
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(15)} className="text-xs">+15°</Button>
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(45)} className="text-xs">+45°</Button>
                                <Button size="sm" variant="ghost" onClick={() => rotateSelectedObject(90)} className="text-xs">+90°</Button>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="absolute top-4 right-4 z-50 pointer-events-auto flex gap-2">
                  <div className="bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2 text-white text-sm font-mono">
                    {(zoom * 100).toFixed(0)}%
                  </div>
                  <Button 
                    size="lg" 
                    variant="destructive" 
                    onClick={toggleFullscreen}
                    className="h-10 px-4 font-semibold shadow-lg"
                  >
                    ✕ Exit
                  </Button>
                </div>
                
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/90 backdrop-blur-sm border border-border rounded-lg px-4 py-2 shadow-lg z-50 pointer-events-auto">
                  <div className="flex gap-3 items-center" style={{ pointerEvents: 'auto' }}>
                    <span className="text-sm text-muted-foreground hidden sm:block">Active:</span>
                    <span className="text-sm font-medium text-primary capitalize">{tool.replace('-', ' ')}</span>
                    <div className="h-4 w-px bg-border" />
                    <Button size="sm" variant="ghost" onClick={() => setZoom(Math.max(0.1, zoom / 1.2))} className="h-8 w-8 p-0">−</Button>
                    <Button size="sm" variant="ghost" onClick={() => setZoom(Math.min(5, zoom * 1.2))} className="h-8 w-8 p-0">+</Button>
                    <div className="h-4 w-px bg-border" />
                    <Button size="sm" variant="ghost" onClick={undo} disabled={historyIndex <= 0} className="h-8 w-8 p-0">↶</Button>
                    <Button size="sm" variant="ghost" onClick={redo} disabled={historyIndex >= history.length - 1} className="h-8 w-8 p-0">↷</Button>
                  </div>
                </div>
                
                <div className="absolute bottom-20 left-4 bg-black/70 backdrop-blur-sm rounded-lg px-3 py-2 text-xs text-muted-foreground z-40 pointer-events-none">
                  <p>Pinch to zoom | Two fingers to pan</p>
                </div>
              </>
            )}
          </div>

          <div className="text-sm text-muted-foreground">
            <p><strong>Quick Sketch Tools:</strong> Draw ponds, panels, and site layouts with ease. Use <strong>Rounded Rectangles</strong> for smooth shapes. Click <strong>Fullscreen</strong> for maximum canvas space. Press keyboard shortcuts (L=Line, C=Curve, R=Rectangle) for fast work. <strong>Snap Lock</strong> helps align to grid. All drawings auto-save.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function LinrProjectPage() {
  const params = useParams()
  const router = useRouter()
  const { user, token, isLoading: authLoading } = useAuth()
  const projectId = params.projectId as string
  
  const [termsAccepted, setTermsAccepted] = useState<boolean | null>(null)
  const [projectLoading, setProjectLoading] = useState(true)
  const [projectError, setProjectError] = useState<string | null>(null)
  const [projectInfo, setProjectInfo] = useState<{ id: number; name: string; orgId: number } | null>(null)
  
  const [activeModule, setActiveModule] = useState<string>("engineers")
  const [settings, setSettings] = useState<Settings>({ company: "", contact: "", region: "", logo: "" })
  const [projectSpecs, setProjectSpecs] = useState<ProjectSpecs>({
    projectName: "",
    projectNumber: "",
    clientName: "",
    siteLocation: "",
    geomembraneType: "",
    specifiedThickness: "",
    totalArea: "",
    startDate: "",
    supervisor: "",
    contractor: "",
    qualityStandards: "",
    testingRequirements: "",
    minPeelPass: "",
    minShearPass: "",
    destructiveTestFrequency: ""
  })
  const [signOnLogs, setSignOnLogs] = useState<LogEntry[]>([])
  const [dailyLogs, setDailyLogs] = useState<LogEntry[]>([])
  const [panelPlacementLogs, setPanelPlacementLogs] = useState<LogEntry[]>([])
  const [editingPanelIndex, setEditingPanelIndex] = useState<number | null>(null)
  const [materialRegisterLogs, setMaterialRegisterLogs] = useState<LogEntry[]>([])
  const [weldLogs, setWeldLogs] = useState<LogEntry[]>([])
  const [repairLogs, setRepairLogs] = useState<LogEntry[]>([])
  const [repairWeldType, setRepairWeldType] = useState<'extrusion' | 'seam'>('extrusion')
  const [airLogs, setAirLogs] = useState<LogEntry[]>([])
  const [vacuumLogs, setVacuumLogs] = useState<LogEntry[]>([])
  const [sparkLogs, setSparkLogs] = useState<LogEntry[]>([])
  const [destructiveLogs, setDestructiveLogs] = useState<LogEntry[]>([])
  const [machinePreStartLogs, setMachinePreStartLogs] = useState<LogEntry[]>([])
  const [trialWeldLogs, setTrialWeldLogs] = useState<LogEntry[]>([])
  const [ncrLogs, setNcrLogs] = useState<LogEntry[]>([])
  const [finalPortal, setFinalPortal] = useState<FinalPortalData>({})
  const [asBuiltData, setAsBuiltData] = useState<AsBuiltData>({
    layers: [{ id: 1, name: "Base Layer", objects: [], isVisible: true }],
    activeLayerId: 1,
    nextLayerId: 2
  })
  const [materialInventory, setMaterialInventory] = useState<MaterialInventory>({
    rolls: [],
    panelPlacements: [],
    nextPanelNumber: 1
  })
  const [selectedRollForPanel, setSelectedRollForPanel] = useState<string | null>(null)
  const [panelLengthInput, setPanelLengthInput] = useState<string>("")

  const storageKey = (key: string) => `linr_project_${projectId}_${key}`

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login')
    }
  }, [authLoading, user, router])

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const accepted = localStorage.getItem("linr_terms_accepted")
        setTermsAccepted(accepted === "true")
      } catch (e) {
        console.error("Error checking terms:", e)
        setTermsAccepted(false)
      }
    }
  }, [])

  const acceptTerms = () => {
    localStorage.setItem("linr_terms_accepted", "true")
    setTermsAccepted(true)
  }

  useEffect(() => {
    if (!token || !projectId) return
    
    const loadProjectData = async () => {
      setProjectLoading(true)
      setProjectError(null)
      
      try {
        const [projectRes, specsRes] = await Promise.all([
          fetch(`/api/projects/${projectId}`, {
            headers: { Authorization: `Bearer ${token}` }
          }),
          fetch(`/api/projects/${projectId}/specs`, {
            headers: { Authorization: `Bearer ${token}` }
          })
        ])
        
        if (!projectRes.ok) {
          if (projectRes.status === 403 || projectRes.status === 401) {
            setProjectError("You don't have access to this project")
            return
          }
          throw new Error("Failed to load project")
        }
        
        const project = await projectRes.json()
        setProjectInfo({ id: project.id, name: project.name, orgId: project.orgId })
        
        if (specsRes.ok) {
          const specs = await specsRes.json()
          if (specs) {
            setProjectSpecs({
              projectName: project.name || "",
              projectNumber: specs.projectNumber || "",
              clientName: specs.clientName || "",
              siteLocation: specs.siteLocation || "",
              geomembraneType: specs.linerType || "",
              specifiedThickness: specs.minThicknessMm?.toString() || "",
              totalArea: "",
              startDate: "",
              supervisor: "",
              contractor: "",
              qualityStandards: "",
              testingRequirements: "",
              minPeelPass: specs.minPeelStrengthNmm?.toString() || "",
              minShearPass: specs.minShearStrengthNmm?.toString() || "",
              destructiveTestFrequency: ""
            })
          }
        }
        
        const savedData = localStorage.getItem(storageKey("data"))
        if (savedData) {
          const parsed = JSON.parse(savedData)
          if (parsed.signOnLogs) setSignOnLogs(parsed.signOnLogs)
          if (parsed.dailyLogs) setDailyLogs(parsed.dailyLogs)
          if (parsed.panelPlacementLogs) setPanelPlacementLogs(parsed.panelPlacementLogs)
          if (parsed.materialRegisterLogs) setMaterialRegisterLogs(parsed.materialRegisterLogs)
          if (parsed.weldLogs) setWeldLogs(parsed.weldLogs)
          if (parsed.repairLogs) setRepairLogs(parsed.repairLogs)
          if (parsed.airLogs) setAirLogs(parsed.airLogs)
          if (parsed.vacuumLogs) setVacuumLogs(parsed.vacuumLogs)
          if (parsed.sparkLogs) setSparkLogs(parsed.sparkLogs)
          if (parsed.destructiveLogs) setDestructiveLogs(parsed.destructiveLogs)
          if (parsed.machinePreStartLogs) setMachinePreStartLogs(parsed.machinePreStartLogs)
          if (parsed.trialWeldLogs) setTrialWeldLogs(parsed.trialWeldLogs)
          if (parsed.ncrLogs) setNcrLogs(parsed.ncrLogs)
          if (parsed.finalPortal) setFinalPortal(parsed.finalPortal)
          if (parsed.asBuiltData) setAsBuiltData(parsed.asBuiltData)
          if (parsed.materialInventory) setMaterialInventory(parsed.materialInventory)
          if (parsed.settings) setSettings(parsed.settings)
        }
        
      } catch (error) {
        console.error("Error loading project:", error)
        setProjectError("Failed to load project data")
      } finally {
        setProjectLoading(false)
      }
    }
    
    loadProjectData()
  }, [token, projectId])

  const saveProjectData = () => {
    const dataToSave = {
      signOnLogs,
      dailyLogs,
      panelPlacementLogs,
      materialRegisterLogs,
      weldLogs,
      repairLogs,
      airLogs,
      vacuumLogs,
      sparkLogs,
      destructiveLogs,
      machinePreStartLogs,
      trialWeldLogs,
      ncrLogs,
      finalPortal,
      asBuiltData,
      materialInventory,
      settings
    }
    localStorage.setItem(storageKey("data"), JSON.stringify(dataToSave))
  }

  useEffect(() => {
    if (projectInfo) {
      saveProjectData()
    }
  }, [signOnLogs, dailyLogs, panelPlacementLogs, materialRegisterLogs, weldLogs, repairLogs, 
      airLogs, vacuumLogs, sparkLogs, destructiveLogs, machinePreStartLogs, trialWeldLogs, 
      ncrLogs, finalPortal, asBuiltData, materialInventory, settings, projectInfo])

  const goBackToHome = () => {
    router.push('/home')
  }

  const saveSettings = (newSettings: Settings) => {
    setSettings(newSettings)
  }

  const saveProjectSpecs = (newSpecs: ProjectSpecs) => {
    setProjectSpecs(newSpecs)
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        saveSettings({ ...settings, logo: reader.result as string })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleProjectSpecsSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const newSpecs: ProjectSpecs = {
      projectName: formData.get("projectName") as string,
      projectNumber: formData.get("projectNumber") as string,
      clientName: formData.get("clientName") as string,
      siteLocation: formData.get("siteLocation") as string,
      geomembraneType: formData.get("geomembraneType") as string,
      specifiedThickness: formData.get("specifiedThickness") as string,
      totalArea: formData.get("totalArea") as string,
      startDate: formData.get("startDate") as string,
      supervisor: formData.get("supervisor") as string,
      contractor: formData.get("contractor") as string,
      qualityStandards: formData.get("qualityStandards") as string,
      testingRequirements: formData.get("testingRequirements") as string,
      minPeelPass: formData.get("minPeelPass") as string,
      minShearPass: formData.get("minShearPass") as string,
      destructiveTestFrequency: formData.get("destructiveTestFrequency") as string,
    }
    saveProjectSpecs(newSpecs)
  }

  const addSignOn = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("name") as string,
      formData.get("company") as string,
      formData.get("timeIn") as string,
      formData.get("timeOut") as string,
    ]
    const updated = [...signOnLogs, entry]
    setSignOnLogs(updated)
    form.reset()
  }

  const addDaily = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("weather") as string,
      formData.get("crew") as string,
      formData.get("notes") as string,
    ]
    const updated = [...dailyLogs, entry]
    setDailyLogs(updated)
    form.reset()
  }

  const addPanelPlacement = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("panelNumber") as string,
      formData.get("date") as string,
      formData.get("time") as string,
      formData.get("ambientTemp") as string,
      formData.get("length") as string,
      formData.get("location") as string,
      formData.get("rollNumber") as string,
    ]
    
    if (editingPanelIndex !== null) {
      const updated = [...panelPlacementLogs]
      updated[editingPanelIndex] = entry
      setPanelPlacementLogs(updated)
      setEditingPanelIndex(null)
    } else {
      const updated = [...panelPlacementLogs, entry]
      setPanelPlacementLogs(updated)
    }
    form.reset()
  }

  const startEditPanel = (index: number) => {
    setEditingPanelIndex(index)
  }

  const cancelEditPanel = () => {
    setEditingPanelIndex(null)
  }

  const getNextLogPanelNumber = () => {
    if (panelPlacementLogs.length === 0) return "1"
    const maxNumber = panelPlacementLogs.reduce((max, log) => {
      const num = parseInt(log[0]) || 0
      return num > max ? num : max
    }, 0)
    return String(maxNumber + 1)
  }

  const addMaterialRegister = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("rollId") as string,
      formData.get("manufacturer") as string,
      formData.get("thickness") as string,
      formData.get("width") as string,
      formData.get("length") as string,
      formData.get("lotNumber") as string,
      formData.get("note") as string,
    ]
    const updated = [...materialRegisterLogs, entry]
    setMaterialRegisterLogs(updated)
    form.reset()
  }

  const addRepair = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    
    const weldType = formData.get("weldType") as string
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("location") as string,
      formData.get("size") as string,
      formData.get("issue") as string,
      formData.get("tech") as string,
      weldType,
      formData.get("barrelTemp") as string || "",
      formData.get("preheatTemp") as string || "",
      formData.get("fusionTemp") as string || "",
      formData.get("fusionSpeed") as string || "",
      formData.get("note") as string,
    ]
    const updated = [...repairLogs, entry]
    setRepairLogs(updated)
    form.reset()
    setRepairWeldType('extrusion')
  }

  const getRecentTrialWeldSettings = () => {
    if (trialWeldLogs.length === 0) return null
    
    const now = new Date()
    const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000)
    
    for (let i = trialWeldLogs.length - 1; i >= 0; i--) {
      const trial = trialWeldLogs[i]
      const trialDateTime = new Date(`${trial[0]}T${trial[1]}`)
      
      if (trialDateTime >= fourHoursAgo) {
        return {
          techName: trial[2] || "",
          machineId: trial[3] || "",
          iagiNumber: trial[9] || "",
          machineTemp: trial[5] || "",
          machineSpeed: trial[6] || "",
          barrelTemp: trial[7] || "",
          preheatTemp: trial[8] || "",
        }
      }
    }
    
    return null
  }

  const getRecentExtrusionTrialWeldSettings = () => {
    if (trialWeldLogs.length === 0) return null
    
    const now = new Date()
    const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000)
    
    for (let i = trialWeldLogs.length - 1; i >= 0; i--) {
      const trial = trialWeldLogs[i]
      const trialDateTime = new Date(`${trial[0]}T${trial[1]}`)
      const weldType = (trial[4] || "").toLowerCase()
      
      if (trialDateTime >= fourHoursAgo && weldType.includes("extrusion")) {
        return {
          techName: trial[2] || "",
          machineId: trial[3] || "",
          iagiNumber: trial[9] || "",
          barrelTemp: trial[7] || "",
          preheatTemp: trial[8] || "",
        }
      }
    }
    
    return null
  }

  const getRecentFusionTrialWeldSettings = () => {
    if (trialWeldLogs.length === 0) return null
    
    const now = new Date()
    const fourHoursAgo = new Date(now.getTime() - 4 * 60 * 60 * 1000)
    
    for (let i = trialWeldLogs.length - 1; i >= 0; i--) {
      const trial = trialWeldLogs[i]
      const trialDateTime = new Date(`${trial[0]}T${trial[1]}`)
      const weldType = (trial[4] || "").toLowerCase()
      
      if (trialDateTime >= fourHoursAgo && weldType.includes("fusion")) {
        return {
          techName: trial[2] || "",
          machineId: trial[3] || "",
          iagiNumber: trial[9] || "",
          fusionTemp: trial[5] || "",
          fusionSpeed: trial[6] || "",
        }
      }
    }
    
    return null
  }

  const addWeld = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    
    const now = new Date()
    const currentDate = now.toISOString().split('T')[0]
    const currentTime = now.toTimeString().slice(0, 5)
    
    const entry: LogEntry = [
      formData.get("seamNumber") as string,
      formData.get("technicianName") as string,
      formData.get("iagiNumber") as string || "",
      currentDate,
      currentTime,
      formData.get("machineTemp") as string,
      formData.get("machineSpeed") as string,
    ]
    const updated = [...weldLogs, entry]
    setWeldLogs(updated)
    form.reset()
  }

  const addAir = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("testId") as string,
      formData.get("pressure") as string,
      formData.get("duration") as string,
      formData.get("result") as string,
    ]
    const updated = [...airLogs, entry]
    setAirLogs(updated)
    form.reset()
  }

  const addVacuum = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("testId") as string,
      formData.get("pressure") as string,
      formData.get("duration") as string,
      formData.get("result") as string,
    ]
    const updated = [...vacuumLogs, entry]
    setVacuumLogs(updated)
    form.reset()
  }

  const addSpark = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("testId") as string,
      formData.get("voltage") as string,
      formData.get("result") as string,
    ]
    const updated = [...sparkLogs, entry]
    setSparkLogs(updated)
    form.reset()
  }

  const addDestructive = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("sampleId") as string,
      formData.get("peel") as string,
      formData.get("shear") as string,
      formData.get("result") as string,
    ]
    const updated = [...destructiveLogs, entry]
    setDestructiveLogs(updated)
    form.reset()
  }

  const addNonDestructive = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const testType = formData.get("testType") as string
    
    if (testType === "Air") {
      const entry: LogEntry = [
        formData.get("testId") as string,
        formData.get("pressure") as string,
        formData.get("duration") as string,
        formData.get("result") as string,
      ]
      const updated = [...airLogs, entry]
      setAirLogs(updated)
    } else if (testType === "Vacuum") {
      const entry: LogEntry = [
        formData.get("testId") as string,
        formData.get("pressure") as string,
        formData.get("duration") as string,
        formData.get("result") as string,
      ]
      const updated = [...vacuumLogs, entry]
      setVacuumLogs(updated)
    } else if (testType === "Spark") {
      const entry: LogEntry = [
        formData.get("testId") as string,
        formData.get("voltage") as string,
        formData.get("result") as string,
      ]
      const updated = [...sparkLogs, entry]
      setSparkLogs(updated)
    }
    
    form.reset()
  }

  const addMachinePreStart = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("machine") as string,
      formData.get("operator") as string,
      formData.get("preCheck") as string,
      formData.get("notes") as string,
    ]
    const updated = [...machinePreStartLogs, entry]
    setMachinePreStartLogs(updated)
    form.reset()
  }

  const addTrialWeld = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("date") as string,
      formData.get("time") as string,
      formData.get("tech") as string,
      formData.get("machineId") as string,
      formData.get("weldType") as string,
      formData.get("fusionTemp") as string,
      formData.get("fusionSpeed") as string,
      formData.get("extrusionBarrel") as string,
      formData.get("extrusionPreheat") as string,
      formData.get("iagiNumber") as string || "",
    ]
    const updated = [...trialWeldLogs, entry]
    setTrialWeldLogs(updated)
    form.reset()
  }

  const addNCR = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    const entry: LogEntry = [
      formData.get("ncrId") as string,
      formData.get("description") as string,
      formData.get("action") as string,
      formData.get("status") as string,
    ]
    const updated = [...ncrLogs, entry]
    setNcrLogs(updated)
    form.reset()
  }

  const deleteSignOn = (index: number) => {
    const updated = signOnLogs.filter((_, i) => i !== index)
    setSignOnLogs(updated)
  }

  const deleteDaily = (index: number) => {
    const updated = dailyLogs.filter((_, i) => i !== index)
    setDailyLogs(updated)
  }

  const deletePanelPlacement = (index: number) => {
    const updated = panelPlacementLogs.filter((_, i) => i !== index)
    setPanelPlacementLogs(updated)
  }

  const deleteMaterialRegister = (index: number) => {
    const updated = materialRegisterLogs.filter((_, i) => i !== index)
    setMaterialRegisterLogs(updated)
  }

  const deleteRepair = (index: number) => {
    const updated = repairLogs.filter((_, i) => i !== index)
    setRepairLogs(updated)
  }

  const deleteWeld = (index: number) => {
    const updated = weldLogs.filter((_, i) => i !== index)
    setWeldLogs(updated)
  }

  const deleteAir = (index: number) => {
    const updated = airLogs.filter((_, i) => i !== index)
    setAirLogs(updated)
  }

  const deleteVacuum = (index: number) => {
    const updated = vacuumLogs.filter((_, i) => i !== index)
    setVacuumLogs(updated)
  }

  const deleteSpark = (index: number) => {
    const updated = sparkLogs.filter((_, i) => i !== index)
    setSparkLogs(updated)
  }

  const deleteDestructive = (index: number) => {
    const updated = destructiveLogs.filter((_, i) => i !== index)
    setDestructiveLogs(updated)
  }

  const deleteMachinePreStart = (index: number) => {
    const updated = machinePreStartLogs.filter((_, i) => i !== index)
    setMachinePreStartLogs(updated)
  }

  const deleteTrialWeld = (index: number) => {
    const updated = trialWeldLogs.filter((_, i) => i !== index)
    setTrialWeldLogs(updated)
  }

  const deleteNCR = (index: number) => {
    const updated = ncrLogs.filter((_, i) => i !== index)
    setNcrLogs(updated)
  }

  const activateRollFromRegister = (registerIndex: number) => {
    const registerEntry = materialRegisterLogs[registerIndex]
    if (!registerEntry) return
    
    const newRoll: MaterialRoll = {
      id: Date.now().toString(),
      rollId: registerEntry[1],
      widthM: parseFloat(registerEntry[4]) || 0,
      fullLengthM: parseFloat(registerEntry[5]) || 0,
      remainingLengthM: parseFloat(registerEntry[5]) || 0,
      materialType: registerEntry[2] || "Unknown",
      isActive: true,
      linkedRegisterIndex: registerIndex,
      consumptionLog: []
    }
    
    setMaterialInventory(prev => ({
      ...prev,
      rolls: [...prev.rolls, newRoll]
    }))
  }

  const addManualRoll = (rollId: string, widthM: number, fullLengthM: number, materialType: string) => {
    const newRoll: MaterialRoll = {
      id: Date.now().toString(),
      rollId,
      widthM,
      fullLengthM,
      remainingLengthM: fullLengthM,
      materialType,
      isActive: true,
      consumptionLog: []
    }
    
    setMaterialInventory(prev => ({
      ...prev,
      rolls: [...prev.rolls, newRoll]
    }))
  }

  const deactivateRoll = (rollInternalId: string) => {
    setMaterialInventory(prev => ({
      ...prev,
      rolls: prev.rolls.map(r => r.id === rollInternalId ? { ...r, isActive: false } : r)
    }))
  }

  const getActiveRolls = () => {
    return materialInventory.rolls.filter(r => r.isActive && r.remainingLengthM > 0)
  }

  const consumeRollLength = (rollInternalId: string, lengthUsed: number, panelId: string): boolean => {
    const roll = materialInventory.rolls.find(r => r.id === rollInternalId)
    if (!roll || roll.remainingLengthM < lengthUsed) {
      return false
    }
    
    setMaterialInventory(prev => ({
      ...prev,
      rolls: prev.rolls.map(r => {
        if (r.id === rollInternalId) {
          return {
            ...r,
            remainingLengthM: r.remainingLengthM - lengthUsed,
            consumptionLog: [...r.consumptionLog, {
              panelId,
              lengthUsed,
              timestamp: new Date().toISOString()
            }]
          }
        }
        return r
      })
    }))
    return true
  }

  const getNextPanelNumber = (): string => {
    const num = materialInventory.nextPanelNumber
    return `P${String(num).padStart(3, '0')}`
  }

  const placePanelFromRoll = (rollInternalId: string, lengthM: number, location?: string): PanelPlacement | null => {
    const roll = materialInventory.rolls.find(r => r.id === rollInternalId)
    if (!roll || roll.remainingLengthM < lengthM) {
      return null
    }
    
    const panelNumber = getNextPanelNumber()
    
    const newPlacement: PanelPlacement = {
      id: Date.now().toString(),
      panelNumber,
      rollId: roll.rollId,
      lengthM,
      widthM: roll.widthM,
      placedAt: new Date().toISOString(),
      location
    }
    
    setMaterialInventory(prev => ({
      ...prev,
      panelPlacements: [...prev.panelPlacements, newPlacement],
      nextPanelNumber: prev.nextPanelNumber + 1,
      rolls: prev.rolls.map(r => {
        if (r.id === rollInternalId) {
          return {
            ...r,
            remainingLengthM: r.remainingLengthM - lengthM,
            consumptionLog: [...r.consumptionLog, {
              panelId: panelNumber,
              lengthUsed: lengthM,
              timestamp: new Date().toISOString()
            }]
          }
        }
        return r
      })
    }))
    
    return newPlacement
  }

  const getRollRemainingPercentage = (roll: MaterialRoll): number => {
    if (roll.fullLengthM === 0) return 0
    return Math.round((roll.remainingLengthM / roll.fullLengthM) * 100)
  }

  const isRollLow = (roll: MaterialRoll): boolean => {
    return getRollRemainingPercentage(roll) <= 10
  }

  const generateCSV = (headers: string[], data: LogEntry[]): string => {
    const rows = [headers.join(","), ...data.map(row => row.map(cell => `"${cell}"`).join(","))]
    return rows.join("\n")
  }

  const generateIntelligentSummary = (): { paragraphs: string[] } => {
    const paragraphs: string[] = []
    
    const totalTests = airLogs.length + vacuumLogs.length + sparkLogs.length + destructiveLogs.length
    const totalWorkDays = new Set(signOnLogs.map(log => log[0])).size
    const totalPanels = panelPlacementLogs.length
    const totalWelds = weldLogs.length
    const totalRepairs = repairLogs.length
    const openNCRs = ncrLogs.filter(ncr => ncr[3]?.toLowerCase() !== 'closed').length
    const closedNCRs = ncrLogs.filter(ncr => ncr[3]?.toLowerCase() === 'closed').length
    
    const ndtPassed = airLogs.filter(t => t[3]?.toLowerCase().includes('pass')).length +
                      vacuumLogs.filter(t => t[3]?.toLowerCase().includes('pass')).length +
                      sparkLogs.filter(t => t[2]?.toLowerCase().includes('pass')).length
    const ndtTotal = airLogs.length + vacuumLogs.length + sparkLogs.length
    const ndtPassRate = ndtTotal > 0 ? Math.round((ndtPassed / ndtTotal) * 100) : 0
    
    const dtPassed = destructiveLogs.filter(t => t[3]?.toLowerCase().includes('pass')).length
    const dtPassRate = destructiveLogs.length > 0 ? Math.round((dtPassed / destructiveLogs.length) * 100) : 0

    paragraphs.push(`This Construction Quality Assurance (CQA) report summarizes the geomembrane installation project conducted by ${settings.company || 'the contractor'} in ${settings.region || 'the project region'}. The project involved comprehensive quality monitoring across ${totalWorkDays || 'multiple'} recorded work days, with rigorous testing protocols and documentation procedures throughout the installation process.`)

    if (totalPanels > 0 || totalWelds > 0) {
      paragraphs.push(`Installation activities included the placement of ${totalPanels} geomembrane panels with ${totalWelds} panel seam welds completed. ${totalRepairs > 0 ? `A total of ${totalRepairs} repair${totalRepairs !== 1 ? 's were' : ' was'} documented and addressed during the installation phase.` : 'No repairs were required during the installation phase, indicating excellent workmanship and material quality.'}`)
    }

    if (totalTests > 0) {
      paragraphs.push(`Quality assurance testing was conducted extensively throughout the project. Non-destructive testing (NDT) included ${airLogs.length} air channel test${airLogs.length !== 1 ? 's' : ''}, ${vacuumLogs.length} vacuum box test${vacuumLogs.length !== 1 ? 's' : ''}, and ${sparkLogs.length} spark/holiday test${sparkLogs.length !== 1 ? 's' : ''}, achieving an overall pass rate of ${ndtPassRate}%. ${destructiveLogs.length > 0 ? `Destructive testing was performed on ${destructiveLogs.length} sample${destructiveLogs.length !== 1 ? 's' : ''}, with a ${dtPassRate}% pass rate, confirming weld integrity and compliance with project specifications.` : ''}`)
    }

    if (ncrLogs.length > 0) {
      paragraphs.push(`Non-Conformance Reports (NCRs) were managed systematically throughout the project. ${ncrLogs.length} NCR${ncrLogs.length !== 1 ? 's were' : ' was'} raised, of which ${closedNCRs} ${closedNCRs !== 1 ? 'have' : 'has'} been successfully resolved and closed. ${openNCRs > 0 ? `${openNCRs} NCR${openNCRs !== 1 ? 's remain' : ' remains'} open and require${openNCRs === 1 ? 's' : ''} continued attention and corrective action.` : 'All identified non-conformances have been satisfactorily resolved.'}`)
    } else {
      paragraphs.push(`No Non-Conformance Reports (NCRs) were raised during this project phase, demonstrating exemplary adherence to quality standards and project specifications.`)
    }

    if (machinePreStartLogs.length > 0 || trialWeldLogs.length > 0) {
      paragraphs.push(`Equipment management and pre-operational checks were conducted diligently. ${machinePreStartLogs.length} machine pre-start inspection${machinePreStartLogs.length !== 1 ? 's were' : ' was'} completed to ensure all welding equipment met operational standards. ${trialWeldLogs.length > 0 ? `Additionally, ${trialWeldLogs.length} trial weld${trialWeldLogs.length !== 1 ? 's were' : ' was'} performed to validate welding parameters before production welding commenced.` : ''}`)
    }

    const passRateAcceptable = ndtPassRate >= 95 && dtPassRate >= 90
    const hasOpenIssues = openNCRs > 0
    
    if (totalTests > 0 || ncrLogs.length > 0) {
      if (passRateAcceptable && !hasOpenIssues) {
        paragraphs.push(`Based on the comprehensive quality assurance data collected, this project demonstrates excellent compliance with industry standards and project specifications. The high testing pass rates and successful resolution of all non-conformances indicate that the geomembrane installation meets or exceeds required quality standards. The installed liner system is deemed fit for purpose and ready for operational service.`)
      } else if (hasOpenIssues) {
        paragraphs.push(`The project has maintained acceptable quality standards overall. However, ${openNCRs} open non-conformance${openNCRs !== 1 ? 's require' : ' requires'} resolution before final certification. It is recommended that all outstanding NCRs be closed and appropriate corrective actions verified before the system is placed into service.`)
      } else {
        paragraphs.push(`The project quality metrics indicate areas requiring attention. Additional testing and verification may be warranted to ensure full compliance with project specifications. Continued monitoring and quality assurance oversight is recommended for the remaining project phases.`)
      }
    }

    return { paragraphs }
  }
  
  const generateSummary = (): string => {
    return `# CQA Final Summary Report

**Company:** ${settings.company || "N/A"}  
**Contact:** ${settings.contact || "N/A"}  
**Region:** ${settings.region || "N/A"}  
**Generated:** ${new Date().toLocaleString()}

---

## Summary Statistics

- **Sign On Records:** ${signOnLogs.length}
- **Daily Reports:** ${dailyLogs.length}
- **Machine Pre-Starts:** ${machinePreStartLogs.length}
- **Trial Welds:** ${trialWeldLogs.length}
- **Welds Logged:** ${weldLogs.length}
- **Repair Records:** ${repairLogs.length}
- **Panel Placements:** ${panelPlacementLogs.length}
- **Material Register:** ${materialRegisterLogs.length}
- **Non-Destructive Tests:**
  - Air Channel Tests: ${airLogs.length}
  - Vacuum Box Tests: ${vacuumLogs.length}
  - Spark/Holiday Tests: ${sparkLogs.length}
- **Destructive Tests:** ${destructiveLogs.length}
- **NCRs Registered:** ${ncrLogs.length}
- **As-Built Drawings:** ${asBuiltData.layers.reduce((sum, layer) => sum + layer.objects.length, 0)} objects across ${asBuiltData.layers.length} layer${asBuiltData.layers.length !== 1 ? 's' : ''}

## Final Portal Submissions

- **Total Submission Days:** ${Object.keys(finalPortal).length}
- **Total Submissions:** ${Object.values(finalPortal).reduce((sum, day) => sum + day.submissions.length, 0)}
- **Completed Days:** ${Object.values(finalPortal).filter(day => day.completionStatus === "complete").length}
- **Pending Days:** ${Object.values(finalPortal).filter(day => day.completionStatus === "incomplete").length}

---

## Notes

This report was generated from the LINR CQA logging application.
All data is stored locally in the browser and exported by the user.
`
  }

  const exportZip = async () => {
    const zip = new JSZip()

    zip.file("sign_on_sheet.csv", generateCSV(["Date", "Worker Name", "Company", "Time In", "Time Out"], signOnLogs))
    zip.file("daily_reports.csv", generateCSV(["Date", "Weather", "Crew", "Notes"], dailyLogs))
    zip.file("machine_pre_start.csv", generateCSV(["Date", "Machine", "Operator", "Pre-Check", "Notes"], machinePreStartLogs))
    zip.file("trial_welds.csv", generateCSV(["Date", "Time", "Tech", "Machine ID", "Weld Type", "Fusion Temp (°C)", "Fusion Speed (m/min)", "Extrusion Barrel (°C)", "Extrusion Preheat (°C)"], trialWeldLogs))
    zip.file("weld_log.csv", generateCSV(["Technician Name", "Machine ID", "Date", "Time", "Fusion Temp (°C)", "Fusion Speed (m/min)"], weldLogs))
    zip.file("repair_log.csv", generateCSV(["Date", "Location", "Bead Length / Patch Size", "Issue", "Tech", "Weld Type", "Barrel Temp (°C)", "Preheat Temp (°C)", "Fusion Temp (°C)", "Fusion Speed (m/min)", "Note"], repairLogs))
    zip.file("panel_placement.csv", generateCSV(["Date", "Time", "Ambient Temp (°C)", "Length of Panel (m)", "Location", "Roll Number"], panelPlacementLogs))
    zip.file("material_register.csv", generateCSV(["Date", "Roll ID", "Manufacturer", "Thickness (mm)", "Width (m)", "Length (m)", "Lot Number", "Note"], materialRegisterLogs))
    zip.file("air_channel_tests.csv", generateCSV(["Test ID", "Pressure (kPa)", "Duration (min)", "Result"], airLogs))
    zip.file("vacuum_box_tests.csv", generateCSV(["Test ID", "Pressure (kPa)", "Duration (min)", "Result"], vacuumLogs))
    zip.file("spark_holiday_tests.csv", generateCSV(["Test ID", "Voltage (V)", "Result"], sparkLogs))
    zip.file("destructive_tests.csv", generateCSV(["Sample ID", "Peel (N/mm)", "Shear (N/mm)", "Result"], destructiveLogs))
    zip.file("ncr_register.csv", generateCSV(["NCR ID", "Description", "Action", "Status"], ncrLogs))
    
    const submissionRows: string[][] = []
    Object.keys(finalPortal).sort().forEach(date => {
      const dayData = finalPortal[date]
      dayData.submissions.forEach(sub => {
        submissionRows.push([
          date,
          sub.role,
          sub.submittedBy,
          sub.crew || "",
          new Date(sub.timestamp).toLocaleString(),
          sub.logSnapshots.reduce((sum, snap) => sum + snap.count, 0).toString(),
          sub.status,
          sub.notes || ""
        ])
      })
    })
    zip.file("final_portal_submissions.csv", generateCSV(
      ["Date", "Role", "Submitted By", "Crew", "Timestamp", "Total Entries", "Status", "Notes"],
      submissionRows
    ))
    
    zip.file("final_summary.md", generateSummary())
    
    zip.file("as_built_drawings.json", JSON.stringify(asBuiltData, null, 2))

    const blob = await zip.generateAsync({ type: "blob" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `cqa_export_${Date.now()}.zip`
    a.click()
    URL.revokeObjectURL(url)
  }

  const clearAllProjectData = () => {
    if (!projectInfo) return
    
    if (confirm(`Are you sure you want to clear all data for project "${projectInfo.name}"? This cannot be undone.`)) {
      setSettings({ company: "", contact: "", region: "", logo: "" })
      setProjectSpecs({
        projectName: "",
        projectNumber: "",
        clientName: "",
        siteLocation: "",
        geomembraneType: "",
        specifiedThickness: "",
        totalArea: "",
        startDate: "",
        supervisor: "",
        contractor: "",
        qualityStandards: "",
        testingRequirements: "",
        minPeelPass: "",
        minShearPass: "",
        destructiveTestFrequency: ""
      })
      setSignOnLogs([])
      setDailyLogs([])
      setPanelPlacementLogs([])
      setMaterialRegisterLogs([])
      setWeldLogs([])
      setRepairLogs([])
      setAirLogs([])
      setVacuumLogs([])
      setSparkLogs([])
      setDestructiveLogs([])
      setMachinePreStartLogs([])
      setTrialWeldLogs([])
      setNcrLogs([])
      setFinalPortal({})
      setAsBuiltData({
        layers: [{ id: 1, name: "Base Layer", objects: [], isVisible: true }],
        activeLayerId: 1,
        nextLayerId: 2
      })
      setMaterialInventory({
        rolls: [],
        panelPlacements: [],
        nextPanelNumber: 1
      })
      localStorage.removeItem(storageKey("data"))
    }
  }

  const handlePrint = () => {
    window.print()
  }

  if (authLoading || termsAccepted === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse text-primary text-lg">Loading...</div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  if (projectLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-pulse text-primary text-lg mb-2">Loading project...</div>
          <p className="text-muted-foreground text-sm">Fetching project data and specifications</p>
        </div>
      </div>
    )
  }

  if (projectError) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Access Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">{projectError}</p>
            <Button onClick={goBackToHome} className="w-full">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to My Jobs
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!termsAccepted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-card/20 to-background flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl shadow-2xl bg-gradient-to-br from-card to-card/80 border-border/50">
          <CardHeader className="text-center pb-4 border-b border-border/30">
            <div className="flex justify-center mb-4">
              <img src="/icononly_transparent_nobuffer_1763974511214.png" alt="LINR" className="w-16 h-16 object-contain" />
            </div>
            <CardTitle className="text-2xl bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">Terms and Conditions</CardTitle>
            <CardDescription className="text-base mt-2">Please read and accept before using LINR</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="bg-background/50 rounded-lg p-4 mb-6 max-h-80 overflow-y-auto border border-border/30">
              <div className="text-sm text-muted-foreground space-y-4">
                <h3 className="text-foreground font-semibold text-base">1. Acceptance of Terms</h3>
                <p>By accessing and using the LINR CQA Logging Application, you accept and agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use this application.</p>
                
                <h3 className="text-foreground font-semibold text-base">2. Application Purpose</h3>
                <p>LINR is designed for Construction Quality Assurance (CQA) logging in geomembrane installation projects. The application stores all data locally in your browser and is intended for field documentation purposes.</p>
                
                <h3 className="text-foreground font-semibold text-base">3. Data Storage and Privacy</h3>
                <p>All project data is stored locally on your device using browser storage (localStorage). No data is transmitted to external servers. You are responsible for backing up your data through the export function. Clearing your browser data will permanently delete all stored information.</p>
                
                <h3 className="text-foreground font-semibold text-base">4. User Responsibilities</h3>
                <p>You are responsible for the accuracy of all data entered into the application. You should regularly export and backup your project data. You must ensure the application meets your specific project requirements before relying on it for official documentation.</p>
                
                <h3 className="text-foreground font-semibold text-base">5. Limitation of Liability</h3>
                <p>This application is provided &quot;as is&quot; without warranties of any kind. The developers are not liable for any data loss, errors, or damages arising from the use of this application. Users should verify all critical data independently.</p>
                
                <h3 className="text-foreground font-semibold text-base">6. Intellectual Property</h3>
                <p>All content, design, and functionality of the LINR application are protected by intellectual property rights. You may use the application for its intended purpose but may not copy, modify, or distribute the application without permission.</p>
                
                <h3 className="text-foreground font-semibold text-base">7. Updates and Modifications</h3>
                <p>These terms may be updated from time to time. Continued use of the application after changes constitutes acceptance of the new terms.</p>
                
                <h3 className="text-foreground font-semibold text-base">8. Governing Law</h3>
                <p>These terms shall be governed by and construed in accordance with applicable laws. Any disputes shall be resolved through appropriate legal channels.</p>
              </div>
            </div>
            
            <Button 
              onClick={acceptTerms}
              className="w-full bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary/80 text-primary-foreground h-12 text-base font-semibold shadow-lg"
            >
              I Accept the Terms and Conditions
            </Button>
            
            <p className="text-xs text-muted-foreground text-center mt-4">
              By clicking the button above, you confirm that you have read, understood, and agree to these terms.
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border sticky top-0 z-50 shadow-lg">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {settings.logo && (
                <img 
                  src={settings.logo} 
                  alt="Logo" 
                  className="h-12 w-auto object-contain" 
                />
              )}
              <div>
                <h1 className="text-2xl font-semibold text-primary">{projectInfo?.name || projectSpecs.projectName || "LINR"}</h1>
                <p className="text-sm text-muted-foreground">CQA Logging Application</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2 no-print">
              <Button onClick={goBackToHome} variant="outline" className="border-border h-11 px-3 sm:px-4">
                <ArrowLeft className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">My Jobs</span>
              </Button>
              <Button onClick={handlePrint} variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground h-11 px-3 sm:px-4">
                <Printer className="h-4 w-4 sm:mr-2" />
                <span className="hidden sm:inline">Print</span>
              </Button>
              <Button onClick={exportZip} className="bg-primary hover:bg-primary/90 text-primary-foreground h-11 px-3 sm:px-4">
                <Download className="h-4 w-4 sm:mr-2" />
                <span className="hidden tablet:inline">Export ZIP</span>
                <span className="tablet:hidden">Export</span>
              </Button>
              <Button onClick={clearAllProjectData} className="bg-accent hover:bg-accent/90 text-accent-foreground h-11 px-3 text-xs sm:text-sm">
                <span className="hidden sm:inline">Clear Project Data</span>
                <span className="sm:hidden">Clear</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 sm:px-6 py-4 sm:py-8">
        <div className="mb-6 sm:mb-8 bg-card border border-border rounded-lg p-3 sm:p-4 shadow-sm no-print">
          <div className="flex flex-wrap gap-2 sm:gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Daily Operations <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setActiveModule("signon")} className="cursor-pointer">Sign On Sheet</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("machineprestart")} className="cursor-pointer">Machine Pre-Start Check</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("daily")} className="cursor-pointer">Daily Summary</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Technicians <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setActiveModule("trialwelds")} className="cursor-pointer">Trial Welds</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("welds")} className="cursor-pointer">Weld Log (Panel Seaming)</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("repairs")} className="cursor-pointer">Repair Log</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Testing <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setActiveModule("nondestructive")} className="cursor-pointer">Non-Destructive Testing</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("destructive")} className="cursor-pointer">Destructive Tests</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Materials <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setActiveModule("panelplacement")} className="cursor-pointer">Panel Placement</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("materialregister")} className="cursor-pointer">Material Register</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" onClick={() => setActiveModule("ncr")}>Quality (NCR)</Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline">
                  Reports <ChevronDown className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setActiveModule("asbuilt")} className="cursor-pointer">As-Built Drawings</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("report")} className="cursor-pointer">CQA Report</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveModule("finalportal")} className="cursor-pointer">Final Joint Portal</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" onClick={() => setActiveModule("engineers")}>Engineers</Button>
            <Button variant="outline" onClick={() => setActiveModule("settings")}>Settings</Button>
            <Button variant="outline" onClick={() => setActiveModule("userguide")} className="bg-primary/10 hover:bg-primary/20 border-primary/30">User Guide</Button>
          </div>
        </div>

        <div className="w-full">
          {activeModule === "engineers" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Engineers Section - Project Configuration</CardTitle>
                <CardDescription>Configure project specifications, technical requirements, and quality standards</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProjectSpecsSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="projectName">Project Name</Label>
                      <Input
                        id="projectName"
                        name="projectName"
                        value={projectSpecs.projectName}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, projectName: e.target.value })}
                        placeholder="Enter project name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="projectNumber">Project Number</Label>
                      <Input
                        id="projectNumber"
                        name="projectNumber"
                        value={projectSpecs.projectNumber}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, projectNumber: e.target.value })}
                        placeholder="Project ID or reference number"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="clientName">Client Name</Label>
                      <Input
                        id="clientName"
                        name="clientName"
                        value={projectSpecs.clientName}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, clientName: e.target.value })}
                        placeholder="Client organization"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="siteLocation">Site Location</Label>
                      <Input
                        id="siteLocation"
                        name="siteLocation"
                        value={projectSpecs.siteLocation}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, siteLocation: e.target.value })}
                        placeholder="Project site address or coordinates"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="geomembraneType">Geomembrane Type/Material</Label>
                      <Input
                        id="geomembraneType"
                        name="geomembraneType"
                        value={projectSpecs.geomembraneType}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, geomembraneType: e.target.value })}
                        placeholder="e.g., HDPE, LLDPE, fPP"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specifiedThickness">Specified Thickness (mm)</Label>
                      <Input
                        id="specifiedThickness"
                        name="specifiedThickness"
                        type="number"
                        step="0.01"
                        value={projectSpecs.specifiedThickness}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, specifiedThickness: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="totalArea">Total Area (m²)</Label>
                      <Input
                        id="totalArea"
                        name="totalArea"
                        type="number"
                        step="0.01"
                        value={projectSpecs.totalArea}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, totalArea: e.target.value })}
                        placeholder="0.00"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="startDate">Project Start Date</Label>
                      <Input
                        id="startDate"
                        name="startDate"
                        type="date"
                        value={projectSpecs.startDate}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, startDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="supervisor">Project Supervisor</Label>
                      <Input
                        id="supervisor"
                        name="supervisor"
                        value={projectSpecs.supervisor}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, supervisor: e.target.value })}
                        placeholder="Name of supervisor/engineer"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contractor">Contractor Name</Label>
                      <Input
                        id="contractor"
                        name="contractor"
                        value={projectSpecs.contractor}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, contractor: e.target.value })}
                        placeholder="Main contractor"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="qualityStandards">Quality Standards / Requirements</Label>
                    <Textarea
                      id="qualityStandards"
                      name="qualityStandards"
                      value={projectSpecs.qualityStandards}
                      onChange={(e) => saveProjectSpecs({ ...projectSpecs, qualityStandards: e.target.value })}
                      placeholder="Enter applicable standards (e.g., ASTM D7466, GRI GM-13, etc.) and any specific quality requirements"
                      rows={3}
                      className="resize-none"
                    />
                  </div>

                  <Separator className="my-6" />
                  <h3 className="text-lg font-semibold mb-4">Testing Requirements</h3>

                  <div className="space-y-2">
                    <Label htmlFor="testingRequirements">Testing Requirements Description</Label>
                    <Textarea
                      id="testingRequirements"
                      name="testingRequirements"
                      value={projectSpecs.testingRequirements}
                      onChange={(e) => saveProjectSpecs({ ...projectSpecs, testingRequirements: e.target.value })}
                      placeholder="Describe destructive and non-destructive testing requirements, sampling protocols, etc."
                      rows={3}
                      className="resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="minPeelPass">Minimum Peel Pass (N/mm)</Label>
                      <Input
                        id="minPeelPass"
                        name="minPeelPass"
                        type="number"
                        step="0.1"
                        value={projectSpecs.minPeelPass}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, minPeelPass: e.target.value })}
                        placeholder="0.0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="minShearPass">Minimum Shear Pass (N/mm)</Label>
                      <Input
                        id="minShearPass"
                        name="minShearPass"
                        type="number"
                        step="0.1"
                        value={projectSpecs.minShearPass}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, minShearPass: e.target.value })}
                        placeholder="0.0"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="destructiveTestFrequency">Destructive Test Frequency (m)</Label>
                      <Input
                        id="destructiveTestFrequency"
                        name="destructiveTestFrequency"
                        type="number"
                        step="1"
                        value={projectSpecs.destructiveTestFrequency}
                        onChange={(e) => saveProjectSpecs({ ...projectSpecs, destructiveTestFrequency: e.target.value })}
                        placeholder="e.g., 150"
                      />
                      <p className="text-xs text-muted-foreground">Sample required every X meters of welding</p>
                    </div>
                  </div>

                  {projectSpecs.destructiveTestFrequency && (
                    <div className="mt-4 p-4 bg-accent/10 border border-accent/30 rounded-lg">
                      <h4 className="font-semibold text-accent mb-2">Destructive Sample Due Points</h4>
                      <p className="text-sm text-accent mb-2">
                        Based on your frequency of {projectSpecs.destructiveTestFrequency}m per sample, destructive tests are due at:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {Array.from({ length: 20 }, (_, i) => (i + 1) * parseFloat(projectSpecs.destructiveTestFrequency)).map((duePoint, idx) => (
                          <span key={idx} className="px-3 py-1 bg-accent/20 text-accent rounded-md text-sm font-medium">
                            {duePoint.toFixed(0)}m
                          </span>
                        ))}
                      </div>
                      <p className="text-xs text-accent-foreground mt-3">
                        First 20 sample points shown. Continue pattern for project duration.
                      </p>
                    </div>
                  )}

                  <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 text-sm text-primary">
                    <strong>Note:</strong> These specifications will be saved automatically and remain active throughout the project lifecycle. They will also appear in the CQA Report.
                  </div>
                </form>
              </CardContent>
            </Card>
          )}

          {activeModule === "settings" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <SettingsIcon className="h-5 w-5" />
                  Settings
                </CardTitle>
                <CardDescription>Configure company information and branding</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="company">Company Name</Label>
                  <Input
                    id="company"
                    value={settings.company}
                    onChange={(e) => saveSettings({ ...settings, company: e.target.value })}
                    placeholder="Enter company name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact">Contact Information</Label>
                  <Input
                    id="contact"
                    value={settings.contact}
                    onChange={(e) => saveSettings({ ...settings, contact: e.target.value })}
                    placeholder="Email or phone"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="region">Region</Label>
                  <Input
                    id="region"
                    value={settings.region}
                    onChange={(e) => saveSettings({ ...settings, region: e.target.value })}
                    placeholder="Project region"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="logo">Company Logo</Label>
                  <Input
                    id="logo"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                  />
                  {settings.logo && (
                    <div className="mt-2">
                      <img src={settings.logo} alt="Company logo preview" className="h-20 w-auto border rounded" />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "signon" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Daily Sign On Sheet</CardTitle>
                <CardDescription>Track workers signing in and out each day</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addSignOn} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <Input id="date" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="name">Worker Name</Label>
                      <Input id="name" name="name" required placeholder="Full name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" name="company" placeholder="Company name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="timeIn">Time In</Label>
                      <Input id="timeIn" name="timeIn" type="time" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="timeOut">Time Out</Label>
                      <Input id="timeOut" name="timeOut" type="time" placeholder="Optional" />
                    </div>
                  </div>
                  <Button type="submit">Add Worker</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Worker Name</th>
                        <th className="p-2 text-left">Company</th>
                        <th className="p-2 text-left">Time In</th>
                        <th className="p-2 text-left">Time Out</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {signOnLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteSignOn(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "machineprestart" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Machine/Equipment Pre-Start</CardTitle>
                <CardDescription>Log daily machine pre-start checks</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addMachinePreStart} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="prestartDate">Date</Label>
                      <Input id="prestartDate" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machine">Machine</Label>
                      <Input id="machine" name="machine" required placeholder="Machine ID/Name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="operator">Operator</Label>
                      <Input id="operator" name="operator" required placeholder="Operator name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="preCheck">Pre-Check</Label>
                      <select id="preCheck" name="preCheck" className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                        <option value="Pass">Pass</option>
                        <option value="Fail">Fail</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="prestartNotes">Notes</Label>
                      <Input id="prestartNotes" name="notes" placeholder="Optional notes" />
                    </div>
                  </div>
                  <Button type="submit">Add Entry</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Machine</th>
                        <th className="p-2 text-left">Operator</th>
                        <th className="p-2 text-left">Pre-Check</th>
                        <th className="p-2 text-left">Notes</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {machinePreStartLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteMachinePreStart(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "trialwelds" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Trial Welds</CardTitle>
                <CardDescription>Log trial weld results - settings auto-populate to Weld Log for production welds</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addTrialWeld} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <Input id="date" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="time">Time</Label>
                      <Input id="time" name="time" type="time" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tech">Tech Name</Label>
                      <Input id="tech" name="tech" required placeholder="Technician name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="iagiNumber">IAGI # (optional)</Label>
                      <Input id="iagiNumber" name="iagiNumber" placeholder="IAGI certification #" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machineId">Machine ID</Label>
                      <Input id="machineId" name="machineId" required placeholder="Machine ID" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weldType">Weld Type</Label>
                      <Input id="weldType" name="weldType" required placeholder="e.g. Fusion/Extrusion" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fusionTemp">Fusion Temp (°C)</Label>
                      <Input id="fusionTemp" name="fusionTemp" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fusionSpeed">Fusion Speed (m/min)</Label>
                      <Input id="fusionSpeed" name="fusionSpeed" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="extrusionBarrel">Extrusion Barrel (°C)</Label>
                      <Input id="extrusionBarrel" name="extrusionBarrel" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="extrusionPreheat">Extrusion Preheat (°C)</Label>
                      <Input id="extrusionPreheat" name="extrusionPreheat" type="number" step="0.1" placeholder="0.0" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    💡 After completing a trial weld, your settings will auto-populate in the Weld Log for the next 4 hours.
                  </p>
                  <Button type="submit">Add Trial Weld</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Time</th>
                        <th className="p-2 text-left">Tech</th>
                        <th className="p-2 text-left">IAGI #</th>
                        <th className="p-2 text-left">Machine ID</th>
                        <th className="p-2 text-left">Weld Type</th>
                        <th className="p-2 text-left">Fusion Temp</th>
                        <th className="p-2 text-left">Fusion Speed</th>
                        <th className="p-2 text-left">Barrel (°C)</th>
                        <th className="p-2 text-left">Preheat (°C)</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {trialWeldLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[9] || '-'}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2">{row[5]}</td>
                          <td className="p-2">{row[6]}</td>
                          <td className="p-2">{row[7]}</td>
                          <td className="p-2">{row[8]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteTrialWeld(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "daily" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Daily Summary</CardTitle>
                <CardDescription>Log daily project summaries</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addDaily} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="date">Date</Label>
                      <Input id="date" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="weather">Weather</Label>
                      <Input id="weather" name="weather" placeholder="e.g. Sunny" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="crew">Crew</Label>
                      <Input id="crew" name="crew" placeholder="e.g. 3 welders" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="notes">Notes</Label>
                      <Input id="notes" name="notes" placeholder="Daily notes" />
                    </div>
                  </div>
                  <Button type="submit">Add Entry</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Weather</th>
                        <th className="p-2 text-left">Crew</th>
                        <th className="p-2 text-left">Notes</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dailyLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteDaily(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "panelplacement" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>{editingPanelIndex !== null ? "Edit Panel" : "Panel Placement"}</CardTitle>
                <CardDescription>
                  {editingPanelIndex !== null 
                    ? `Editing Panel #${panelPlacementLogs[editingPanelIndex]?.[0] || ""}`
                    : "Track panel installation and placement with sequential numbering"
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addPanelPlacement} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="ppPanelNumber">Panel #</Label>
                      <Input 
                        id="ppPanelNumber" 
                        name="panelNumber" 
                        type="number"
                        min="1"
                        placeholder="Auto"
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[0] : getNextLogPanelNumber()}
                        key={editingPanelIndex !== null ? `edit-${editingPanelIndex}` : `add-${panelPlacementLogs.length}`}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ppDate">Date</Label>
                      <Input 
                        id="ppDate" 
                        name="date" 
                        type="date" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[1] : ""}
                        key={editingPanelIndex !== null ? `edit-date-${editingPanelIndex}` : `add-date`}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ppTime">Time</Label>
                      <Input 
                        id="ppTime" 
                        name="time" 
                        type="time" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[2] : ""}
                        key={editingPanelIndex !== null ? `edit-time-${editingPanelIndex}` : `add-time`}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ppAmbientTemp">Ambient Temp (°C)</Label>
                      <Input 
                        id="ppAmbientTemp" 
                        name="ambientTemp" 
                        type="number" 
                        step="0.1" 
                        placeholder="0.0" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[3] : ""}
                        key={editingPanelIndex !== null ? `edit-temp-${editingPanelIndex}` : `add-temp`}
                        required 
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="ppLength">Length of Panel (m)</Label>
                      <Input 
                        id="ppLength" 
                        name="length" 
                        type="number" 
                        step="0.01" 
                        placeholder="0.00" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[4] : ""}
                        key={editingPanelIndex !== null ? `edit-length-${editingPanelIndex}` : `add-length`}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ppLocation">Location</Label>
                      <Input 
                        id="ppLocation" 
                        name="location" 
                        placeholder="Location" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[5] : ""}
                        key={editingPanelIndex !== null ? `edit-loc-${editingPanelIndex}` : `add-loc`}
                        required 
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ppRollNumber">Roll Number</Label>
                      <Input 
                        id="ppRollNumber" 
                        name="rollNumber" 
                        placeholder="Roll number" 
                        defaultValue={editingPanelIndex !== null ? panelPlacementLogs[editingPanelIndex]?.[6] : ""}
                        key={editingPanelIndex !== null ? `edit-roll-${editingPanelIndex}` : `add-roll`}
                        required 
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" className={editingPanelIndex !== null ? "bg-primary" : ""}>
                      {editingPanelIndex !== null ? "Save Changes" : "Add Panel Placement"}
                    </Button>
                    {editingPanelIndex !== null && (
                      <Button type="button" variant="outline" onClick={cancelEditPanel}>
                        Cancel
                      </Button>
                    )}
                  </div>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Panel #</th>
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Time</th>
                        <th className="p-2 text-left">Ambient Temp (°C)</th>
                        <th className="p-2 text-left">Length (m)</th>
                        <th className="p-2 text-left">Location</th>
                        <th className="p-2 text-left">Roll Number</th>
                        <th className="p-2 text-left no-print">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {panelPlacementLogs.map((row, i) => (
                        <tr key={i} className={`border-b ${editingPanelIndex === i ? "bg-primary/10" : ""}`}>
                          <td className="p-2 font-medium">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2">{row[5]}</td>
                          <td className="p-2">{row[6]}</td>
                          <td className="p-2 no-print">
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => startEditPanel(i)}
                                className="h-8 w-8 p-0 text-primary hover:text-primary/80 hover:bg-primary/10"
                                disabled={editingPanelIndex !== null}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => deletePanelPlacement(i)}
                                className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                                disabled={editingPanelIndex !== null}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "materialregister" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Material Register</CardTitle>
                <CardDescription>Track geomembrane rolls and material details</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addMaterialRegister} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="mrDate">Date</Label>
                      <Input id="mrDate" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrRollId">Roll ID</Label>
                      <Input id="mrRollId" name="rollId" required placeholder="Roll ID" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrManufacturer">Manufacturer</Label>
                      <Input id="mrManufacturer" name="manufacturer" placeholder="Manufacturer" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrThickness">Thickness (mm)</Label>
                      <Input id="mrThickness" name="thickness" type="number" step="0.1" placeholder="0.0" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="mrWidth">Width (m)</Label>
                      <Input id="mrWidth" name="width" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrLength">Length (m)</Label>
                      <Input id="mrLength" name="length" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrLot">Lot Number</Label>
                      <Input id="mrLot" name="lotNumber" placeholder="Lot number" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="mrNote">Note</Label>
                      <Input id="mrNote" name="note" placeholder="Optional" />
                    </div>
                  </div>
                  <Button type="submit">Add Material</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Roll ID</th>
                        <th className="p-2 text-left">Manufacturer</th>
                        <th className="p-2 text-left">Thickness (mm)</th>
                        <th className="p-2 text-left">Width (m)</th>
                        <th className="p-2 text-left">Length (m)</th>
                        <th className="p-2 text-left">Lot Number</th>
                        <th className="p-2 text-left">Note</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {materialRegisterLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2">{row[5]}</td>
                          <td className="p-2">{row[6]}</td>
                          <td className="p-2">{row[7]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteMaterialRegister(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <Separator className="my-6" />
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">Active Rolls Inventory</h3>
                      <p className="text-sm text-muted-foreground">Activate rolls for panel placement and track remaining material in real-time</p>
                    </div>
                  </div>
                  
                  {materialRegisterLogs.length > 0 && (
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <Label className="text-sm font-medium">Activate Roll from Register</Label>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        {materialRegisterLogs.map((row, i) => {
                          const isAlreadyActive = materialInventory.rolls.some(r => r.linkedRegisterIndex === i)
                          return (
                            <Button
                              key={i}
                              variant={isAlreadyActive ? "secondary" : "outline"}
                              size="sm"
                              onClick={() => !isAlreadyActive && activateRollFromRegister(i)}
                              disabled={isAlreadyActive}
                              className="text-xs"
                            >
                              {row[1]} ({row[4]}m x {row[5]}m)
                              {isAlreadyActive && " - Active"}
                            </Button>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {getActiveRolls().length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="p-2 text-left">Roll ID</th>
                            <th className="p-2 text-left">Width (m)</th>
                            <th className="p-2 text-left">Full Length (m)</th>
                            <th className="p-2 text-left">Remaining (m)</th>
                            <th className="p-2 text-left">Used</th>
                            <th className="p-2 text-left">Status</th>
                            <th className="p-2 text-left">Material</th>
                            <th className="p-2 text-left no-print">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {getActiveRolls().map((roll) => (
                            <tr key={roll.id} className={`border-b ${isRollLow(roll) ? 'bg-orange-50 dark:bg-orange-950/20' : ''}`}>
                              <td className="p-2 font-mono font-semibold">{roll.rollId}</td>
                              <td className="p-2">{roll.widthM.toFixed(1)}</td>
                              <td className="p-2">{roll.fullLengthM.toFixed(1)}</td>
                              <td className="p-2 font-semibold text-primary">{roll.remainingLengthM.toFixed(1)}</td>
                              <td className="p-2">
                                <div className="flex items-center gap-2">
                                  <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full ${isRollLow(roll) ? 'bg-orange-500' : 'bg-primary'}`}
                                      style={{ width: `${100 - getRollRemainingPercentage(roll)}%` }}
                                    />
                                  </div>
                                  <span className="text-xs text-muted-foreground">
                                    {100 - getRollRemainingPercentage(roll)}%
                                  </span>
                                </div>
                              </td>
                              <td className="p-2">
                                {isRollLow(roll) ? (
                                  <span className="text-xs px-2 py-1 bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200 rounded-full">
                                    Low Stock
                                  </span>
                                ) : (
                                  <span className="text-xs px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 rounded-full">
                                    Available
                                  </span>
                                )}
                              </td>
                              <td className="p-2 text-sm">{roll.materialType}</td>
                              <td className="p-2 no-print">
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  onClick={() => deactivateRoll(roll.id)}
                                  className="h-8 text-xs"
                                >
                                  Deactivate
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No active rolls. Activate a roll from the register above or add one manually.</p>
                    </div>
                  )}

                  {materialInventory.panelPlacements.length > 0 && (
                    <>
                      <Separator className="my-4" />
                      <div>
                        <h4 className="text-md font-semibold mb-2">Panel Placements ({materialInventory.panelPlacements.length})</h4>
                        <div className="overflow-x-auto">
                          <table className="w-full border-collapse text-sm">
                            <thead>
                              <tr className="border-b bg-muted/50">
                                <th className="p-2 text-left">Panel #</th>
                                <th className="p-2 text-left">Roll ID</th>
                                <th className="p-2 text-left">Dimensions (L x W)</th>
                                <th className="p-2 text-left">Placed At</th>
                              </tr>
                            </thead>
                            <tbody>
                              {materialInventory.panelPlacements.map((panel) => (
                                <tr key={panel.id} className="border-b">
                                  <td className="p-2 font-mono font-semibold text-primary">{panel.panelNumber}</td>
                                  <td className="p-2">{panel.rollId}</td>
                                  <td className="p-2">{panel.lengthM.toFixed(1)}m x {panel.widthM.toFixed(1)}m</td>
                                  <td className="p-2 text-muted-foreground">
                                    {new Date(panel.placedAt).toLocaleString()}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "welds" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Weld Log</CardTitle>
                <CardDescription>Panel seam fusion welding log - settings autofill from recent trial welds. Seam numbers auto-track.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addWeld} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="seamNumber">Seam #</Label>
                      <Input 
                        id="seamNumber" 
                        name="seamNumber" 
                        defaultValue={`S${String(weldLogs.length + 1).padStart(3, '0')}`}
                        placeholder="S001"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="technicianName">Technician Name</Label>
                      <Input 
                        id="technicianName" 
                        name="technicianName" 
                        required 
                        placeholder="Welder name"
                        defaultValue={getRecentTrialWeldSettings()?.techName || ""}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="iagiNumber">IAGI # (optional)</Label>
                      <Input 
                        id="iagiNumber" 
                        name="iagiNumber" 
                        placeholder="IAGI certification #"
                        defaultValue={getRecentTrialWeldSettings()?.iagiNumber || ""}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machineId">Machine ID</Label>
                      <Input 
                        id="machineId" 
                        name="machineId" 
                        required 
                        placeholder="Machine number"
                        defaultValue={getRecentTrialWeldSettings()?.machineId || ""}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machineTemp">Fusion Temp (°C)</Label>
                      <Input 
                        id="machineTemp" 
                        name="machineTemp" 
                        type="number" 
                        step="0.1" 
                        defaultValue={getRecentTrialWeldSettings()?.machineTemp || ""}
                        placeholder="0.0"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="machineSpeed">Fusion Speed (m/min)</Label>
                      <Input 
                        id="machineSpeed" 
                        name="machineSpeed" 
                        type="number" 
                        step="0.1" 
                        defaultValue={getRecentTrialWeldSettings()?.machineSpeed || ""}
                        placeholder="0.0"
                        required
                      />
                    </div>
                  </div>
                  {trialWeldLogs.length > 0 && getRecentTrialWeldSettings() && (
                    <p className="text-sm text-muted-foreground">
                      💡 Settings autofilled from recent trial weld ({getRecentTrialWeldSettings()?.techName}). Date/time set automatically.
                    </p>
                  )}
                  <Button type="submit">Add Weld</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Seam #</th>
                        <th className="p-2 text-left">Technician</th>
                        <th className="p-2 text-left">IAGI #</th>
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Time</th>
                        <th className="p-2 text-left">Fusion Temp (°C)</th>
                        <th className="p-2 text-left">Fusion Speed (m/min)</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {weldLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2 font-mono font-semibold text-primary">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2] || '-'}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2">{row[5]}</td>
                          <td className="p-2">{row[6]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteWeld(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "repairs" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Repair Log</CardTitle>
                <CardDescription>Track repairs and remedial work - defaults to extrusion for standard repairs, switch to seam style for wall lift/tie-in</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addRepair} className="space-y-4 mb-6">
                  <div className="flex gap-2 mb-4">
                    <Button
                      type="button"
                      variant={repairWeldType === 'extrusion' ? 'default' : 'outline'}
                      onClick={() => setRepairWeldType('extrusion')}
                      className="flex-1"
                    >
                      Extrusion Weld
                    </Button>
                    <Button
                      type="button"
                      variant={repairWeldType === 'seam' ? 'default' : 'outline'}
                      onClick={() => setRepairWeldType('seam')}
                      className="flex-1"
                    >
                      Seam Style (Wall Lift/Tie-In)
                    </Button>
                  </div>
                  <input type="hidden" name="weldType" value={repairWeldType === 'extrusion' ? 'Extrusion' : 'Seam Style'} />
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="repairDate">Date</Label>
                      <Input id="repairDate" name="date" type="date" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairLocation">Location</Label>
                      <Input id="repairLocation" name="location" placeholder="Location" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairSize">Bead Length / Patch Size</Label>
                      <Input id="repairSize" name="size" placeholder="e.g., 2.5m or 300x200mm" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairIssue">Issue</Label>
                      <Input id="repairIssue" name="issue" placeholder="Issue description" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="repairTech">Tech</Label>
                      <Input 
                        id="repairTech" 
                        name="tech" 
                        placeholder="Technician"
                        defaultValue={repairWeldType === 'extrusion' 
                          ? getRecentExtrusionTrialWeldSettings()?.techName || ""
                          : getRecentFusionTrialWeldSettings()?.techName || ""}
                        key={`tech-${repairWeldType}`}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="repairNote">Note</Label>
                      <Input id="repairNote" name="note" placeholder="Optional" />
                    </div>
                  </div>
                  {repairWeldType === 'extrusion' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="repairBarrelTemp">Barrel Temp (°C)</Label>
                        <Input 
                          id="repairBarrelTemp" 
                          name="barrelTemp" 
                          type="number" 
                          step="0.1" 
                          placeholder="0.0"
                          defaultValue={getRecentExtrusionTrialWeldSettings()?.barrelTemp || ""}
                          key={`barrel-${repairWeldType}`}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="repairPreheatTemp">Preheat Temp (°C)</Label>
                        <Input 
                          id="repairPreheatTemp" 
                          name="preheatTemp" 
                          type="number" 
                          step="0.1" 
                          placeholder="0.0"
                          defaultValue={getRecentExtrusionTrialWeldSettings()?.preheatTemp || ""}
                          key={`preheat-${repairWeldType}`}
                        />
                      </div>
                    </div>
                  )}
                  {repairWeldType === 'seam' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="repairFusionTemp">Fusion Temp (°C)</Label>
                        <Input 
                          id="repairFusionTemp" 
                          name="fusionTemp" 
                          type="number" 
                          step="0.1" 
                          placeholder="0.0"
                          defaultValue={getRecentFusionTrialWeldSettings()?.fusionTemp || ""}
                          key={`fusion-${repairWeldType}`}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="repairFusionSpeed">Fusion Speed (m/min)</Label>
                        <Input 
                          id="repairFusionSpeed" 
                          name="fusionSpeed" 
                          type="number" 
                          step="0.1" 
                          placeholder="0.0"
                          defaultValue={getRecentFusionTrialWeldSettings()?.fusionSpeed || ""}
                          key={`speed-${repairWeldType}`}
                        />
                      </div>
                    </div>
                  )}
                  {repairWeldType === 'extrusion' && trialWeldLogs.length > 0 && getRecentExtrusionTrialWeldSettings() && (
                    <p className="text-sm text-muted-foreground">
                      Settings autofilled from recent extrusion trial weld ({getRecentExtrusionTrialWeldSettings()?.techName}).
                    </p>
                  )}
                  {repairWeldType === 'seam' && trialWeldLogs.length > 0 && getRecentFusionTrialWeldSettings() && (
                    <p className="text-sm text-muted-foreground">
                      Settings autofilled from recent fusion trial weld ({getRecentFusionTrialWeldSettings()?.techName}).
                    </p>
                  )}
                  <Button type="submit">Add Repair</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Date</th>
                        <th className="p-2 text-left">Location</th>
                        <th className="p-2 text-left">Bead/Patch Size</th>
                        <th className="p-2 text-left">Issue</th>
                        <th className="p-2 text-left">Tech</th>
                        <th className="p-2 text-left">Weld Type</th>
                        <th className="p-2 text-left">Barrel (°C)</th>
                        <th className="p-2 text-left">Preheat (°C)</th>
                        <th className="p-2 text-left">Fusion (°C)</th>
                        <th className="p-2 text-left">Speed (m/min)</th>
                        <th className="p-2 text-left">Note</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {repairLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2">{row[4]}</td>
                          <td className="p-2">{row[5]}</td>
                          <td className="p-2">{row[6] || '-'}</td>
                          <td className="p-2">{row[7] || '-'}</td>
                          <td className="p-2">{row[8] || '-'}</td>
                          <td className="p-2">{row[9] || '-'}</td>
                          <td className="p-2">{row[10]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteRepair(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "destructive" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Destructive Tests</CardTitle>
                <CardDescription>Log destructive test results</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addDestructive} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="sampleId">Sample ID</Label>
                      <Input id="sampleId" name="sampleId" required placeholder="Sample ID" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="peel">Peel (N/mm)</Label>
                      <Input id="peel" name="peel" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="shear">Shear (N/mm)</Label>
                      <Input id="shear" name="shear" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="destResult">Result</Label>
                      <Input id="destResult" name="result" placeholder="Pass/Fail" />
                    </div>
                  </div>
                  <Button type="submit">Add Test</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Sample ID</th>
                        <th className="p-2 text-left">Peel (N/mm)</th>
                        <th className="p-2 text-left">Shear (N/mm)</th>
                        <th className="p-2 text-left">Result</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {destructiveLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteDestructive(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "nondestructive" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>Non-Destructive Testing</CardTitle>
                <CardDescription>Air Channel, Vacuum Box, and Spark/Holiday Tests</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addNonDestructive} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="ndtTestType">Test Type</Label>
                      <select 
                        id="ndtTestType" 
                        name="testType" 
                        required 
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                        onChange={(e) => {
                          const form = e.target.form
                          const pressureField = form?.querySelector('#ndtPressure')?.parentElement
                          const durationField = form?.querySelector('#ndtDuration')?.parentElement
                          const voltageField = form?.querySelector('#ndtVoltage')?.parentElement
                          
                          if (e.target.value === 'Air' || e.target.value === 'Vacuum') {
                            pressureField?.classList.remove('hidden')
                            durationField?.classList.remove('hidden')
                            voltageField?.classList.add('hidden')
                          } else if (e.target.value === 'Spark') {
                            pressureField?.classList.add('hidden')
                            durationField?.classList.add('hidden')
                            voltageField?.classList.remove('hidden')
                          }
                        }}
                      >
                        <option value="">Select Type</option>
                        <option value="Air">Air Channel</option>
                        <option value="Vacuum">Vacuum Box</option>
                        <option value="Spark">Spark/Holiday</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ndtTestId">Test ID</Label>
                      <Input id="ndtTestId" name="testId" required placeholder="Test ID" />
                    </div>
                    <div className="space-y-2 hidden" id="pressureField">
                      <Label htmlFor="ndtPressure">Pressure (kPa)</Label>
                      <Input id="ndtPressure" name="pressure" type="number" step="0.1" placeholder="0.0" />
                    </div>
                    <div className="space-y-2 hidden" id="durationField">
                      <Label htmlFor="ndtDuration">Duration (min)</Label>
                      <Input id="ndtDuration" name="duration" type="number" placeholder="0" />
                    </div>
                    <div className="space-y-2 hidden" id="voltageField">
                      <Label htmlFor="ndtVoltage">Voltage (V)</Label>
                      <Input id="ndtVoltage" name="voltage" type="number" placeholder="0" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="ndtResult">Result</Label>
                      <Input id="ndtResult" name="result" placeholder="Pass/Fail" />
                    </div>
                  </div>
                  <Button type="submit">Add Test</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">Test Type</th>
                        <th className="p-2 text-left">Test ID</th>
                        <th className="p-2 text-left">Pressure (kPa)</th>
                        <th className="p-2 text-left">Duration (min)</th>
                        <th className="p-2 text-left">Voltage (V)</th>
                        <th className="p-2 text-left">Result</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {airLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">Air</td>
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">-</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteAir(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                      {vacuumLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">Vacuum</td>
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">-</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteVacuum(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                      {sparkLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">Spark</td>
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">-</td>
                          <td className="p-2">-</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteSpark(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "ncr" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>NCR Register</CardTitle>
                <CardDescription>Non-Conformance Report tracking</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={addNCR} className="space-y-4 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="ncrId">NCR ID</Label>
                      <Input id="ncrId" name="ncrId" required placeholder="NCR ID" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Input id="description" name="description" placeholder="Description" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="action">Action</Label>
                      <Input id="action" name="action" placeholder="Corrective action" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="status">Status</Label>
                      <Input id="status" name="status" placeholder="Open/Closed" />
                    </div>
                  </div>
                  <Button type="submit">Add NCR</Button>
                </form>
                <Separator className="my-4" />
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="p-2 text-left">NCR ID</th>
                        <th className="p-2 text-left">Description</th>
                        <th className="p-2 text-left">Action</th>
                        <th className="p-2 text-left">Status</th>
                        <th className="p-2 text-left no-print">Delete</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ncrLogs.map((row, i) => (
                        <tr key={i} className="border-b">
                          <td className="p-2">{row[0]}</td>
                          <td className="p-2">{row[1]}</td>
                          <td className="p-2">{row[2]}</td>
                          <td className="p-2">{row[3]}</td>
                          <td className="p-2 no-print">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => deleteNCR(i)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "asbuilt" && (
            <AsBuiltDrawing 
              asBuiltData={asBuiltData}
              setAsBuiltData={setAsBuiltData}
              materialInventory={materialInventory}
              onPlacePanel={placePanelFromRoll}
              getActiveRolls={getActiveRolls}
            />
          )}

          {activeModule === "report" && (
            <Card className="shadow-sm bg-card ">
              <CardHeader>
                <CardTitle>CQA Pack Report</CardTitle>
                <CardDescription>Complete project report - optimized for printing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div className="flex items-start gap-4 border-b pb-3 mb-6">
                    {settings.logo && (
                      <img src={settings.logo} alt="Company Logo" className="h-16 w-auto" />
                    )}
                    <div className="flex-1">
                      <h1 className="text-2xl font-bold mb-1">{settings.company || "CQA Report"}</h1>
                      <p className="text-sm text-muted-foreground">{settings.region || "Project Region"}</p>
                      <p className="text-xs text-muted-foreground">{settings.contact}</p>
                    </div>
                  </div>

                  <section className="mb-8 p-6 bg-muted rounded-lg border ">
                    <h2 className="text-xl font-bold mb-4 text-foreground">Executive Summary</h2>
                    <div className="space-y-4 text-sm leading-relaxed text-foreground">
                      {generateIntelligentSummary().paragraphs.map((paragraph, index) => (
                        <p key={index} className="text-justify">
                          {paragraph}
                        </p>
                      ))}
                    </div>
                    <div className="mt-4 pt-4 border-t border-border text-xs text-muted-foreground">
                      Report generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
                    </div>
                  </section>

                  {(projectSpecs.projectName || projectSpecs.projectNumber || projectSpecs.clientName) && (
                    <section className="page-break-before mb-8">
                      <h2 className="text-xl font-semibold mb-4 border-b pb-2">Project Specifications</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        {projectSpecs.projectName && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Project Name</div>
                            <div className="text-foreground">{projectSpecs.projectName}</div>
                          </div>
                        )}
                        {projectSpecs.projectNumber && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Project Number</div>
                            <div className="text-foreground">{projectSpecs.projectNumber}</div>
                          </div>
                        )}
                        {projectSpecs.clientName && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Client Name</div>
                            <div className="text-foreground">{projectSpecs.clientName}</div>
                          </div>
                        )}
                        {projectSpecs.siteLocation && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Site Location</div>
                            <div className="text-foreground">{projectSpecs.siteLocation}</div>
                          </div>
                        )}
                        {projectSpecs.geomembraneType && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Geomembrane Type/Material</div>
                            <div className="text-foreground">{projectSpecs.geomembraneType}</div>
                          </div>
                        )}
                        {projectSpecs.specifiedThickness && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Specified Thickness</div>
                            <div className="text-foreground">{projectSpecs.specifiedThickness} mm</div>
                          </div>
                        )}
                        {projectSpecs.totalArea && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Total Area</div>
                            <div className="text-foreground">{projectSpecs.totalArea} m²</div>
                          </div>
                        )}
                        {projectSpecs.startDate && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Project Start Date</div>
                            <div className="text-foreground">{projectSpecs.startDate}</div>
                          </div>
                        )}
                        {projectSpecs.supervisor && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Project Supervisor</div>
                            <div className="text-foreground">{projectSpecs.supervisor}</div>
                          </div>
                        )}
                        {projectSpecs.contractor && (
                          <div className="border rounded-lg p-3 bg-muted/50">
                            <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Contractor Name</div>
                            <div className="text-foreground">{projectSpecs.contractor}</div>
                          </div>
                        )}
                      </div>
                      {projectSpecs.qualityStandards && (
                        <div className="mt-4 border rounded-lg p-3 bg-muted/50">
                          <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-2">Quality Standards / Requirements</div>
                          <div className="text-foreground whitespace-pre-wrap">{projectSpecs.qualityStandards}</div>
                        </div>
                      )}
                      
                      {(projectSpecs.testingRequirements || projectSpecs.minPeelPass || projectSpecs.minShearPass || projectSpecs.destructiveTestFrequency) && (
                        <div className="mt-4">
                          <h3 className="text-lg font-semibold mb-3 pb-2 border-b">Testing Requirements</h3>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                            {projectSpecs.minPeelPass && (
                              <div className="border rounded-lg p-3 bg-muted/50">
                                <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Minimum Peel Pass</div>
                                <div className="text-foreground text-lg font-bold">{projectSpecs.minPeelPass} N/mm</div>
                              </div>
                            )}
                            {projectSpecs.minShearPass && (
                              <div className="border rounded-lg p-3 bg-muted/50">
                                <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Minimum Shear Pass</div>
                                <div className="text-foreground text-lg font-bold">{projectSpecs.minShearPass} N/mm</div>
                              </div>
                            )}
                            {projectSpecs.destructiveTestFrequency && (
                              <div className="border rounded-lg p-3 bg-muted/50">
                                <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-1">Destructive Test Frequency</div>
                                <div className="text-foreground text-lg font-bold">Every {projectSpecs.destructiveTestFrequency}m</div>
                              </div>
                            )}
                          </div>
                          {projectSpecs.testingRequirements && (
                            <div className="border rounded-lg p-3 bg-muted/50">
                              <div className="font-semibold text-muted-foreground text-xs uppercase tracking-wide mb-2">Testing Requirements Description</div>
                              <div className="text-foreground whitespace-pre-wrap">{projectSpecs.testingRequirements}</div>
                            </div>
                          )}
                          {projectSpecs.destructiveTestFrequency && (
                            <div className="mt-4 border rounded-lg p-3 bg-accent/10 border-accent/30">
                              <div className="font-semibold text-accent text-sm mb-2">Destructive Sample Due Points</div>
                              <div className="flex flex-wrap gap-2">
                                {Array.from({ length: 20 }, (_, i) => (i + 1) * parseFloat(projectSpecs.destructiveTestFrequency)).map((duePoint, idx) => (
                                  <span key={idx} className="px-2 py-1 bg-accent/20 text-accent rounded text-xs font-medium">
                                    {duePoint.toFixed(0)}m
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </section>
                  )}

                  {signOnLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Daily Sign On Sheet</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Worker Name</th>
                              <th className="border p-2 text-left">Company</th>
                              <th className="border p-2 text-left">Time In</th>
                              <th className="border p-2 text-left">Time Out</th>
                            </tr>
                          </thead>
                          <tbody>
                            {signOnLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {machinePreStartLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Machine Pre-Start Check</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Machine</th>
                              <th className="border p-2 text-left">Operator</th>
                              <th className="border p-2 text-left">Pre-Check</th>
                              <th className="border p-2 text-left">Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {machinePreStartLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {trialWeldLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Trial Welds</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Time</th>
                              <th className="border p-2 text-left">Tech</th>
                              <th className="border p-2 text-left">Machine ID</th>
                              <th className="border p-2 text-left">Weld Type</th>
                              <th className="border p-2 text-left">Fusion Temp (°C)</th>
                              <th className="border p-2 text-left">Fusion Speed (m/min)</th>
                              <th className="border p-2 text-left">Extrusion Barrel (°C)</th>
                              <th className="border p-2 text-left">Extrusion Preheat (°C)</th>
                            </tr>
                          </thead>
                          <tbody>
                            {trialWeldLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                                <td className="border p-2">{row[5]}</td>
                                <td className="border p-2">{row[6]}</td>
                                <td className="border p-2">{row[7]}</td>
                                <td className="border p-2">{row[8]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {dailyLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Daily Summary</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Weather</th>
                              <th className="border p-2 text-left">Crew</th>
                              <th className="border p-2 text-left">Notes</th>
                            </tr>
                          </thead>
                          <tbody>
                            {dailyLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {panelPlacementLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Panel Placement</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Time</th>
                              <th className="border p-2 text-left">Ambient Temp (°C)</th>
                              <th className="border p-2 text-left">Length of Panel (m)</th>
                              <th className="border p-2 text-left">Location</th>
                              <th className="border p-2 text-left">Roll Number</th>
                            </tr>
                          </thead>
                          <tbody>
                            {panelPlacementLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                                <td className="border p-2">{row[5]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {materialRegisterLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Material Register</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Roll ID</th>
                              <th className="border p-2 text-left">Manufacturer</th>
                              <th className="border p-2 text-left">Thickness (mm)</th>
                              <th className="border p-2 text-left">Width (m)</th>
                              <th className="border p-2 text-left">Length (m)</th>
                              <th className="border p-2 text-left">Lot Number</th>
                              <th className="border p-2 text-left">Note</th>
                            </tr>
                          </thead>
                          <tbody>
                            {materialRegisterLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                                <td className="border p-2">{row[5]}</td>
                                <td className="border p-2">{row[6]}</td>
                                <td className="border p-2">{row[7]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {repairLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Repair Log</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border text-sm">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Location</th>
                              <th className="border p-2 text-left">Size</th>
                              <th className="border p-2 text-left">Issue</th>
                              <th className="border p-2 text-left">Tech</th>
                              <th className="border p-2 text-left">Weld Type</th>
                              <th className="border p-2 text-left">Barrel (°C)</th>
                              <th className="border p-2 text-left">Preheat (°C)</th>
                              <th className="border p-2 text-left">Fusion (°C)</th>
                              <th className="border p-2 text-left">Speed (m/min)</th>
                              <th className="border p-2 text-left">Note</th>
                            </tr>
                          </thead>
                          <tbody>
                            {repairLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                                <td className="border p-2">{row[5]}</td>
                                <td className="border p-2">{row[6] || '-'}</td>
                                <td className="border p-2">{row[7] || '-'}</td>
                                <td className="border p-2">{row[8] || '-'}</td>
                                <td className="border p-2">{row[9] || '-'}</td>
                                <td className="border p-2">{row[10]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {weldLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Weld Log (Panel Seam Fusion)</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Technician Name</th>
                              <th className="border p-2 text-left">Machine ID</th>
                              <th className="border p-2 text-left">Date</th>
                              <th className="border p-2 text-left">Time</th>
                              <th className="border p-2 text-left">Fusion Temp (°C)</th>
                              <th className="border p-2 text-left">Fusion Speed (m/min)</th>
                            </tr>
                          </thead>
                          <tbody>
                            {weldLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                                <td className="border p-2">{row[4]}</td>
                                <td className="border p-2">{row[5]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {(airLogs.length > 0 || vacuumLogs.length > 0 || sparkLogs.length > 0) && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Non-Destructive Testing</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Test Type</th>
                              <th className="border p-2 text-left">Test ID</th>
                              <th className="border p-2 text-left">Pressure (kPa)</th>
                              <th className="border p-2 text-left">Duration (min)</th>
                              <th className="border p-2 text-left">Voltage (V)</th>
                              <th className="border p-2 text-left">Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            {airLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">Air</td>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">{row[3]}</td>
                              </tr>
                            ))}
                            {vacuumLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">Vacuum</td>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">{row[3]}</td>
                              </tr>
                            ))}
                            {sparkLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">Spark</td>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {destructiveLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">Destructive Tests</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">Sample ID</th>
                              <th className="border p-2 text-left">Peel (N/mm)</th>
                              <th className="border p-2 text-left">Shear (N/mm)</th>
                              <th className="border p-2 text-left">Result</th>
                            </tr>
                          </thead>
                          <tbody>
                            {destructiveLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  {ncrLogs.length > 0 && (
                    <section className="page-break-before">
                      <h2 className="text-xl font-semibold mb-3 border-b pb-2">NCR Register</h2>
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse border">
                          <thead>
                            <tr className="bg-muted/50">
                              <th className="border p-2 text-left">NCR ID</th>
                              <th className="border p-2 text-left">Description</th>
                              <th className="border p-2 text-left">Action</th>
                              <th className="border p-2 text-left">Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ncrLogs.map((row, i) => (
                              <tr key={i}>
                                <td className="border p-2">{row[0]}</td>
                                <td className="border p-2">{row[1]}</td>
                                <td className="border p-2">{row[2]}</td>
                                <td className="border p-2">{row[3]}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </section>
                  )}

                  <div className="mt-8 pt-4 border-t text-sm text-muted-foreground text-center">
                    <p>Report generated on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeModule === "finalportal" && (
            <FinalJointPortal
              finalPortal={finalPortal}
              setFinalPortal={setFinalPortal}
              projectSpecs={projectSpecs}
              signOnLogs={signOnLogs}
              dailyLogs={dailyLogs}
              panelPlacementLogs={panelPlacementLogs}
              weldLogs={weldLogs}
              trialWeldLogs={trialWeldLogs}
              repairLogs={repairLogs}
              airLogs={airLogs}
              vacuumLogs={vacuumLogs}
              sparkLogs={sparkLogs}
              destructiveLogs={destructiveLogs}
              machinePreStartLogs={machinePreStartLogs}
              ncrLogs={ncrLogs}
            />
          )}

          {activeModule === "userguide" && (
            <Card className="shadow-sm bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">📖</span> LINR User Guide
                </CardTitle>
                <CardDescription>Complete guide to using the CQA Logging Application</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                  <h3 className="text-lg font-semibold text-primary mb-2">Welcome to LINR</h3>
                  <p className="text-muted-foreground">
                    LINR is an offline-first Construction Quality Assurance (CQA) logging application designed for geomembrane installation projects. 
                    All your data is stored locally in your browser, so you can work without internet connectivity.
                  </p>
                </div>

                <div className="space-y-6">
                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>🚀</span> Getting Started
                    </h3>
                    <div className="space-y-4 text-muted-foreground">
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">1. Create a New Project</h4>
                        <p>From the home screen, enter a project name and click "Create Project". Each project has its own isolated data.</p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">2. Configure Settings</h4>
                        <p>Go to <strong>Settings</strong> to enter your company name, contact details, and region. You can also upload a company logo for reports.</p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">3. Set Up Project Specs</h4>
                        <p>Navigate to <strong>Engineers</strong> to configure project specifications including client name, site location, geomembrane type, and quality standards.</p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">4. Start Logging</h4>
                        <p>Use the navigation bar to access different logging modules. All entries are auto-saved as you work.</p>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>📋</span> Module Overview
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-orange-400">📝</span> Daily Operations
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>Sign On Sheet</strong> - Record personnel on-site daily</li>
                          <li><strong>Machine Pre-Start</strong> - Equipment safety checks</li>
                          <li><strong>Daily Summary</strong> - Weather, activities, notes</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-blue-400">🔧</span> Welding
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>Trial Welds</strong> - Pre-production weld tests</li>
                          <li><strong>Weld Log</strong> - Production panel seaming records</li>
                          <li><strong>Repair Log</strong> - Weld repairs and patches</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-green-400">🧪</span> Testing
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>Non-Destructive</strong> - Air, vacuum, spark tests</li>
                          <li><strong>Destructive Tests</strong> - Peel and shear testing</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-purple-400">📦</span> Materials
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>Panel Placement</strong> - Track panel deployment</li>
                          <li><strong>Material Register</strong> - Inventory management</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-red-400">⚠️</span> Quality
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>NCR Log</strong> - Non-conformance reports</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                          <span className="text-cyan-400">📊</span> Reports
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li><strong>As-Built Drawings</strong> - CAD-style sketches</li>
                          <li><strong>CQA Report</strong> - Complete project summary</li>
                          <li><strong>Final Joint Portal</strong> - End-of-day submissions</li>
                        </ul>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>🎨</span> As-Built Drawings Guide
                    </h3>
                    <div className="space-y-4">
                      <p className="text-muted-foreground">
                        The As-Built Drawings module is a powerful CAD-style tool for sketching ponds, panels, and site layouts.
                      </p>
                      
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-3">Drawing Tools</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">↖</span>
                            <div>
                              <p className="font-medium">Select</p>
                              <p className="text-xs text-muted-foreground">Click to select, drag to move</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">📏</span>
                            <div>
                              <p className="font-medium">Line</p>
                              <p className="text-xs text-muted-foreground">Draw straight lines</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">〰️</span>
                            <div>
                              <p className="font-medium">Curve</p>
                              <p className="text-xs text-muted-foreground">Draw curved lines</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">▭</span>
                            <div>
                              <p className="font-medium">Rectangle</p>
                              <p className="text-xs text-muted-foreground">Draw rectangles</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">▢</span>
                            <div>
                              <p className="font-medium">Rounded Rect</p>
                              <p className="text-xs text-muted-foreground">Smooth corner rectangles</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">🏗️</span>
                            <div>
                              <p className="font-medium">Structure</p>
                              <p className="text-xs text-muted-foreground">Add pre-built shapes</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">T</span>
                            <div>
                              <p className="font-medium">Text</p>
                              <p className="text-xs text-muted-foreground">Add labels and notes</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">📐</span>
                            <div>
                              <p className="font-medium">Measure</p>
                              <p className="text-xs text-muted-foreground">Measure distances</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-primary/20 rounded flex items-center justify-center">📍</span>
                            <div>
                              <p className="font-medium">GPS Marker</p>
                              <p className="text-xs text-muted-foreground">Mark GPS coordinates</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-3">Eraser Tools</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-red-500/20 rounded flex items-center justify-center">🗑️</span>
                            <div>
                              <p className="font-medium">Click Eraser</p>
                              <p className="text-xs text-muted-foreground">Click on any object to delete it</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-8 h-8 bg-red-500/20 rounded flex items-center justify-center">⬜</span>
                            <div>
                              <p className="font-medium">Box Eraser</p>
                              <p className="text-xs text-muted-foreground">Draw a box to delete multiple objects</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-3">Keyboard Shortcuts</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">L</kbd> = Line</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">C</kbd> = Curve</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">R</kbd> = Rectangle</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">T</kbd> = Text</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">S</kbd> = Structure</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">M</kbd> = Measure</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">E</kbd> = Eraser</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">G</kbd> = Toggle Grid</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">Ctrl+Z</kbd> = Undo</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">Ctrl+Y</kbd> = Redo</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">Space</kbd> = Pan</div>
                          <div className="bg-muted/50 rounded px-2 py-1"><kbd className="font-mono">+/-</kbd> = Zoom</div>
                        </div>
                      </div>

                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-3">Tips for Mobile/Tablet</h4>
                        <ul className="text-sm text-muted-foreground space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span>Use <strong>Fullscreen mode</strong> for maximum drawing space</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span><strong>Pinch to zoom</strong> in and out of your drawing</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span><strong>Two-finger drag</strong> to pan around the canvas</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span>Enable <strong>Snap Lock</strong> to align to grid points</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="text-primary">•</span>
                            <span>Use the floating toolbar in fullscreen for quick tool access</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>💾</span> Data Management
                    </h3>
                    <div className="space-y-4">
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Auto-Save</h4>
                        <p className="text-sm text-muted-foreground">
                          All your entries are automatically saved to your browser's local storage as you type. 
                          You never need to manually save your work.
                        </p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Export Data</h4>
                        <p className="text-sm text-muted-foreground">
                          Use the <strong>Export All Data</strong> button on the home screen to download a ZIP file containing:
                        </p>
                        <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                          <li>• CSV files for all logging modules</li>
                          <li>• JSON export of As-Built drawings</li>
                          <li>• Markdown summary report</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Multiple Projects</h4>
                        <p className="text-sm text-muted-foreground">
                          Create separate projects for different job sites. Each project has completely isolated data, 
                          so you can switch between projects without mixing data.
                        </p>
                      </div>
                      <div className="bg-warning/10 border border-warning/30 rounded-lg p-4">
                        <h4 className="font-medium text-warning mb-2">Important: Data Backup</h4>
                        <p className="text-sm text-muted-foreground">
                          Your data is stored in your browser only. <strong>Export your data regularly</strong> to prevent data loss 
                          if you clear your browser data or switch devices.
                        </p>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>🖨️</span> Printing Reports
                    </h3>
                    <div className="space-y-4 text-muted-foreground">
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Print CQA Report</h4>
                        <p className="text-sm">
                          Navigate to <strong>Reports → CQA Report</strong> and click the Print button. 
                          The report automatically formats for printing with:
                        </p>
                        <ul className="text-sm mt-2 space-y-1">
                          <li>• Company logo and header on each page</li>
                          <li>• White background for ink-friendly printing</li>
                          <li>• Professional table formatting</li>
                          <li>• Page numbers and date stamps</li>
                        </ul>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Print Individual Modules</h4>
                        <p className="text-sm">
                          Each module has a Print button that prints just that section of data in a formatted layout.
                        </p>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>📱</span> Offline Usage
                    </h3>
                    <div className="bg-card border rounded-lg p-4">
                      <p className="text-sm text-muted-foreground mb-3">
                        LINR is designed to work completely offline. Once loaded, you can:
                      </p>
                      <ul className="text-sm text-muted-foreground space-y-2">
                        <li className="flex items-start gap-2">
                          <span className="text-green-400">✓</span>
                          <span>Create and manage projects without internet</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-green-400">✓</span>
                          <span>Log all data across all modules</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-green-400">✓</span>
                          <span>Create As-Built drawings</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-green-400">✓</span>
                          <span>Export data to ZIP files</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <span className="text-green-400">✓</span>
                          <span>Print reports</span>
                        </li>
                      </ul>
                      <p className="text-sm text-muted-foreground mt-3">
                        <strong>Tip:</strong> Add LINR to your home screen for quick access like a native app.
                      </p>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-xl font-semibold border-b pb-2 mb-4 flex items-center gap-2">
                      <span>❓</span> Troubleshooting
                    </h3>
                    <div className="space-y-4">
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Data not appearing?</h4>
                        <p className="text-sm text-muted-foreground">
                          Make sure you're using the same browser and haven't cleared your browser data. 
                          Data is stored per-browser, so Chrome and Safari have separate storage.
                        </p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Drawing not saving?</h4>
                        <p className="text-sm text-muted-foreground">
                          Drawings auto-save after each action. If you're having issues, try refreshing the page. 
                          Use Undo (Ctrl+Z) if you made a mistake.
                        </p>
                      </div>
                      <div className="bg-card border rounded-lg p-4">
                        <h4 className="font-medium text-foreground mb-2">Export not working?</h4>
                        <p className="text-sm text-muted-foreground">
                          Ensure your browser allows downloads. Some mobile browsers may save the ZIP to a Downloads folder. 
                          Check your browser's download settings.
                        </p>
                      </div>
                    </div>
                  </section>
                </div>

                <div className="bg-muted/30 rounded-lg p-4 text-center">
                  <p className="text-sm text-muted-foreground">
                    Need more help? Contact your CQA supervisor or system administrator.
                  </p>
                  <p className="text-xs text-muted-foreground mt-2">
                    LINR v1.0 - Built for field teams
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
      
      <footer className="print-footer print-only">
        {settings.company && <strong>{settings.company}</strong>}
        {settings.contact && <span> | Contact: {settings.contact}</span>}
        {settings.region && <span> | Region: {settings.region}</span>}
      </footer>
    </div>
  )
}
