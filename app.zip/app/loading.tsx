export default function Loading() {
  return (
    <div 
      className="min-h-screen flex items-center justify-center"
      style={{ backgroundColor: 'hsl(220, 25%, 10%)' }}
    >
      <div className="flex items-center gap-3 animate-pulse">
        <img 
          src="/icononly_transparent_nobuffer_1763974511214.png" 
          alt="LINR" 
          className="w-12 h-12 object-contain" 
        />
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'hsl(180, 80%, 50%)' }}>LINR</h1>
          <p className="text-sm" style={{ color: 'hsl(0, 0%, 75%)' }}>Loading...</p>
        </div>
      </div>
    </div>
  )
}
