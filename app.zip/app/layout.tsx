import type { Metadata } from "next";
import "./globals.css";
import { RegisterSW } from "./register-sw";
import { AuthProvider } from "@/lib/auth-context";

export const metadata: Metadata = {
  title: "LINR – CQA App",
  description: "Construction Quality Assurance logging application for geomembrane projects",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#111827" />
        <link rel="icon" href="/icons/icon-192.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="LINR" />
      </head>
      <body style={{ backgroundColor: 'hsl(220, 25%, 10%)' }}>
        <RegisterSW />
        <AuthProvider>
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
